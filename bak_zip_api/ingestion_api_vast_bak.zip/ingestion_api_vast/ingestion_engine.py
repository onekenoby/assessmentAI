# FINAL MULTI-TENANT HARDENED VERSION - aligned with Architecture v1.1


"""
set EMBED_BATCH_SIZE=16
set DB_FLUSH_SIZE=96
set VISION_PARALLEL_WORKERS=1
set MAX_KG_CHUNKS_PER_DOC=10

set PG_COMMIT_EVERY_N_PAGES=25
"""

"""
Ingestion Engine - v2.5 DATABASE BYTEA
✅ Source: protected PostgreSQL rag_ingestion worker APIs
✅ Strategy: PDF -> Virtual MD + Image Asset Park (RAM)
✅ Vision: Surgical AI on parked assets only
✅ Value Hunter: DB-tier-aware selective KG + AI Gatekeeper
✅ Hardware: Optimized for P5000 (16GB VRAM, num_ctx: 3072)
"""



import os

import sys

# Output immediato nel terminale/container.
# Evita che i messaggi di producer, consumer, embedding, KG e database
# restino nel buffer fino alla fine del processo Docker.
os.environ["PYTHONUNBUFFERED"] = "1"
try:
    sys.stdout.reconfigure(line_buffering=True, write_through=True)
    sys.stderr.reconfigure(line_buffering=True, write_through=True)
except (AttributeError, ValueError):
    # Compatibilità con stream sostituiti da IDE/test runner.
    pass

# --- FIX ANTI-BLOCCO ---
# Impostiamo queste variabili PRIMA di importare altre librerie pesanti.
# Questo risolve il freeze quando si calcolano gli embeddings mentre Ollama è attivo.
os.environ["TOKENIZERS_PARALLELISM"] = "false"

# valori "safe" (evitano oversubscription e spesso evitano freeze)
CPU_THREADS = os.environ.get("EMBED_CPU_THREADS", "4")
os.environ["OMP_NUM_THREADS"] = CPU_THREADS
os.environ["MKL_NUM_THREADS"] = CPU_THREADS
os.environ["OPENBLAS_NUM_THREADS"] = CPU_THREADS
os.environ["NUMEXPR_NUM_THREADS"] = CPU_THREADS

import re
import json
import time
import uuid
import shutil
import hashlib
import base64
from typing import List, Dict, Tuple, Optional, Any, Union
from contextlib import contextmanager
from concurrent.futures import ThreadPoolExecutor, as_completed
import concurrent.futures as cf
import subprocess
import requests
from threading import Lock
import gc
import queue
import threading
import tempfile


#import pytesseract
#pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

import pytesseract
TESSERACT_CMD = os.getenv("TESSERACT_CMD", "")

if TESSERACT_CMD:
    pytesseract.pytesseract.tesseract_cmd = TESSERACT_CMD


import unicodedata
import fitz  # PyMuPDF
import psycopg2
from psycopg2.extras import Json, execute_values, RealDictCursor
from psycopg2.pool import ThreadedConnectionPool
from psycopg2 import errors as pg_errors

from sentence_transformers import SentenceTransformer
from qdrant_client import QdrantClient, models
from neo4j import GraphDatabase
from openai import OpenAI

# OLLAMA
#from ollama import chat
#from ollama import ChatResponse

# Le chiamate a Ollama vengono eseguite tramite requests
# usando OLLAMA_API_CHAT e OLLAMA_API_GENERATE.



from pdfminer.layout import LAParams

try:
    from pdfminer.high_level import extract_pages
    from pdfminer.layout import LTTextContainer
except Exception:
    extract_pages = None
    LTTextContainer = None

from sentence_transformers import util
import torch


# =========================
# DOCUMENT CLASSIFICATION SOURCE
# =========================
# TIER, scope, organization_id and ontology are authoritative metadata
# returned by the protected worker APIs of schema rag_ingestion.
# No local source directory or path-based taxonomy is used.


# =========================
# MULTI-TENANT CONTEXT
# =========================
# organization_id, TIER, scope and tenant_key are always read from the
# claimed job in Database A. There is no fixed tenant in the runtime.

POC_MODE = os.getenv("POC_MODE", "1") == "1"
CORPUS_VERSION = (os.getenv("CORPUS_VERSION", "v1").strip() or "v1")
DEFAULT_CLASSIFICATION = (
    os.getenv("DEFAULT_CLASSIFICATION", "internal").strip().lower()
    or "internal"
)
DOCUMENT_ACTIVE_STATUS = "active"
INGESTION_RUN_STATUSES = {"RUNNING", "DONE", "FAILED", "PARTIAL_FAILED"}
PG_AUTO_HARDEN_SCHEMA = os.getenv("PG_AUTO_HARDEN_SCHEMA", "0") == "1"
PG_SCHEMA_MIGRATION_ONLY = os.getenv("PG_SCHEMA_MIGRATION_ONLY", "0") == "1"
PG_ENFORCE_LEAST_PRIVILEGE = False

# Contesto thread-local usato esclusivamente per impostare la RLS del
# Database B durante l'elaborazione del job corrente.
_OUTPUT_DB_CONTEXT = threading.local()


def build_tenant_key(scope: str, organization_id: Optional[int]) -> str:
    """Namespace stabile usato negli identificativi persistiti."""
    normalized_scope = str(scope or "").strip().upper()

    if normalized_scope == "GLOBAL":
        return "GLOBAL"

    if normalized_scope != "ACCOUNT":
        raise ValueError(f"Scope multi-tenant non valido: {scope!r}")

    if organization_id is None:
        raise ValueError("organization_id obbligatorio per scope ACCOUNT")

    org_id = int(organization_id)
    if org_id <= 0:
        raise ValueError("organization_id deve essere maggiore di zero")

    return f"ORG:{org_id}"


# -------------------------
# KG LIMITS (coherent names)
# -------------------------
# These are the ONLY canonical names used by the pipeline.
# A few aliases are kept for backward-compat with older snippets.
MIN_ENTITY_DENSITY = int(os.getenv("MIN_ENTITY_DENSITY", "1"))
MIN_FIN_KEYWORDS = int(os.getenv("MIN_FIN_KEYWORDS", "1"))

KG_TEXT_MAX_CHARS = int(os.getenv("KG_TEXT_MAX_CHARS", "2600"))   # max chars sent to KG model per window
KG_WINDOW_OVERLAP_CHARS = int(os.getenv("KG_WINDOW_OVERLAP_CHARS", "300"))
# 0 = nessun limite. Ogni pagina lunga viene coperta da tutte le finestre necessarie.
KG_MAX_WINDOWS_PER_PAGE = int(os.getenv("KG_MAX_WINDOWS_PER_PAGE", "0"))
KG_MAX_TRIPLES = int(os.getenv("KG_MAX_TRIPLES", "50"))           # 10 soft cap (sanitize already caps)
KG_TIMEOUT = int(os.getenv("KG_TIMEOUT", "360"))                   # seconds per KG task/page

# Backward-compat aliases (do NOT use in new code)
KG_CHARS_LIMIT = KG_TEXT_MAX_CHARS
KG_MAX_CHARS = KG_TEXT_MAX_CHARS
KG_MAX_TRIPLES_PER_PAGE = KG_MAX_TRIPLES
MAX_TRIPLES_KG = KG_MAX_TRIPLES
KG_TASK_TIMEOUT = KG_TIMEOUT
KG_TASK_TIMEOUT_PER_PAGE = KG_TIMEOUT
KG_TIMEOUT_PER_PAGE = KG_TIMEOUT






CHUNK_MAX_CHARS = int(os.getenv("CHUNK_MAX_CHARS", "800"))
CHUNK_OVERLAP_CHARS = int(os.getenv("CHUNK_OVERLAP_CHARS", "200"))
MIN_CHUNK_LEN = int(os.getenv("MIN_CHUNK_LEN", "40"))

CONTEXT_WINDOW_CHARS = int(os.getenv("CONTEXT_WINDOW_CHARS", "260"))
INCLUDE_CONTEXT_IN_KG = os.getenv("INCLUDE_CONTEXT_IN_KG", "1") == "1"

DB_FLUSH_SIZE = int(os.getenv("DB_FLUSH_SIZE", "200"))          # un po' più alto per meno flush - 
EMBED_BATCH_SIZE = int(os.getenv("EMBED_BATCH_SIZE", "16"))    # se la tua VRAM regge, aumenta velocità

# Vision switches
PDF_VISION_ENABLED = os.getenv("PDF_VISION_ENABLED", "1") == "1"
PDF_VISION_ONLY_IF_TEXT_SCARSO = False #= os.getenv("PDF_VISION_ONLY_IF_TEXT_SCARSO", "0") == "1"
PDF_MIN_TEXT_LEN_FOR_NO_VISION = 0 #= int(os.getenv("PDF_MIN_TEXT_LEN_FOR_NO_VISION", "450"))

VISION_DPI = int(os.getenv("VISION_DPI", "130"))
VISION_MAX_IMAGE_BYTES = int(os.getenv("VISION_MAX_IMAGE_BYTES", "2000000"))

VISION_MAX_FORMULAS_PER_PAGE = int(
    os.getenv("VISION_MAX_FORMULAS_PER_PAGE", "10")
)

# ---------------------------------------------------------
# Profilo Vision configurabile
# Default iniziali consigliati per RTX 5090 32 GB.
# ---------------------------------------------------------
VISION_PAGE_DPI = int(
    os.getenv("VISION_PAGE_DPI", "160")
)

VISION_PAGE_NUM_CTX = int(
    os.getenv("VISION_PAGE_NUM_CTX", "8192")
)

VISION_PAGE_MAX_TOKENS = int(
    os.getenv("VISION_PAGE_MAX_TOKENS", "3200")
)

FORMULA_RENDER_DPI = int(
    os.getenv("FORMULA_RENDER_DPI", "210")
)

FORMULA_VISION_NUM_CTX = int(
    os.getenv("FORMULA_VISION_NUM_CTX", "8192")
)

FORMULA_VISION_MAX_TOKENS = int(
    os.getenv("FORMULA_VISION_MAX_TOKENS", "1500")
)

FORMULA_VISION_MAX_SIDE = int(
    os.getenv("FORMULA_VISION_MAX_SIDE", "2400")
)

PDF_VECTOR_VISION_THRESHOLD = int(
    os.getenv(
        "PDF_VECTOR_VISION_THRESHOLD",
        "40",
    )
)

PDF_VECTOR_ONLY_MAX_TEXT_LEN = int(
    os.getenv(
        "PDF_VECTOR_ONLY_MAX_TEXT_LEN",
        "80",
    )
)

PDF_TABLE_DIGIT_DENSITY = float(
    os.getenv("PDF_TABLE_DIGIT_DENSITY", "0.15")
)

PDF_SKIP_FORMULA_AFTER_PAGE_VISION = (
    os.getenv(
        "PDF_SKIP_FORMULA_AFTER_PAGE_VISION",
        "1",
    ) == "1"
)

PDF_VECTOR_ONLY_MAX_TEXT_LEN = int(
    os.getenv(
        "PDF_VECTOR_ONLY_MAX_TEXT_LEN",
        "120",
    )
)

PDF_CORRUPTION_BAD_CHAR_RATIO = float(
    os.getenv(
        "PDF_CORRUPTION_BAD_CHAR_RATIO",
        "0.01",
    )
)

PDF_CORRUPTION_MIN_BAD_CHARS = int(
    os.getenv(
        "PDF_CORRUPTION_MIN_BAD_CHARS",
        "3",
    )
)

CHART_VISION_NUM_CTX = int(
    os.getenv(
        "CHART_VISION_NUM_CTX",
        str(VISION_PAGE_NUM_CTX),
    )
)

CHART_VISION_RETRY_ENABLED = (
    os.getenv(
        "CHART_VISION_RETRY_ENABLED",
        "1",
    ) == "1"
)

CHART_VISION_RETRY_ON_EMPTY = (
    os.getenv(
        "CHART_VISION_RETRY_ON_EMPTY",
        "0",
    ) == "1"
)

CHART_REQUIRE_OCR_TEXT = (
    os.getenv(
        "CHART_REQUIRE_OCR_TEXT",
        "1",
    ) == "1"
)

CHART_MIN_OCR_CHARS = int(
    os.getenv(
        "CHART_MIN_OCR_CHARS",
        "12",
    )
)

# --- SOGLIE ASSET VISUALI ---
# Immagini più piccole di questo valore (in byte) verranno ignorate.
# 7000 = icone/loghi | 2000 = molto permissivo | 15000 = molto sever
PDF_EXTRACT_EMBEDDED_IMAGES = os.getenv("PDF_EXTRACT_EMBEDDED_IMAGES", "1") == "1" #= os.getenv("PDF_EXTRACT_EMBEDDED_IMAGES", "1") == "1"
PDF_VISION_ON_EMBEDDED_IMAGES = os.getenv("PDF_VISION_ON_EMBEDDED_IMAGES", "1") == "1" # = os.getenv("PDF_VISION_ON_EMBEDDED_IMAGES", "1") == "1"
PDF_MAX_IMAGES_PER_PAGE = int(os.getenv("PDF_MAX_IMAGES_PER_PAGE", "5"))


MIN_IMAGE_BYTES = int(
    os.getenv(
        "MIN_IMAGE_BYTES",
        "7000",
    )
)

MIN_ASSET_SIZE = int(
    os.getenv(
        "MIN_ASSET_SIZE",
        "7000",
    )
)

PDF_EMBEDDED_MIN_WIDTH = int(
    os.getenv(
        "PDF_EMBEDDED_MIN_WIDTH",
        "300",
    )
)

PDF_EMBEDDED_MIN_HEIGHT = int(
    os.getenv(
        "PDF_EMBEDDED_MIN_HEIGHT",
        "180",
    )
)

PDF_EMBEDDED_MIN_AREA = int(
    os.getenv(
        "PDF_EMBEDDED_MIN_AREA",
        "100000",
    )
)

PDF_EMBEDDED_MAX_ASPECT_RATIO = float(
    os.getenv(
        "PDF_EMBEDDED_MAX_ASPECT_RATIO",
        "6.0",
    )
)

PDF_EMBEDDED_MIN_TONAL_RANGE = int(
    os.getenv(
        "PDF_EMBEDDED_MIN_TONAL_RANGE",
        "12",
    )
)

PDF_EMBEDDED_SKIP_DUPLICATES = (
    os.getenv(
        "PDF_EMBEDDED_SKIP_DUPLICATES",
        "1",
    ) == "1"
)



# Speed: Vision parallel + cache
VISION_PARALLEL_WORKERS = int(
    os.getenv("VISION_PARALLEL_WORKERS", "1")
)

OLLAMA_NUM_PARALLEL = int(
    os.getenv("OLLAMA_NUM_PARALLEL", "1")
)

VISION_CACHE_MAX = int(
    os.getenv("VISION_CACHE_MAX", "5000")
)

# entries in-memory

# Commit policy
PG_COMMIT_EVERY_N_PAGES = int(os.getenv("PG_COMMIT_EVERY_N_PAGES", "25"))

# KG extraction (solo dove serve)
KG_ENABLED = os.getenv("KG_ENABLED", "1") == "1"
KG_MIN_LEN = int(os.getenv("KG_MIN_LEN", "100")) #
MAX_KG_CHUNKS_PER_DOC = int(os.getenv("MAX_KG_CHUNKS_PER_DOC", "0"))
# Il limite KG è disabilitato di default. Viene applicato soltanto se
# KG_CHUNK_LIMIT_ENABLED=1; in questo modo un vecchio valore ambiente non
# tronca silenziosamente il grafo.
KG_CHUNK_LIMIT_ENABLED = os.getenv("KG_CHUNK_LIMIT_ENABLED", "0") == "1"


KG_GATEKEEPER_THRESHOLD = float(
    os.getenv(
        "KG_GATEKEEPER_THRESHOLD",
        "0.20",
    )
)

KG_WINDOW_OVERLAP_CHARS = int(
    os.getenv(
        "KG_WINDOW_OVERLAP_CHARS",
        "300",
    )
)

KG_MAX_WINDOWS_PER_CHUNK = int(
    os.getenv(
        "KG_MAX_WINDOWS_PER_CHUNK",
        "0",
    )
)

# Parametri fissi di una singola estrazione KG.
KG_INPUT_MAX_CHARS = int(
    os.getenv(
        "KG_INPUT_MAX_CHARS",
        "2600",
    )
)

KG_NUM_CTX = int(
    os.getenv(
        "KG_NUM_CTX",
        "8192",
    )
)

KG_MAX_OUTPUT_TOKENS = int(
    os.getenv(
        "KG_MAX_OUTPUT_TOKENS",
        "1400",
    )
)

KG_MAX_NODES_PER_WINDOW = int(
    os.getenv(
        "KG_MAX_NODES_PER_WINDOW",
        "20",
    )
)

KG_MAX_EDGES_PER_WINDOW = int(
    os.getenv(
        "KG_MAX_EDGES_PER_WINDOW",
        "30",
    )
)

PDF_TEXT_EXTRACTOR = "fitz"
#PDF_TEXT_EXTRACTOR = os.getenv("PDF_TEXT_EXTRACTOR", "pdfminer").lower()
#PDF_TEXT_EXTRACTOR = os.getenv("PDF_TEXT_EXTRACTOR", "fitz").lower() #<--- OPZIONALE PIù VELOCE
#PDF_TEXT_EXTRACTOR = os.getenv("PDF_TEXT_EXTRACTOR", "fitz").lower()  # fitz | pdfminer

# --- Nella sezione A. GESTIONE FORMULE ---
FULLPAGE_DPI = int(
    os.getenv("FULLPAGE_DPI", "110")
)

CROP_DPI = int(
    os.getenv("CROP_DPI", "160")
)

KG_WORKERS = int(
    os.getenv("KG_WORKERS", "1")
)

kg_executor = ThreadPoolExecutor(
    max_workers=KG_WORKERS
)


CID_RE = re.compile(r"\(cid:\d+\)")

REL_CANON_CACHE_PATH = os.getenv("REL_CANON_CACHE_PATH", "relation_canon_cache.json")
REL_CANON_MAX_TOKENS = int(os.getenv("REL_CANON_MAX_TOKENS", "700"))

RELTYPE_OK = re.compile(r"^[A-Z][A-Z_]{2,60}$")


KG_KEYWORDS = [
    "policy", "procedura", "procedure", "guideline", "standard", "normativa", "framework",
    "rischio", "risk", "vulnerabilità", "minaccia", "threat", "mitigazione",
    "incidente", "incident", "breach", "data breach", "violazione",
    "accesso", "access", "autenticazione", "mfa", "password", "crittografia", "encryption",
    "backup", "restore", "ripristino", "disaster recovery", "business continuity",
    "audit", "assessment", "conformità", "compliance", "non-conformità",
    "asset", "server", "network", "firewall", "log", "monitoraggio",
    "formazione", "training", "awareness", "dipendente", "fornitore", "vendor"
]


# =========================================================
# SEMANTIC GATEKEEPER CONFIG - ASSESSMENT / CYBERSECURITY EDITION
# =========================================================
# Centroidi semantici per catturare lo spettro assessment, compliance e cybersecurity
GATEKEEPER_CONCEPTS = [
    "Information security, ISO 27001, cybersecurity, data protection, confidentiality, integrity, availability, risk assessment, risk treatment, asset management, access control",
    "Compliance, GDPR, NIS2, DORA, regulatory requirements, legal obligations, data privacy, personal data, data breaches, incident response, reporting obligations",
    "IT Governance, policies, procedures, standards, guidelines, organizational structure, roles and responsibilities, segregation of duties, management review",
    "Business Continuity, Disaster Recovery, BCP, DRP, backup strategies, RTO, RPO, resilience, crisis management, redundancy",
    "Technical controls, firewalls, encryption, cryptography, MFA, multi-factor authentication, vulnerability management, patch management, SIEM, logging, monitoring",
    "Physical security, environmental controls, access badges, CCTV, secure areas, clear desk policy, clean screen policy",
    "Human resources security, awareness training, onboarding, offboarding, phishing simulations, NDA, non-disclosure agreements, background checks",
    "Vendor management, third-party risk, SLA, supply chain security, cloud security, SOC 2, audits, continuous monitoring"
]
# Cache per gli embedding delle ancore (calcolati una volta sola all'avvio)
_GK_ANCHOR_EMBEDDINGS = None



###################
# --- NUOVO: Filtro Pagine Strutturali (Junk Filter) ---
STRUCTURAL_PAT = re.compile(
    r"\b(Contents|Index|Bibliography|Acknowledgements|Glossary|Appendix|Reference|Table of Contents|"
    r"Indice|Sommario|Bibliografia|Ringraziamenti|Appendice|Riferimenti)\b",
    re.IGNORECASE
)

def is_structural_page(text: str, p_no: int = 1) -> bool:
    """Rileva se la pagina è junk (indice/sommario), ma risparmia la Pagina 1."""
    if not text: return False
    # La Pagina 1 non è MAI considerata puramente strutturale (contiene il titolo/intro)
    if p_no == 1: return False
    return bool(STRUCTURAL_PAT.search(text[:400]))

def get_entity_density(text: str) -> int:
    """
    Heuristica semplice: conta "candidate entità" (Title Case) che non risultano
    essere parole comuni (lowercase) presenti nello stesso testo.

    Serve solo come gating, quindi deve essere:
    - veloce
    - deterministica
    - stabile
    """
    if not text or len(text) < 20:
        return 0

    clean_text = re.sub(r'# PAGE \d+', '', text)

    # Parole in Title Case (min 3 char)
    potential_entities = re.findall(r'\b[A-ZÀ-Ú][a-zà-ú]{2,}\b', clean_text)

    # Vocabolario "comune" in lowercase (min 3 char)
    common_vocab = set(re.findall(r'\b[a-zà-ú]{3,}\b', clean_text))

    true_entities = {w for w in set(potential_entities) if w.lower() not in common_vocab}
    return len(true_entities)


def count_unique_keywords(text: str) -> int:
    """Conta quanti concetti assessment/compliance diversi sono presenti nel chunk."""
    found = set(_KG_PAT.findall(text))
    return len(found)

# ---- FAST KG GATEKEEPER (NO LLM) ----
_KG_GK_CACHE = {}
_KG_GK_CACHE_MAX = 50000
_PROPER_NOUN_FAST = re.compile(r"\b[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})*\b")


# def con pytorch
def ai_gatekeeper_decision(text: str) -> bool:
    """
    Gatekeeper Semantico (V2):
    Invece di contare keyword, calcola quanto il testo è vicino ai concetti assessment/compliance/cybersecurity.
    """
    if not text or len(text) < KG_MIN_LEN: # Filtro lunghezza minima (es. 250-300 char)
        return False

    global _GK_ANCHOR_EMBEDDINGS
    embedder = get_embedder() # Recupera il modello bge-m3 già caricato

    # 1. Inizializzazione Lazy delle ancore (fatta solo alla prima chiamata)
    if _GK_ANCHOR_EMBEDDINGS is None:
        # print("   🧠 Inizializzazione Semantic Gatekeeper...")
        _GK_ANCHOR_EMBEDDINGS = embedder.encode(GATEKEEPER_CONCEPTS, convert_to_tensor=True)

    # 2. Embedding del Chunk corrente
    # Nota: bge-m3 è molto veloce, su CPU impiega pochi millisecondi per 1000 char
    chunk_embedding = embedder.encode(text, convert_to_tensor=True)

    # 3. Calcolo Similarità (Coseno)
    # Confronta il chunk con TUTTI i concetti e prende il punteggio massimo
    scores = util.cos_sim(chunk_embedding, _GK_ANCHOR_EMBEDDINGS)
    max_score = float(torch.max(scores))

    # 4. Soglia di Decisione
    # 0.35 è solitamente una buona soglia per "vagamente correlato".
    # 0.50 è "molto correlato".
    # Se il testo parla di "cucinare la pasta", lo score sarà < 0.20.
    THRESHOLD = 0.20 

    # Debug (opzionale: scommenta per calibrare la soglia)
    if max_score > 0.3:
       print(f"   [GK] Score: {max_score:.3f} | Text: {text[:50]}...")

    return max_score >= THRESHOLD


def ai_gatekeeper_decision_from_vec(vec, threshold: float = 0.38) -> bool:
    """
    Gatekeeper Semantico (V2) ma usando un embedding già calcolato (NO re-encode).
    vec: np.ndarray | list[float] | torch.Tensor
    """
    global _GK_ANCHOR_EMBEDDINGS

    if vec is None:
        return False

    embedder = get_embedder()

    # Lazy init ancore (una sola volta)
    if _GK_ANCHOR_EMBEDDINGS is None:
        _GK_ANCHOR_EMBEDDINGS = embedder.encode(GATEKEEPER_CONCEPTS, convert_to_tensor=True)

    # vec -> torch tensor (1, dim)
    if not isinstance(vec, torch.Tensor):
        vec_t = torch.tensor(vec, dtype=torch.float32)
    else:
        vec_t = vec.float()

    if vec_t.dim() == 1:
        vec_t = vec_t.unsqueeze(0)

    scores = util.cos_sim(vec_t, _GK_ANCHOR_EMBEDDINGS)
    max_score = float(torch.max(scores))

    if max_score > 0.3:
        print(f"   [GK] Score(vec): {max_score:.3f}")

    return max_score >= threshold



#---------------------

# Compilazione Regex per KG_KEYWORDS (massima efficienza)
# Il prefisso \b assicura il match di parole intere (es. "rate" non matcha "pirate")
_KG_PAT = re.compile(r'\b(' + '|'.join(KG_KEYWORDS) + r')\b', re.IGNORECASE)




# Qdrant
QDRANT_HOST = os.getenv("QDRANT_HOST", "127.0.0.1")
QDRANT_PORT = int(os.getenv("QDRANT_PORT", "6334"))
QDRANT_COLLECTION = os.getenv("QDRANT_COLLECTION", "assessment_docs")

# Postgres
PG_HOST = os.getenv("PG_HOST", "127.0.0.1")
PG_PORT = int(os.getenv("PG_PORT", "5433"))
PG_DB = os.getenv("PG_DB", "assessment_ingestion")

PG_USER = os.getenv("PG_USER", "admin")
PG_PASS = os.getenv("PG_PASS", "admin_password")
PG_MIN_CONN = int(os.getenv("PG_MIN_CONN", "1"))
PG_MAX_CONN = int(os.getenv("PG_MAX_CONN", "8"))


# PostgreSQL Database A: applicazione + schema rag_ingestion + file BYTEA.
# Per requisito usa lo stesso host, porta, utente e password del Database B.
SOURCE_PG_HOST = os.getenv("SOURCE_PG_HOST", PG_HOST)
SOURCE_PG_PORT = int(os.getenv("SOURCE_PG_PORT", str(PG_PORT)))
SOURCE_PG_DB = os.getenv("SOURCE_PG_DB", "assessment_gestio_tier")
SOURCE_PG_USER = os.getenv("SOURCE_PG_USER", PG_USER)
SOURCE_PG_PASS = os.getenv("SOURCE_PG_PASS", PG_PASS)
SOURCE_PG_MIN_CONN = int(os.getenv("SOURCE_PG_MIN_CONN", "1"))
SOURCE_PG_MAX_CONN = int(os.getenv("SOURCE_PG_MAX_CONN", "4"))

INGESTION_WORKER_ID = (
    os.getenv("INGESTION_WORKER_ID", "worker-ingestion-01").strip()
    or "worker-ingestion-01"
)
JOB_HEARTBEAT_SECONDS = max(
    10,
    int(os.getenv("JOB_HEARTBEAT_SECONDS", "60")),
)
JOB_RETRY_DELAY = (
    os.getenv("JOB_RETRY_DELAY", "15 minutes").strip()
    or "15 minutes"
)

DB_MAX_JOBS_PER_RUN = max(0, int(os.getenv("DB_MAX_JOBS_PER_RUN", "100")))


#DB_MAX_JOBS_PER_RUN = max(
#    0,
#    int(os.getenv("DB_MAX_JOBS_PER_RUN", "0")),
#)

# Neo4j
NEO4J_URI = os.getenv("NEO4J_URI", "bolt://127.0.0.1:7688")
NEO4J_USER = os.getenv("NEO4J_USER", "neo4j")
NEO4J_PASS = os.getenv("NEO4J_PASS", "admin_password")
NEO4J_ENABLED = os.getenv("NEO4J_ENABLED", "1") == "1"

# LM Studio / OpenAI-compatible
#LM_BASE_URL = os.getenv("LM_BASE_URL", "http://127.0.0.1:1234/v1")
#LM_API_KEY = os.getenv("LM_API_KEY", "lm-studio")


#qwen3-8b-gguf:latest
#LLM_MODEL_NAME = os.getenv("LLM_MODEL_NAME", "qwen3-vl-8b-instruct")

#LLM_MODEL_NAME = os.getenv("LLM_MODEL_NAME", "gemma2:9b") 
#LLM_MODEL_NAME = os.getenv("LLM_MODEL_NAME", "qwen2.5:7b") 
#LLM_MODEL_NAME = os.getenv("LLM_MODEL_NAME", "qwen2.5:14b") 
#LLM_MODEL_NAME = os.getenv("LLM_MODEL_NAME", "llama3.1:8b") 

#VISION_MODEL_NAME = os.getenv("VISION_MODEL_NAME", "llama3.1:8b")
#VISION_MODEL_NAME = os.getenv("VISION_MODEL_NAME", "qwen3.5:9b")
#VISION_MODEL_NAME = os.getenv("VISION_MODEL_NAME", "ministral-3:8b")



LLM_MODEL_NAME = os.getenv("LLM_MODEL_NAME", "llama3.1:8b")
VISION_MODEL_NAME = os.getenv("VISION_MODEL_NAME", "ministral-3:8b")


OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")

OLLAMA_API_GENERATE = os.getenv(
    "OLLAMA_API_GENERATE",
    f"{OLLAMA_BASE_URL}/api/generate"
)

OLLAMA_API_CHAT = os.getenv(
    "OLLAMA_API_CHAT",
    f"{OLLAMA_BASE_URL}/api/chat"
)

OLLAMA_API_TAGS = os.getenv(
    "OLLAMA_API_TAGS",
    f"{OLLAMA_BASE_URL}/api/tags"
)

USE_REMOTE_OLLAMA = os.getenv("USE_REMOTE_OLLAMA", "0") == "1"
OLLAMA_AUTOSTART = os.getenv("OLLAMA_AUTOSTART", "1") == "1"




# Embeddings
#EMBEDDING_MODEL_NAME = os.getenv("EMBEDDING_MODEL_NAME", "BAAI/bge-m3")

EMBEDDING_MODEL_NAME = os.getenv("EMBEDDING_MODEL_NAME", "E:/Modelli/bge-m3")

#EMBEDDING_MODEL_NAME = os.getenv(
#    "EMBEDDING_MODEL_NAME",
#    "/workspace/models/bge-m3"
#)


QDRANT_TEXT_MAX_CHARS = int(os.getenv("QDRANT_TEXT_MAX_CHARS", "2500"))
# Timeout HTTP del client Qdrant. Il default del client è troppo breve per
# create_payload_index/upsert con wait=True su Docker e può produrre "timed out".
QDRANT_TIMEOUT_S = int(os.getenv("QDRANT_TIMEOUT_S", "120"))

# LLM reliability
LLM_MAX_TOKENS = int(os.getenv("LLM_MAX_TOKENS", "1300"))
LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.1"))
LLM_RETRIES = int(os.getenv("LLM_RETRIES", "2"))


# =========================
# CLIENTS INIT (LAZY)
# =========================
openai_client = None
embedder = None
qdrant_client = None

def get_embedder():
    global embedder
    if embedder is None:
        # device="cpu" evita conflitti di memoria con Ollama
        embedder = SentenceTransformer(EMBEDDING_MODEL_NAME, device="cpu")
    return embedder

def get_qdrant_client():
    global qdrant_client
    if qdrant_client is None:
        qdrant_client = QdrantClient(
            host=QDRANT_HOST,
            port=QDRANT_PORT,
            timeout=QDRANT_TIMEOUT_S,
        )
    return qdrant_client

neo4j_driver = None
if NEO4J_ENABLED:
    try:
        neo4j_driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASS))
    except Exception as e:
        print(f"⚠️ Neo4j disabled (driver init failed): {e}")
        NEO4J_ENABLED = False

pg_pool = ThreadedConnectionPool(
    PG_MIN_CONN, PG_MAX_CONN,
    host=PG_HOST, port=PG_PORT, dbname=PG_DB,
    user=PG_USER, password=PG_PASS
)


source_pg_pool = ThreadedConnectionPool(
    SOURCE_PG_MIN_CONN,
    SOURCE_PG_MAX_CONN,
    host=SOURCE_PG_HOST,
    port=SOURCE_PG_PORT,
    dbname=SOURCE_PG_DB,
    user=SOURCE_PG_USER,
    password=SOURCE_PG_PASS,
)

# ==============================================================================
# PROMPT VISIONE UNIVERSALE (Vision Supremacy)
# ==============================================================================
FORMULA_VISION_PROMPT = """
You are a Scientific OCR Engine.
Your task is to transcribe mathematical content from the image into structured JSON with LaTeX.

### INPUT SOURCE HANDLING:
- **Text Layer**: If you see garbled text, reconstruction it into valid math.
- **Vector/Image**: Transcribe graphical formulas exactly as they appear.

### RULES:
1. **LATEX MANDATORY**: Use standard LaTeX for all math (e.g., `\\frac{a}{b}`, `\\int`, `\\sum`, `\\sigma`).
2. **FIDELITY**: Transcribe EXACTLY symbols found in the image. Do not hallucinate formulas not present.
3. **NO ASCII MATH**: Do not use "x^2". Use "$x^2$".

### OUTPUT FORMAT (JSON ONLY):
{
  "summary_it": "Breve descrizione del contenuto matematico (es. 'Equazione differenziale', 'Modello statistico').",
  "formulas": [
    {
      "description_it": "Nome o etichetta visibile (es. 'Eq. 1.2' o 'Definizione')",
      "latex": " ... write here the LaTeX code inside dollars, e.g. $a + b = c$ ... ", 
      "variables": [
        {"name": "symbol", "meaning": "variable meaning (if context allows) or 'unknown'"}
      ]
    }
  ]
}
"""

CHART_VISION_PROMPT = """
You are a SENIOR COMPLIANCE & CYBERSECURITY AUDITOR AI.
Your goal: Extract precise data and strategic insights from charts, tables, screenshots, risk matrices, control matrices, diagrams, dashboards, and evidence artifacts in audit reports and security assessments.

CONTEXT: The user is performing an assessment and needs evidence about risks, controls, compliance status, incidents, vulnerabilities, assets, owners, dates, remediation status, and security KPIs.

ABSOLUTE PROHIBITIONS:
- Do NOT invent numbers. If a value is not explicitly labeled or readable, write "NOT READABLE".
- Do NOT infer compliance status unless it is visible or explicitly stated.
- Do NOT ignore negative signs, percentages, dates, severity labels, SLA labels, or open/closed status.
- Do NOT use terminology from unrelated domains unless it is explicitly present in the document.

Return ONLY valid JSON (no markdown), EXACT schema:

{
  "kind": "line_chart|bar_chart|pie|table|heatmap|risk_matrix|control_matrix|network_diagram|process_flow|dashboard|screenshot|other",
  "title": "Exact chart/table/diagram title if visible, e.g., 'Vulnerability Remediation Status'",
  "subtitle": "Subtitle including scope, unit, population, or assessment period if visible",
  "source": "Source if visible, e.g., 'Internal Audit', 'SIEM Export', 'Vulnerability Scanner', 'GRC Tool', or 'NOT READABLE'",
  "timeframe": "Explicit period, date, quarter, audit window, or 'NOT READABLE'",

  "what_is_visible_it": "Descrizione in ITALIANO della struttura visuale: matrice rischi, tabella controlli, dashboard KPI, diagramma di rete, flusso di processo, screenshot di evidenza, ecc.",
  
  "analysis_it": "Sintesi professionale in 3 frasi in ITALIANO. Concentrati su severità del rischio, efficacia dei controlli, gap di conformità, finding aperti/chiusi, asset coinvolti, trend incidenti/vulnerabilità e priorità di remediation.",
  
  "data_table_md": "| Category | Metric | Value | Status |\n|---|---:|---:|---|\n| Access Control | MFA Coverage | 78% | Partial |\n| Vulnerability Management | Critical Open Findings | 12 | High Risk |",

  "observations_it": [
    "Fact 1: identifica valori massimi/minimi, severità, controlli scoperti, finding aperti o asset più esposti.",
    "Fact 2: annota percentuali, conteggi, SLA, date, owner, stato di remediation o maturity level se visibili.",
    "Fact 3: segnala se l'evidenza è incompleta, non leggibile o non sufficiente a dimostrare conformità."
  ],
  
  "visual_trends_it": ["Descrivi trend o distribuzioni: aumento/diminuzione incidenti, concentrazione per severità, copertura controlli, stato remediation, heatmap rischio."],

  "legend_it": {
    "is_readable": true,
    "mapping": [{"label": "Critical", "color_or_style": "Red"}, {"label": "Implemented", "color_or_style": "Green"}]
  },
  
  "numbers": [
    {
      "label": "Control/Risk/Asset/Process category, e.g., 'Access Control'",
      "value": "Exact value read, e.g., '78%' or '12'",
      "unit": "Count, %, score, severity, maturity level, SLA days, or textual status",
      "period": "Date, audit period, or time reference if visible"
    }
  ],
  "confidence": 0.0
}
"""

# ==============================================================================
# PROMPT: VISION-FIRST (PAGE-TO-MARKDOWN)
# ==============================================================================
# Questo prompt istruisce Ministral a trascrivere tutto in un unico flusso Markdown.
# È cruciale per catturare grafici e tabelle nel contesto del testo.
# ==============================================================================
# PROMPT VISIONE (Vision-First v2 - ASSESSMENT VISUAL HUNTER)
# ==============================================================================
VISION_FIRST_PROMPT = r"""
You are a Compliance and IT Security Analyst with Computer Vision capabilities.
Your goal is to transcribe text AND deeply analyze visual evidence used in cybersecurity, compliance, privacy, and IT audit assessments.

PAGE ANALYSIS PROTOCOL:

1. **SCAN FOR ASSESSMENT VISUALS FIRST**: Look immediately for risk heatmaps, control matrices, audit finding tables, compliance dashboards, maturity charts, incident timelines, vulnerability charts, network diagrams, architecture diagrams, process flows, asset inventories, screenshots of configurations/logs, and organizational charts.
   - If found, you MUST insert a detailed description block using this EXACT format:
   
   > **### 🖼️ VISUAL ANALYSIS: [Title/Type of Assessment Visual]**
   > *Visual Elements:* Describe matrices, columns, rows, nodes, arrows, colors, severities, statuses, owners, dates, controls, risks, assets, or systems.
   > *Data Insights:* Describe risk levels, severity distributions, control coverage, compliance gaps, open/closed findings, maturity levels, affected assets, dates, owners, and evidence status.
   > *Context:* Relate the visual to surrounding text labels, captions, page titles, control IDs, framework references, or figure numbers.

2. **TEXT TRANSCRIPTION**: After looking for visuals, transcribe all text headers and paragraphs exactly.
3. **TABLES**: Transcribe tables using Markdown pipes (|), preserving control IDs, owners, status, risk rating, evidence, dates, and remediation fields when visible.
4. **FORMULAS / METRICS**: Use Unicode symbols or LaTeX-like notation only when formulas or scoring rules are explicitly visible.

STRICT RULES:
- **DO NOT IGNORE IMAGES**: Even if they contain text labels, treat them as assessment evidence to describe.
- **DO NOT INVENT COMPLIANCE**: If a control, owner, date, risk level, or evidence status is not visible, state that it is not readable/available.
- **Merge** the visual description naturally into the reading order where the image appears.
- Output ONLY Markdown.
"""



CHART_ANALYST_PROMPT = """
You are an expert compliance, cybersecurity, privacy, and IT risk analyst for a RAG system.
Your task is to analyze structured data (JSON) from a chart/table/diagram/screenshot and the surrounding page context to generate a discursive description in ENGLISH for semantic retrieval.

INPUT:
A JSON object containing:
1. "vision_json": Visually extracted data (title, values, trends, data table, risk/control/evidence details).
2. "page_text": The surrounding PDF page text (for context).

INSTRUCTIONS:
1. Synthesize in ITALIAN what the visual artifact demonstrates for the assessment.
2. Explicitly integrate visible numbers, dates, statuses, severities, controls, risks, owners, assets, and evidence references found in "vision_json" (e.g., "MFA coverage is 78% and status is Partial").
3. If "data_table_md" is present, use it to describe key data points.
4. Describe visual trends such as risk concentration, vulnerability severity distribution, control coverage, remediation progress, incident trend, maturity level, or compliance gap.
5. Be concise but information-dense to facilitate semantic search.

DO NOT invent numbers, assets, controls, owners, dates, or compliance conclusions. If data is scarce, write: "Visual analysis limited due to low resolution."
"""


CHART_RECONCILE_PROMPT = """
You receive:
(A) PAGE_TEXT (raw text from PDF layer)
(B) VISION_JSON (chart/table extraction)

Task:
- Merge ONLY factual, consistent information.
- Never add numbers/series not present in VISION_JSON.
- You may add labels from PAGE_TEXT only if explicitly stated.

Return ONLY valid JSON with the SAME schema as VISION_JSON.
"""

KG_PROMPT = """You are an expert Compliance Auditor, Cybersecurity Analyst, and Data Engineer.
Extract entities and relationships from the text for an assessment-oriented Knowledge Graph.

TAXONOMY (You MUST choose one of these for the 'category' field):
- ORGANIZATION (e.g., Company, Department, Third-Party)
- PERSON (e.g., CISO, DPO, Employee, Process Owner)
- POLICY_OR_PROCEDURE (e.g., Password Policy, Incident Response Plan, Backup Procedure)
- CONTROL (e.g., MFA, Firewall, Encryption, Backup, Logging, Segregation of Duties)
- RISK (e.g., Data Loss, Unauthorized Access, Cyber Attack, Service Unavailability)
- EVIDENCE (e.g., Audit Log, Review Minutes, Vulnerability Scan, Configuration Screenshot)
- ASSET (e.g., Server, Database, Workstation, Network, Application, Cloud Service)
- REGULATION (e.g., GDPR, ISO 27001, NIS2, DORA, NIST)
- CONCEPT (e.g., Confidentiality, Integrity, Availability, Business Continuity)

PROPERTIES (You MUST populate the 'props' object):
- 'description': A brief definition in Italian or in the document language (max 20 words).
- 'formula': The mathematical/risk/scoring formula if explicitly mentioned in the text (otherwise leave empty).
- 'synonyms': Array of alternative names or acronyms explicitly present in the text (e.g., ["MFA", "Multi-Factor Authentication"]).

RELATION VOCABULARY (Prefer these UPPERCASE relation types):
- IS_A, PART_OF, HAS_COMPONENT, APPLIES_TO, BELONGS_TO
- COMPLIES_WITH, VIOLATES, MANDATES, GOVERNS, APPROVES, REVIEWS
- MITIGATES, THREATENS, EXPLOITS, PROTECTS, VULNERABLE_TO
- IMPLEMENTS, GENERATES, VERIFIES, TESTS, REQUIRES, DEPENDS_ON

Return ONLY valid JSON with this exact schema:
{
  "nodes": [
    {
      "id": "Specific assessment entity (e.g., Multi-Factor Authentication)",
      "category": "CONTROL",
      "props": {
        "description": "Controllo che richiede più fattori di autenticazione.",
        "formula": "",
        "synonyms": ["MFA"]
      }
    }
  ],
  "edges": [
    {
      "source": "Multi-Factor Authentication",
      "target": "Unauthorized Access",
      "relation": "MITIGATES",
      "props": {
        "evidence": "Il testo indica che MFA riduce il rischio di accesso non autorizzato."
      }
    }
  ]
}
"""



REL_CANON_PROMPT = """
You are a relation-type canonicalizer for a cybersecurity, compliance, privacy, IT audit, and regulatory assessment knowledge graph.

INPUT: a JSON array of relation types.

OUTPUT: ONLY valid JSON, no markdown, no comments. Schema:
{
  "map": {
    "<RAW>": {
      "verb": "<UPPERCASE_CANONICAL_RELATION>",
      "object": "<ASSESSMENT_OBJECT_OR_EMPTY>",
      "qualifier": "<QUALIFIER_OR_EMPTY>"
    }
  }
}

CANONICAL RELATION VOCABULARY:

STRUCTURE:
- IS_A
- PART_OF
- HAS_COMPONENT
- CONTAINS
- BELONGS_TO
- APPLIES_TO
- MAPS_TO
- DEFINES
- CLASSIFIES

GOVERNANCE / COMPLIANCE:
- COMPLIES_WITH
- NON_COMPLIANT_WITH
- HAS_COMPLIANCE_STATUS
- HAS_GAP
- REQUIRES_REMEDIATION
- REMEDIATES
- MANDATES
- REQUIRES
- GOVERNS
- APPROVES
- REVIEWS
- ASSIGNS_RESPONSIBILITY_TO

INCIDENT / PROCESS:
- TRIGGERS
- ACTIVATES
- STARTS
- FOLLOWS
- PRECEDES
- LEADS_TO
- ESCALATES_TO
- MANAGES
- HANDLES
- CONTAINS_INCIDENT
- ERADICATES
- RECOVERS
- CLOSES
- IMPROVES

NOTIFICATION / AUTHORITY:
- NOTIFIES
- REPORTS_TO
- RECEIVES_NOTIFICATION
- REQUIRES_NOTIFICATION_TO
- HAS_DEADLINE
- HAS_RECIPIENT
- COMMUNICATES_TO

FRAMEWORK:
- SUPPORTS
- ENABLES
- IMPLEMENTS
- DEPENDS_ON
- ALIGNS_WITH
- CONTRIBUTES_TO
- MEASURES
- MONITORS

RISK / SECURITY:
- MITIGATES
- REDUCES
- THREATENS
- EXPLOITS
- PROTECTS
- VULNERABLE_TO
- COMPROMISES
- IMPACTS
- AFFECTS
- EXPOSES

AUDIT / EVIDENCE:
- GENERATES
- VERIFIES
- TESTS
- DEMONSTRATES
- DOCUMENTS
- SUPPORTS_EVIDENCE_FOR

NORMALIZATION RULES:
- COMPLIANT, COMPLIES, COMPLY, CONFORME_A, CONFORMITY_WITH -> COMPLIES_WITH
- NON_COMPLIANT, NON_COMPLIANCE, NON_CONFORMITY, NOT_COMPLIANT, GAP_WITH, VIOLATES -> NON_COMPLIANT_WITH
- STATUS, COMPLIANCE_STATUS, IMPLEMENTATION_STATUS, MATURITY_STATUS -> HAS_COMPLIANCE_STATUS
- GAP, HAS_FINDING, HAS_DEFICIENCY, HAS_WEAKNESS -> HAS_GAP
- REMEDIATION_REQUIRED, NEEDS_REMEDIATION, REQUIRES_CORRECTIVE_ACTION -> REQUIRES_REMEDIATION
- REMEDIATES, CORRECTS, CLOSES_GAP -> REMEDIATES
- NOTIFICATION_TO, SENDS_NOTIFICATION_TO, MUST_NOTIFY -> NOTIFIES
- REPORT_TO, REPORTS, ESCALATES_REPORT_TO -> REPORTS_TO
- DEADLINE, TIME_LIMIT, WITHIN_HOURS, WITHIN_DAYS -> HAS_DEADLINE
- RESPONSIBLE, ACCOUNTABLE, OWNER, ASSIGNED_TO -> ASSIGNS_RESPONSIBILITY_TO

RULES:
- "verb" MUST be one of the canonical relations above.
- If RAW already matches one canonical relation, return it unchanged as verb.
- Put extra trailing tokens, phase names, dates, or status labels into qualifier.
- If unsure, use DEFINES for definitional relations, APPLIES_TO for scope relations, or SUPPORTS_EVIDENCE_FOR for evidence relations.
- Never invent unrelated objects.
- If no object is explicit, leave object empty.

Return JSON only.
"""



CHART_DATA_PROMPT = """
You are a Lead Data Scientist specializing in Security and Audit Dashboard Reconstruction.
Your goal is to extract the EXACT underlying data table from the chart/diagram image.

### PHASE 1: STRUCTURAL ANCHORING (CRITICAL)
1. **Identify the MAIN CATEGORIES (X-Axis)**:
   - Look at the labels *under* the groups of bars.
   - Examples: "Q1, Q2, Q3", "Critical, High, Medium", "Access Control". 
   - *Constraint*: These are the Row Headers.
2. **Identify the SERIES LEGEND (Sub-groups)**:
   - Look for the text that distinguishes the bars *within* a single category.
   - *Visual Cue*: Are there dates (e.g., "2023", "2024") written below/inside the bars?
   - *Visual Cue*: Is there a color legend (e.g., "Red=Open Incidents, Green=Resolved")?
   - *Constraint*: These are the Column Headers.
3. **Determine Cluster Size (N)**:
   - Count how many bars exist for the first category.
   - If a category has 2 bars, N=2. You MUST extract exactly 2 values for every other category.

### PHASE 2: PRECISION EXTRACTION
For EACH Main Category found:
1. **Locate**: Focus on the cluster of bars for that category.
2. **Measure**: Trace the top of each bar to the Y-Axis value. 
   - *Interpolate*: If a bar is between 20 and 40, it is likely 30.
   - *Ordering*: Extract values in the logical order of the Series.
3. **Values**: Return specific numbers. DO NOT return arrays of random numbers.

### PHASE 3: OUTPUT JSON
Return VALID JSON:
{
  "title": "Chart Title",
  "chart_type": "Clustered Bar / Stacked Bar / Line / Heatmap",
  "series_discriminators": "The exact labels for the series (e.g., '2023, 2024').",
  "data_points": [
    {
      "category": "Main Axis Label (e.g. Critical Vulnerabilities)",
      "visual_check": "Short description (e.g. 'Red bar (high)')", 
      "value": "val1, val2" 
    }
  ]
}
"""

# ==============================================================================
# NUOVO PROMPT: FULL PAGE TO MARKDOWN (LaTeX Native)
# ==============================================================================
MARKER_VISION_PROMPT = """
You are an advanced AI conversion engine (OCR + Layout Analysis).
Your task: Convert this document image into clean, structured MARKDOWN.

RULES FOR MATHEMATICS (CRITICAL):
1. Identify ALL mathematical formulas, equations, and symbols.
2. Transcribe them EXACTLY into LaTeX format enclosed in single dollars ($...$) for inline or double dollars ($$...$$) for block equations.
3. Example: Convert "Risk = Impact * Likelihood" into "$$Risk = Impact \times Likelihood$$".
4. Do NOT output ascii math (like x^2). ALWAYS use LaTeX ($x^2$).

RULES FOR STRUCTURE:
1. Preserve headers (###), lists, and tables (using Markdown | col | col |).
2. Ignore page footers, page numbers, and copyright disclaimers.
3. If the text is garbled in the image, infer the correct words based on context.

OUTPUT ONLY THE MARKDOWN. NO CONVERSATIONAL FILLER.
"""

# =========================
# UTILS
# =========================
# --- Vision stats (thread-safe) ---
VISION_STATS = {
    "pages_total": 0,
    "pages_with_imgs": 0,
    "pages_crop_only": 0,
    "pages_fullpage": 0,
}

_VISION_STATS_LOCK = Lock()

# --- UTILITY DI PULIZIA E FILTRAGGIO MD ---


def embedded_image_is_vision_candidate(
    image_bytes: bytes,
    width: int,
    height: int,
) -> bool:
    """
    Filtro deterministico prima di chiamare Vision.

    Esclude:
    - icone e loghi;
    - immagini troppo piccole;
    - banner con rapporto dimensionale estremo;
    - fondi quasi uniformi.
    """
    if (
        not image_bytes
        or len(image_bytes) < MIN_ASSET_SIZE
    ):
        return False

    width = int(width or 0)
    height = int(height or 0)

    if (
        width < PDF_EMBEDDED_MIN_WIDTH
        or height < PDF_EMBEDDED_MIN_HEIGHT
        or (width * height) < PDF_EMBEDDED_MIN_AREA
    ):
        return False

    short_side = max(
        1,
        min(width, height),
    )

    long_side = max(
        width,
        height,
    )

    aspect_ratio = (
        long_side / short_side
    )

    if (
        aspect_ratio
        > PDF_EMBEDDED_MAX_ASPECT_RATIO
    ):
        return False

    try:
        import io
        from PIL import Image

        with Image.open(
            io.BytesIO(image_bytes)
        ) as image:
            gray = image.convert("L")

            min_luma, max_luma = (
                gray.getextrema()
            )

        tonal_range = (
            max_luma - min_luma
        )

        if (
            tonal_range
            < PDF_EMBEDDED_MIN_TONAL_RANGE
        ):
            return False

    except Exception:
        # Un errore PIL non deve bloccare
        # l'intera ingestion.
        pass

    return True


def ai_vision_gatekeeper(
    image_bytes: bytes,
) -> bool:
    """
    Wrapper retrocompatibile per i vecchi
    percorsi che non dispongono di width/height.
    """
    return bool(
        image_bytes
        and len(image_bytes) >= MIN_ASSET_SIZE
    )

    

def clean_markdown_structure(md_content: str) -> str:
    """Rimuove sezioni strutturali pesanti (Indici, Sommari) e rumore web."""
    sections = re.split(r'(\n#+ .*)', md_content)
    cleaned_sections = []
    start_idx = 0
    if len(sections) > 1 and len(sections[0].strip()) < 300:
        start_idx = 2 
        
    for i in range(start_idx, len(sections)):
        section_text = sections[i]
        if bool(STRUCTURAL_PAT.search(section_text[:400])):
            continue
        section_text = re.sub(r'https?://\S+', '', section_text)
        section_text = re.sub(r'\S+@\S+', '', section_text)
        cleaned_sections.append(section_text)
    return "".join(cleaned_sections)

def set_toon_type(chunk: dict, *, is_image: bool) -> dict:
    chunk["toon_type"] = "image" if is_image else "text"
    return chunk


def fast_chunk_text(text: str, max_tokens: int = 2000) -> List[str]:
    """
    Divide il testo in chunk basati su una stima dei token (1 tok ~= 4 char).
    - Veloce (nessun tokenizer pesante).
    - Rispetta i confini delle parole/frasi.
    - Include un overlap automatico per continuità semantica.
    """
    if not text:
        return []
    
    # Stima caratteri: OpenAI usa circa 4 char per token in media
    chunk_size_char = max_tokens * 4
    overlap_char = int(chunk_size_char * 0.1)  # 10% overlap
    
    text_len = len(text)
    if text_len <= chunk_size_char:
        return [text]
        
    chunks = []
    start = 0
    
    while start < text_len:
        # Definiamo il punto di fine teorico
        end = min(start + chunk_size_char, text_len)
        
        # Se non siamo alla fine assoluta del testo, cerchiamo un punto di taglio "morbido"
        if end < text_len:
            # Cerchiamo l'ultimo 'a capo' o 'spazio' prima del limite
            # Questo evita di troncare parole a metà es: "ingegner" | "ia"
            search_window = text[start:end]
            
            # Preferenza 1: Tagliare su un doppio a capo (fine paragrafo)
            last_break = search_window.rfind('\n\n')
            
            # Preferenza 2: Tagliare su un singolo a capo
            if last_break == -1:
                last_break = search_window.rfind('\n')
                
            # Preferenza 3: Tagliare su uno spazio (ultima risorsa)
            if last_break == -1:
                last_break = search_window.rfind(' ')
            
            # Se abbiamo trovato un punto valido nella seconda metà del chunk, usiamolo
            # (Se è troppo presto, meglio tagliare brutale che fare un chunk minuscolo)
            if last_break != -1 and last_break > (chunk_size_char * 0.5):
                end = start + last_break + 1  # +1 per includere il carattere di stop
        
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
            
        # Calcolo del prossimo start con overlap
        # Se siamo alla fine, usciamo
        if end >= text_len:
            break
            
        # Torniamo indietro di 'overlap' caratteri, ma senza superare l'inizio attuale
        start = max(start + 1, end - overlap_char)

    return chunks

def page_has_vector_graphics(page: fitz.Page) -> bool:
    """
    Heuristica: se la pagina contiene molti 'drawings' (linee/rect/path),
    è molto probabile che ci sia un grafico vettoriale.
    """
    try:
        drawings = page.get_drawings()
        if not drawings:
            return False
        # Conteggio totale items (path ops)
        ops = 0
        for d in drawings:
            items = d.get("items") or []
            ops += len(items)
        # Soglia: alza/abbassa se necessario (20-60 tipico)
        return ops >= 20
    except Exception:
        return False



def extract_markdown_chunks(file_path: str, log_id: int) -> List[Dict[str, Any]]:
    """
    Estrattore ad alte prestazioni per file Markdown.
    Gestisce l'auto-cleaning e la Vision AI chirurgica.
    FIX: Include sub-chunking per paragrafi giganti (evita errori 0 nodi).
    """
    out_chunks = []
    filename = os.path.basename(file_path)
    
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            raw_content = f.read()

        # 1. AUTO-CLEANING
        content = clean_markdown_structure(raw_content)

        # 2. CHUNKING STRUTTURATO (Macro-divisione)
        raw_paras = re.split(r'\n(?=# )|\n\n', content)
        
        for idx, macro_para in enumerate(raw_paras):
            macro_para = macro_para.strip()
            if len(macro_para) < MIN_CHUNK_LEN:
                continue
            
            # ### FIX 1: Gestione Vision AI (spostata prima del sub-chunking)
            # Analizziamo l'immagine una volta sola per il "macro blocco"
            vision_metadata = {}
            img_matches = re.findall(r'!\[.*?\]\((.*?)\)', macro_para)
            
            if img_matches and PDF_VISION_ENABLED:
                # ... (TUA LOGICA VISION INVARIATA) ...
                try:
                    img_path = img_matches[0]
                    full_img_path = os.path.join(os.path.dirname(file_path), img_path)
                    
                    if os.path.exists(full_img_path) and os.path.getsize(full_img_path) > 5000:
                        with open(full_img_path, "rb") as img_f:
                            img_bytes = img_f.read()
                        
                        CHART_MIN_CONF = float(os.getenv("CHART_MIN_CONF", "0.55"))
                        c_js = extract_chart_via_vision(img_bytes)
                        
                        conf = float((c_js or {}).get("confidence") or 0.0)

                        if c_js and c_js.get("kind") != "other" and conf >= CHART_MIN_CONF:
                            # Salviamo i dati per iniettarli nel primo sub-chunk
                            vision_metadata = {
                                "chart_semantic": build_chart_semantic_chunk(1, c_js),
                                "metadata_override": c_js
                            }
                            print(f"   📝 Analisi Semantica Chart (conf={conf:.2f})")
                        else:
                            # Salvataggio Postgres (Asset Management)
                            conn = pg_get_conn()
                            try:
                                with conn.cursor() as cur:
                                    pg_save_image(log_id, img_bytes, "image/jpeg", f"MD_{filename}_{idx}", cur)
                                conn.commit()
                            finally:
                                pg_put_conn(conn)
                except Exception as e_img:
                    print(f"   ⚠️ Vision Error: {e_img}")


            # ### FIX 2: SUB-CHUNKING DI SICUREZZA
            # Se il paragrafo è > 1024 token, lo spezziamo ancora, altrimenti l'LLM fallisce.
            # Se è piccolo, fast_chunk_text ritorna una lista con 1 solo elemento (invariato).
            sub_chunks_text = fast_chunk_text(macro_para, max_tokens=1024)
            for sub_i, txt in enumerate(sub_chunks_text):

                current_text_sem = f"Doc: {filename} | Sezione: {txt[:60]}...\n{txt}"
                current_meta = {}

                if sub_i == 0 and vision_metadata:
                    current_text_sem = vision_metadata["chart_semantic"] + "\n\n" + current_text_sem
                    current_meta = vision_metadata.get("metadata_override", {})

                synthetic_page_no = idx + 1

                chunk_data = {
                    "text_raw": txt,
                    "text_sem": current_text_sem,
                    "page_no": synthetic_page_no,
                    "toon_type": "text" if not (sub_i == 0 and vision_metadata) else "chart_analysis",
                    "section_hint": txt[:80] if txt.startswith("#") else f"section_{synthetic_page_no}_part_{sub_i+1}",
                    "metadata": {
                        **current_meta,
                        "source": filename,
                        "source_format": "markdown",
                        "synthetic_page": synthetic_page_no,
                        "macro_section_index": idx,
                        "sub_chunk_index": sub_i,
                    }
                }

                # Se c'era un metadata override (es. grafico), assicurati che sia nel payload
                if "metadata_override" in vision_metadata and sub_i == 0:
                     chunk_data["metadata_override"] = vision_metadata["metadata_override"]

                out_chunks.append(chunk_data)
            
        print(f"   📄 Markdown Ingested: {len(out_chunks)} chunk validi.")
        return out_chunks

    except Exception as e:
        print(f"   ❌ Errore durante l'estrazione Markdown: {e}")
        import traceback
        traceback.print_exc()
        return []

def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()





def force_unload_ollama(model_name: str):
    """
    Forza lo scaricamento del modello dall'istanza Ollama configurata.
    Funziona sia con Ollama locale sia con Ollama remoto.
    """
    if not model_name:
        return

    try:
        payload = {
            "model": model_name,
            "prompt": "",
            "keep_alive": 0,
        }

        requests.post(
            OLLAMA_API_GENERATE,
            json=payload,
            timeout=10,
        )

        time.sleep(2.0)

    except Exception:
        pass




def force_restart_ollama(num_parallel: str = "1") -> bool:
    """
    Riavvia Ollama su Windows ottimizzando l'uso VRAM.

    Parametri:
    - num_parallel: numero di richieste parallele gestite da Ollama.
      Per GPU da 16GB è consigliato "1".
    """

    print(f"🔄 Resetting Ollama Server (Target Parallelism={num_parallel})...")

    # 1) Termina eventuali processi Ollama attivi
    for process_name in ("ollama.exe", "ollama_app.exe"):
        try:
            subprocess.run(
                ["taskkill", "/f", "/im", process_name],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False
            )
        except Exception:
            pass

    time.sleep(3)

    # 2) Configura variabili ambiente
    env = os.environ.copy()
    env["OLLAMA_NUM_PARALLEL"] = str(num_parallel)
    env["OLLAMA_MAX_LOADED_MODELS"] = "2"
    env["OLLAMA_FLASH_ATTENTION"] = "1"

    # 3) Individua eseguibile Ollama
    ollama_path = shutil.which("ollama")

    if not ollama_path:
        ollama_path = os.path.expandvars(
            r"%LOCALAPPDATA%\Programs\Ollama\ollama.exe"
        )

    if not os.path.exists(ollama_path):
        print(f"❌ Ollama non trovato nel percorso: {ollama_path}")
        return False

    print(f"🚀 Starting Ollama from: {ollama_path}")

    # 4) Avvia il server Ollama
    try:
        subprocess.Popen(
            [ollama_path, "serve"],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
            shell=False
        )
    except Exception as e:
        print(f"❌ Errore critico nell'avvio di Ollama: {e}")
        return False

    # 5) Healthcheck
    for i in range(20):
        try:
            res = requests.get(
                "http://127.0.0.1:11434/api/tags",
                timeout=2
            )

            if res.status_code == 200:
                print(f"✨ Ollama is READY (Parallel={num_parallel})")
                return True

        except requests.RequestException:
            print(f"...waiting for server ({i + 1}/20)")
            time.sleep(1)

    print("⚠️ Ollama non ha risposto entro il timeout.")
    return False



def ensure_ollama_parallel(num_parallel="4"):
    """
    Imposta le variabili d'ambiente e avvia il server Ollama.
    """
    # 1. Imposta la variabile d'ambiente per il processo Python e i suoi figli
    os.environ["OLLAMA_NUM_PARALLEL"] = num_parallel
    os.environ["OLLAMA_MAX_LOADED_MODELS"] = "2" # Ottimizza la VRAM
    
    print(f"🚀 Configurazione Ollama: NUM_PARALLEL={num_parallel}")

    # 2. Verifica se Ollama è già attivo
    try:
        response = requests.get("http://localhost:11434/api/tags", timeout=2)
        if response.status_code == 200:
            print("   ✅ Ollama è già in esecuzione. Nota: se non è stato avviato con NUM_PARALLEL, i thread saranno sequenziali.")
            return
    except requests.exceptions.ConnectionError:
        print("   ⚠️ Server Ollama non trovato. Avvio in corso...")

    # 3. Avvio del server come processo in background (subprocess.Popen)
    # 'ollama serve' rimarrà attivo mentre lo script prosegue
    subprocess.Popen(
        ["ollama", "serve"],
        env=os.environ, # Passa le variabili d'ambiente impostate sopra
        stdout=subprocess.DEVNULL, # Nasconde i log del server per pulizia terminale
        stderr=subprocess.DEVNULL
    )

    # 4. Attesa che il server sia pronto
    for _ in range(10):
        try:
            if requests.get("http://localhost:11434/api/tags").status_code == 200:
                print("   ✨ Server Ollama pronto!")
                return
        except:
            time.sleep(2)
    print("   ❌ Errore: Impossibile avviare Ollama automaticamente.")



def deterministic_chunk_id(
    doc_id: str,
    page_no: int,
    chunk_index: int,
    toon_type: str,
    text_sem: str,
    image_id: Optional[int] = None,
) -> str:
    """
    ID deterministico per chunk.
    Se re-ingestisci lo stesso documento con lo stesso chunking -> stesso chunk_id -> niente duplicazioni Neo4j/Qdrant/PG.
    """
    text_hash = sha256_hex((text_sem or "").encode("utf-8"))[:16]
    base = f"{doc_id}::p{page_no}::i{chunk_index}::{toon_type}::{text_hash}"
    if image_id is not None:
        base += f"::img{image_id}"
    # 32 hex chars: stabile, corto, compatibile come string ID
    return sha256_hex(base.encode("utf-8"))[:32]

def normalize_ws(text: str) -> str:
    """
    Normalizza gli spazi ma preserva la struttura 'visiva' delle tabelle.
    Non schiaccia più spazi > 2 in uno solo, perché nei PDF significano 'colonna'.
    """
    text = (text or "").replace("\x00", " ")
    
    # Sostituisce i tab con spazi per uniformità
    text = text.replace("\t", "    ")
    
    # 1. Rimuove spazi eccessivi SOLO se sono singoli (normale testo)
    # Se ci sono più di 2 spazi consecutivi, li manteniamo (potrebbe essere una tabella)
    # Regex: Sostituisce 1 spazio ripetuto, ma rispetta '   ' (3+) come separatore colonna
    # text = re.sub(r"[ ]{2,}", " ", text) <--- VECCHIO CODICE CHE ROMPEVA LE TABELLE
    
    # NUOVO: Collassa spazi enormi (>10) ma lascia il respiro per le colonne (2-10 spazi)
    text = re.sub(r" {10,}", "    ", text) 
    
    # Gestione a capo: rimuove solo i tripli a capo inutili
    text = re.sub(r"\n{3,}", "\n\n", text)
    
    return text.strip()

def normalize_entity_id(s: str) -> str:
    """ID canonico stabile per le Entity Neo4j."""
    s = (s or "").strip().lower()
    for quote in ('"', "'", "“", "”", "‘", "’", "«", "»"):
        s = s.replace(quote, "")
    s = re.sub(r"\s+", " ", s)
    return s[:180]


def entity_alias_matches_text(alias: str, text: str) -> bool:
    """
    Verifica deterministica della presenza di un nome/sinonimo nel chunk.
    Per alias brevi usa boundary alfanumerici, evitando falsi positivi.
    """
    alias_norm = normalize_entity_id(alias)
    text_norm = normalize_entity_id(text)

    if not alias_norm or not text_norm or len(alias_norm) < 2:
        return False

    if re.fullmatch(r"[a-z0-9]{2,12}", alias_norm):
        return bool(
            re.search(
                rf"(?<![a-z0-9]){re.escape(alias_norm)}(?![a-z0-9])",
                text_norm,
            )
        )

    return alias_norm in text_norm

def normalize_doc_name(value: str) -> str:
    """Sincronizzato con gui_reflex.py"""
    if not value: return ""
    v = os.path.basename(str(value).lower().strip())
    v = re.sub(r"\.(pdf|md|txt|docx|html)$", "", v)
    v = re.sub(r"[_\-\s]+out$", "", v)
    v = re.sub(r"[_\-\s]+output$", "", v)
    v = re.sub(r"[^a-z0-9]+", "", v)
    return v



def safe_json_extract(raw: str):
    """
    Estrae in modo robusto il primo JSON valido (dict/list) da una risposta LLM.
    Gestisce:
      - code fences (backticks)
      - testo prima/dopo il JSON
      - caratteri di controllo / null bytes
      - smart quotes
      - trailing commas
      - FIX LATEX: Escaping automatico per sintassi LaTeX (\\sum -> \\\\sum)
    Ritorna: dict | list | None
    """
    if raw is None:
        return None

    s = str(raw)

    # 1) strip code fences
    # FIX ANTI-BUG COPIA/INCOLLA: Usiamo la moltiplicazione per creare i backtick
    # così l'interfaccia della chat non si confonde!
    fence_pattern = "`" * 3 + r"(?:json)?\s*([\s\S]*?)\s*" + "`" * 3
    fence = re.search(fence_pattern, s, flags=re.IGNORECASE)
    
    if fence:
        s = fence.group(1)

    # 2) rimuove caratteri di controllo (salva \t \n \r)
    s = "".join(ch for ch in s if ch == "\t" or ch == "\n" or ch == "\r" or ord(ch) >= 32)

    # 3) normalizza smart quotes
    s = (s.replace("“", '"').replace("”", '"')
           .replace("‘", "'").replace("’", "'"))

    # helper: trova primo JSON bilanciato {..} o [..]
    def _first_balanced_json(text: str):
        starts = []
        for i, ch in enumerate(text):
            if ch in "{[":
                starts.append(i)

        for start in starts:
            open_ch = text[start]
            close_ch = "}" if open_ch == "{" else "]"
            depth = 0
            in_str = False
            esc = False

            for j in range(start, len(text)):
                c = text[j]

                if in_str:
                    if esc:
                        esc = False
                    elif c == "\\":
                        esc = True
                    elif c == '"':
                        in_str = False
                    continue
                else:
                    if c == '"':
                        in_str = True
                        continue
                    if c == open_ch:
                        depth += 1
                    elif c == close_ch:
                        depth -= 1
                        if depth == 0:
                            return text[start:j+1]
        return None

    cand = _first_balanced_json(s)
    if not cand:
        return None

    # 4) prova parse diretto
    try:
        return json.loads(cand)
    except Exception:
        pass

    # 5) micro-repair: trailing commas + spazi strani + LATEX ESCAPING
    repaired = cand
    repaired = re.sub(r",\s*([}\]])", r"\1", repaired)  # trailing commas
    repaired = repaired.strip()

    # 🔥 FIX CRITICO LATEX ESCAPING 🔥
    # Trova tutti i backslash (es. \sum, \frac) non seguiti da valid json escapes (" \ / b f n r t u)
    # e li raddoppia (\\sum) per evitare il crash del parser JSON.
    repaired = re.sub(r'\\(?=[^"\\/bfnrtu])', r'\\\\', repaired)

    # 6) riprova
    try:
        return json.loads(repaired)
    except Exception as e:
        print(f"      [JSON-REPAIR-FAILED] Impossibile recuperare il JSON: {e}")
        return None




def split_text_with_overlap(text: str, max_chars: int, overlap: int) -> List[str]:
    text = normalize_ws(text)
    if len(text) <= max_chars:
        return [text]
    out = []
    i = 0
    step = max(1, max_chars - overlap)
    while i < len(text):
        out.append(text[i:i + max_chars])
        i += step
    return out

def split_paragraphs(text: str, max_chars: int, overlap: int) -> List[str]:
    text = normalize_ws(text)
    paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    merged = []
    buf = ""
    for p in paras:
        if len(buf) + len(p) + 2 <= max_chars:
            buf = (buf + "\n\n" + p).strip()
        else:
            if buf:
                merged.append(buf)
            buf = p
    if buf:
        merged.append(buf)

    final_chunks = []
    for m in merged:
        final_chunks.extend(split_text_with_overlap(m, max_chars, overlap))
    return final_chunks

def find_section_hint(page_text: str) -> str:
    if not page_text:
        return ""
    lines = [ln.strip() for ln in page_text.splitlines() if ln.strip()]
    for ln in lines[:15]:
        if 4 <= len(ln) <= 90 and ln.count(".") <= 1 and not ln.endswith("."):
            return ln[:90]
    return ""

def add_context_windows(chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not chunks:
        return chunks
    texts = [c.get("text_sem", "") for c in chunks]
    for i, c in enumerate(chunks):
        prev_txt = texts[i - 1] if i > 0 else ""
        next_txt = texts[i + 1] if i + 1 < len(texts) else ""
        c["context_prev"] = prev_txt[-CONTEXT_WINDOW_CHARS:] if prev_txt else ""
        c["context_next"] = next_txt[:CONTEXT_WINDOW_CHARS] if next_txt else ""
    return chunks

def extract_facts(text: str) -> Dict[str, Any]:
    if not text:
        return {}
    t = text[:20000]
    perc = re.findall(r"\b\d+(?:[\.,]\d+)?\s?%\b", t)
    currency = re.findall(r"(?:€\s?\d[\d\.,]*|\$\s?\d[\d\.,]*|\b\d[\d\.,]*\s?(?:EUR|USD)\b)", t)
    facts: Dict[str, Any] = {}
    if perc: facts["percentages"] = list(set(perc[:20]))
    if currency: facts["amounts"] = list(set(currency[:20]))
    return facts


def is_text_layer_corrupt(text: str) -> bool:
    """
    Rileva layer testuale rotto. (Versione Hardened per '2C0D')
    """
    if not text: return False
    
    # 1. Pattern inequivocabili di formule rotte
    bad_markers = [
        "2C0D",          # EOQ Formula rotta
        "•", "–", "—", "˜", # Bullet point corrotti
        "× ×",           # Operatori duplicati
        "( ) ( )"        # Parentesi vuote
    ]
    
    for marker in bad_markers:
        if marker in text:
            return True # Trovato marcatore di corruzione -> Butta il testo!

    # 2. Densità numeri
    lines = text.split('\n')
    numeric_lines = 0
    total_lines = len(lines)
    if total_lines > 5:
        for line in lines:
            if re.fullmatch(r'[\d\s\Wμ]+', line.strip()) and len(line) > 5:
                numeric_lines += 1
        
        if (numeric_lines / total_lines) > 0.4:
            return True
            
    return False


def smart_clean_text(text: str) -> str:
    """
    Interpreta e pulisce il testo del PDF:
    1. Rimuove simboli di font corrotti (artefatti matematici).
    2. Rimuove righe che sono solo sequenze di numeri spaziati (indici di formule esplosi).
    3. Normalizza spaziature.
    """
    if not text: 
        return ""
    
    # 1. Rimuovi i caratteri "Ghost" specifici che hai mostrato nel log
    # Questi codici (x95, x96...) sono spesso bullet point o simboli matematici mappati male
    text = re.sub(r'[\x95\x96\x97\x98\x81\x80\x8d\uf0b7\uf020]', ' ', text)
    
    lines = text.split('\n')
    valid_lines = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue

        # 2. Rilevamento Header/Footer ripetitivi
        # Se la riga è identica a intestazioni note, saltala
        if line.lower() in ["formulae sheet", "maths tables", "s17"]:
            continue
            
        # 3. Rilevamento "Numeri Esplosi" (es. "3 3 4" o "1 1 1")
        # Le formule matematiche nel layer testo spesso appaiono come numeri spaziati senza senso.
        # Se una riga ha solo numeri e spazi e meno di 2 lettere, è spazzatura del layer testo.
        if re.match(r'^[\d\s\W]+$', line) and len(re.findall(r'[a-zA-Z]', line)) < 2:
            continue

        valid_lines.append(line)
    
    # Ricostruisci il testo
    text = " ".join(valid_lines)
    
    # 4. Collassa spazi multipli generati dalla rimozione
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def safe_normalize_text(text: str) -> str:
    """
    Normalizzazione universale per testi estratti da PDF.
    - Gestisce legature standard (fi, fl, ff) tramite NFKC.
    - Rimuove caratteri di controllo e 'garbage' non-ASCII sospetti.
    - Preserva i simboli matematici necessari per le formule.
    """
    if not text:
        return ""

    # 1. Normalizzazione NFKC: Decompone le legature standard (es. 'ﬁ' -> 'fi')
    # e normalizza i caratteri simili in un'unica forma standard.
    text = unicodedata.normalize('NFKC', text)

    # 2. Identificazione contesto matematico
    # Se il testo sembra una formula, siamo più conservativi nella rimozione dei simboli.
    is_math = bool(MATH_CANDIDATE_PAT.search(text))

    # 3. Pulizia dei caratteri "Phantom" o "Private Use Area"
    # Molti glitch dei PDF finiscono nel range Unicode E000-F8FF (Private Use Area)
    # o sono caratteri di controllo non stampabili.
    if not is_math:
        # Rimuove caratteri non stampabili e simboli strani (non-latin, non-punctuation)
        # mantenendo però lettere accentate e punteggiatura standard.
        text = re.sub(r'[^\x20-\x7E\u00A0-\u00FF\u0100-\u017F\u0180-\u024F]+', ' ', text)
    else:
        # In contesto matematico, preserviamo i simboli LaTeX comuni
        # ma puliamo comunque i null byte e i caratteri di controllo.
        text = text.replace('\x00', ' ')
        text = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', ' ', text)

    # 4. Normalizzazione degli spazi bianchi
    text = re.sub(r'\s+', ' ', text)
    
    return text.strip()

def _load_rel_canon_cache() -> dict:
    try:
        with open(REL_CANON_CACHE_PATH, "r", encoding="utf-8") as f:
            return json.load(f) or {}
    except Exception:
        return {}

def _save_rel_canon_cache(cache: dict) -> None:
    try:
        with open(REL_CANON_CACHE_PATH, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def _get_rel_canon_map(rel_types: set[str]) -> dict:
    """
    Ritorna cache completa {RAW: {"verb":..., "object":..., "qualifier":...}}
    e aggiorna la cache per i missing con UNA chiamata LLM per batch/doc.
    """
    cache = _load_rel_canon_cache()

    missing = [rt for rt in sorted(rel_types) if rt and rt not in cache]
    if not missing:
        return cache

    raw = llm_chat(
        REL_CANON_PROMPT,
        json.dumps(missing, ensure_ascii=False),
        LLM_MODEL_NAME,
        max_tokens=REL_CANON_MAX_TOKENS
    )

    js = safe_json_extract(raw) or {}
    mapping = (js.get("map") or {}) if isinstance(js, dict) else {}

    for k, v in mapping.items():
        if not isinstance(v, dict):
            continue

        kk = (k or "").strip().upper()
        verb = (v.get("verb") or "").strip().upper()
        obj = (v.get("object") or "").strip().upper()
        qual = (v.get("qualifier") or "").strip().upper()

        if kk and verb:
            cache[kk] = {"verb": verb, "object": obj, "qualifier": qual}

    _save_rel_canon_cache(cache)
    return cache


def canonicalize_edges_to_verb_object(edges: list[dict]) -> list[dict]:
    """
    VERBO-ONLY:
    - ee["relation"] = VERB lemma in EN (uppercase)
    - props tiene audit: raw_relation, canon_verb, canon_object (se presente), qualifier (se presente)
    """
    if not edges:
        return edges

    rel_types = set(
        (e.get("relation") or "").strip().upper()
        for e in edges
        if e.get("relation")
    )
    canon_map = _get_rel_canon_map(rel_types)

    out: list[dict] = []

    for e in edges:
        raw_rel = (e.get("relation") or "").strip().upper()
        raw_rel = raw_rel.replace("__", "_").strip("_")
        if not raw_rel:
            out.append(e)
            continue

        m = canon_map.get(raw_rel) or {}
        
        verb = (m.get("verb") or raw_rel).strip().upper()
        obj = (m.get("object") or "").strip().upper()
        qual = (m.get("qualifier") or "").strip().upper()

        # lemma cheap (en)
        #verb = _cheap_lemma_en(verb)

        ee = dict(e)
        props = dict(ee.get("props") or {})

        # TYPE Neo4j: SOLO VERB
        canon_type = _safe_reltype(verb)

        # audit/provenance
        raw_audit = raw_rel.replace("__", "_").strip("_")
        if not RELTYPE_OK.match(raw_audit):
            raw_audit = raw_rel

        props.setdefault("raw_relation", raw_audit)
        props.setdefault("canon_verb", verb)

        # object come proprietà (non nel type)
        if obj:
            props.setdefault("canon_object", obj)

        # fallback opzionale (se vuoi): VISIT senza oggetto -> PLACE
        if not obj and canon_type == "VISIT":
            props.setdefault("canon_object", "PLACE")

        if qual:
            props.setdefault("qualifier", qual)

        ee["props"] = props
        ee["relation"] = canon_type
        out.append(ee)

    return out



def _safe_reltype(t: str) -> str:
    t = (t or "").strip().upper()
    if RELTYPE_OK.match(t):
        return t
    return "RELATES_TO"

def _cheap_lemma_en(verb: str) -> str:
    v = (verb or "").strip().upper()

    # Le relazioni canoniche composte NON devono essere lemmatizzate.
    # Sono già tipi Neo4j validi e semanticamente specifici.
    canonical_compound_relations = {
        "COMPLIES_WITH",
        "NON_COMPLIANT_WITH",
        "HAS_COMPLIANCE_STATUS",
        "HAS_GAP",
        "REQUIRES_REMEDIATION",
        "ASSIGNS_RESPONSIBILITY_TO",
        "CONTAINS_INCIDENT",
        "ESCALATES_TO",
        "REPORTS_TO",
        "RECEIVES_NOTIFICATION",
        "REQUIRES_NOTIFICATION_TO",
        "HAS_DEADLINE",
        "HAS_RECIPIENT",
        "COMMUNICATES_TO",
        "DEPENDS_ON",
        "ALIGNS_WITH",
        "CONTRIBUTES_TO",
        "VULNERABLE_TO",
        "SUPPORTS_EVIDENCE_FOR",
    }

    if v in canonical_compound_relations:
        return v

    # Se contiene underscore ed è già un tipo relazione pulito, non forzare lemma.
    # Questo evita deformazioni su relazioni composte non ancora censite.
    if "_" in v and RELTYPE_OK.match(v):
        return v

    if len(v) <= 4:
        return v

    if v.endswith("ING") and len(v) > 6:
        v = v[:-3]
    elif v.endswith("ED") and len(v) > 5:
        v = v[:-2]

    if v.endswith("ISHE") and len(v) >= 8:
        v = v[:-1]

    if v.endswith("CUS") and len(v) >= 6:
        v = v + "S"

    return v


def canonicalize_edges_by_base_presence(edges: list[dict]) -> list[dict]:
    """
    NO whitelist, data-driven:
    se nello stesso batch esistono BASE e BASE_SUFFIX, collassa BASE_SUFFIX -> BASE
    e salva raw_relation + qualifier nelle props.
    """
    if not edges:
        return edges

    rel_types = set((e.get("relation") or "").strip().upper() for e in edges if e.get("relation"))
    out = []

    for e in edges:
        rel = (e.get("relation") or "").strip().upper()
        rel = rel.replace("__", "_").strip("_")
        if not rel or "_" not in rel:
            out.append(e)
            continue

        parts = rel.split("_")
        if parts:
            parts[0] = _cheap_lemma_en(parts[0])
            rel = "_".join(parts)


        base, suffix = rel.rsplit("_", 1)

        if base in rel_types and len(base) >= 6 and 1 <= len(suffix) <= 12:
            ee = dict(e)
            ee["relation"] = base
            props = dict(ee.get("props") or {})
            props.setdefault("raw_relation", rel)
            props.setdefault("qualifier", suffix)
            ee["props"] = props
            out.append(ee)
        else:
            out.append(e)

    return out

def is_garbage_text(text: str, threshold: float = 0.10) -> bool:
    """
    Rileva se il testo estratto è corrotto (es. glitch di fitz).
    Soglia 0.10 significa che se più del 10% dei caratteri sono □ o , il chunk viene scartato.
    """
    if not text or len(text) < 5: 
        return True
    # Identifica caratteri "garbage" comuni nei PDF estratti male
    bad_chars = len(re.findall(r"[□\ufffd]", text))
    
    if bad_chars / len(text) > threshold:
        return True
    return False


def sanitize_chart_for_analysis(chart_json: dict) -> dict:
    if not isinstance(chart_json, dict):
        return {}

    cj = dict(chart_json)

    # 1) Periodo: accetta solo anni a 4 cifre
    tf = str(cj.get("timeframe", "") or "")
    years = re.findall(r"\b(19\d{2}|20\d{2})\b", tf)
    if years:
        cj["timeframe"] = " vs ".join(sorted(set(years)))
    else:
        cj["timeframe"] = "NOT READABLE"

    # 2) Categorie: rimuovi qualificatori sospetti
    cats = cj.get("categories_it", [])
    if isinstance(cats, list):
        cleaned = []
        for c in cats:
            low = str(c).lower()
            if " sud" in low or "south" in low:
                continue
            cleaned.append(c)
        cj["categories_it"] = cleaned

    return cj



def generate_chart_analysis_it(
    chart_json: dict,
    page_text: str = "",
) -> str:
    if not isinstance(chart_json, dict):
        return ""

    try:
        payload = {
            "vision_json": chart_json,
            "page_text": (page_text or "")[:2500],
        }

        return ollama_chat_http(
            model=LLM_MODEL_NAME,
            messages=[
                {
                    "role": "system",
                    "content": CHART_ANALYST_PROMPT,
                },
                {
                    "role": "user",
                    "content": json.dumps(
                        payload,
                        ensure_ascii=False,
                    ),
                },
            ],
            options={
                "temperature": 0.1,
                "num_predict": 600,
                "num_ctx": 4096,
            },
            response_format_json=True,
            timeout_s=OLLAMA_KG_TIMEOUT_S,
        )

    except Exception as e:
        print(f"   ⚠️ Chart Analysis Error: {e}")
        return ""
    
    
MATH_CANDIDATE_PAT = re.compile(
    r"(?i)("
    r"formulae\s+sheet|"           # Keyword forte
    r"maths\s+tables|"
    r"cvss|risk\s+score|impact\s*[x×*]\s*likelihood|inherent\s+risk|residual\s+risk|rto|rpo|"
    r"control\s+effectiveness|maturity\s+score|sla|severity\s+score|"
    r"2c0d|"                       # <--- IL TUO ERRORE SPECIFICO (diventa trigger)
    r"standard\s+deviation|likelihood|impact|exposure|"
    r"[\u2200-\u22FF]|"            # Operatori matematici
    r"[∑∏∫√=≈≠≤≥→↔∩∪∞±×÷]|"       # Simboli
    r"[•–—˜]"                      # <--- SE VEDI SPAZZATURA, È MATEMATICA!
    r")"
)
# 3. Pattern per Elementi Visuali (Bilingue)
CHART_CANDIDATE_PAT = re.compile(
    r"\b("
    r"chart|graph|figure|plot|diagram|heatmap|risk matrix|control matrix|dashboard|flowchart|network diagram|architecture|timeline|asset inventory|axis|legend|"
    r"grafico|grafica|figura|plot|diagramma|matrice rischi|matrice di rischio|matrice controlli|dashboard|cruscotto|flusso|rete|architettura|timeline|inventario asset|asse|legenda"
    r")\b",
    re.IGNORECASE
)
# Rileva parole che iniziano con la maiuscola (entità potenziali)
_ENTITY_PROPER_NOUNS = re.compile(r'\b[A-Z][a-zà-ù]{1,}\b')



def is_keyword_candidate_hybrid(text: str) -> bool:
    """
    Trigger bilanciato per distribuire i nodi sui chunk
    semanticamente significativi.
    """
    if not text or len(text) < KG_MIN_LEN:
        return False
    
    clean_text = safe_normalize_text(text)
    
    # Cerchiamo almeno 1 nome proprio E 1 keyword assessment/compliance
    # oppure almeno 3 keyword assessment/tecniche totali
    proper_nouns = set(_ENTITY_PROPER_NOUNS.findall(clean_text))
    assessment_keywords = set(_KG_PAT.findall(clean_text))

    if (
        len(proper_nouns) >= 1
        and len(assessment_keywords) >= 1
    ) or len(assessment_keywords) >= 3:
        return True
    
    return False


def is_keyword_candidate(text: str) -> bool:
    """Valida se il chunk contiene concetti chiave per il Knowledge Graph."""
    if not text or len(text) < KG_MIN_LEN: #
        return False
    return bool(_KG_PAT.search(text)) #

def is_formula_candidate_page(page_text: str) -> bool:
    """Valida se la pagina contiene elementi matematici per la Vision."""
    return bool(page_text and MATH_CANDIDATE_PAT.search(page_text)) #

def is_chart_candidate_page(page_text: str) -> bool:
    """Valida se la pagina contiene riferimenti visivi (grafici/tabelle)."""
    return bool(page_text and CHART_CANDIDATE_PAT.search(page_text)) #


# TIME CHECKER START
def _ms(t0: float) -> int:
    return int((time.time() - t0) * 1000)

def log_phase(filename: str, label: str, ms: int):
    print(f"   ⏱️ {filename} | {label}: {ms} ms")
# TIME CHECKER END


# =========================
# Postgres helpers
# =========================
def set_output_db_tenant_context(doc_meta: Optional[dict]) -> None:
    """Imposta nel thread corrente il tenant derivato dal job Database A."""
    meta = doc_meta or {}
    tier = str(meta.get("tier") or "").strip().upper()
    scope = str(meta.get("scope") or "").strip().upper()
    organization_id = meta.get("organization_id")

    if scope == "GLOBAL":
        if tier != "A" or organization_id is not None:
            raise ValueError(
                "Contesto GLOBAL non valido: richiesti Tier A e organization_id NULL"
            )
        tenant_key = "GLOBAL"
        allow_global = True
        organization_id = None
    elif scope == "ACCOUNT":
        if tier not in {"B", "C"} or organization_id is None:
            raise ValueError(
                "Contesto ACCOUNT non valido: richiesti Tier B/C e organization_id"
            )
        organization_id = int(organization_id)
        if organization_id <= 0:
            raise ValueError("organization_id deve essere maggiore di zero")
        tenant_key = build_tenant_key(scope, organization_id)
        allow_global = False
    else:
        raise ValueError(f"Scope documento non valido: {scope!r}")

    expected_tenant_key = str(meta.get("tenant_key") or tenant_key)
    if expected_tenant_key != tenant_key:
        raise ValueError(
            f"tenant_key non coerente: atteso={tenant_key}, ricevuto={expected_tenant_key}"
        )

    _OUTPUT_DB_CONTEXT.organization_id = organization_id
    _OUTPUT_DB_CONTEXT.allow_global_ingestion = allow_global
    _OUTPUT_DB_CONTEXT.tenant_key = tenant_key
    _OUTPUT_DB_CONTEXT.corpus_version = str(
        meta.get("corpus_version") or CORPUS_VERSION
    )


def clear_output_db_tenant_context() -> None:
    for attr in (
        "organization_id",
        "allow_global_ingestion",
        "tenant_key",
        "corpus_version",
    ):
        try:
            delattr(_OUTPUT_DB_CONTEXT, attr)
        except AttributeError:
            pass


def _current_output_tenant_key() -> str:
    tenant_key = getattr(_OUTPUT_DB_CONTEXT, "tenant_key", None)
    if not tenant_key:
        raise RuntimeError(
            "Contesto tenant non inizializzato: il documento deve provenire "
            "da un job rag_ingestion valido"
        )
    return str(tenant_key)


def pg_get_conn():
    """Connessione al Database B con RLS impostata dal job Database A."""
    if not hasattr(_OUTPUT_DB_CONTEXT, "allow_global_ingestion"):
        raise RuntimeError(
            "Contesto tenant Database B non inizializzato prima della connessione"
        )

    organization_id = getattr(_OUTPUT_DB_CONTEXT, "organization_id", None)
    allow_global = bool(
        getattr(_OUTPUT_DB_CONTEXT, "allow_global_ingestion", False)
    )

    conn = pg_pool.getconn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT set_config('app.current_customer_account_id', %s, false), "
                "set_config('app.allow_global_ingestion', %s, false)",
                (
                    "" if organization_id is None else str(organization_id),
                    "1" if allow_global else "0",
                ),
            )
        conn.commit()
        return conn
    except Exception:
        conn.rollback()
        pg_pool.putconn(conn)
        raise


def pg_put_conn(conn):
    if conn is None:
        return
    try:
        if not conn.closed:
            with conn.cursor() as cur:
                cur.execute("RESET app.current_customer_account_id")
                cur.execute("RESET app.allow_global_ingestion")
            conn.commit()
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
    finally:
        pg_pool.putconn(conn)


def _pg_role_security_check(cur) -> None:
    """
    Verifica il ruolo PostgreSQL.

    Nel POC il ruolo admin/superuser è ammesso e produce soltanto un warning.
    In produzione basta impostare POC_MODE=False e
    PG_ENFORCE_LEAST_PRIVILEGE=True per ripristinare il blocco fail-closed.
    """
    cur.execute(
        "SELECT current_user, rolsuper, rolbypassrls "
        "FROM pg_roles WHERE rolname = current_user"
    )
    row = cur.fetchone() or ("unknown", False, False)
    role_name, is_superuser, bypass_rls = row
    privileged = bool(is_superuser) or bool(bypass_rls)

    if not privileged:
        return

    if PG_ENFORCE_LEAST_PRIVILEGE and not POC_MODE:
        raise RuntimeError(
            "Il ruolo PostgreSQL applicativo non può essere SUPERUSER o BYPASSRLS. "
            "Usare un ruolo dedicato privo di privilegi di bypass."
        )

    print(
        "⚠️ POC MODE: ruolo PostgreSQL privilegiato consentito "
        f"(user={role_name}, superuser={bool(is_superuser)}, "
        f"bypassrls={bool(bypass_rls)})."
    )


def ensure_postgres_security_schema() -> None:
    """
    Bootstrap o verifica dello schema multi-tenant.

    Modalità normali (default):
    - PG_AUTO_HARDEN_SCHEMA=0
    - verifica RLS/FORCE RLS, policy e colonne richieste;
    - richiede un ruolo non SUPERUSER e senza BYPASSRLS.

    Bootstrap una tantum:
    - PG_AUTO_HARDEN_SCHEMA=1
    - PG_SCHEMA_MIGRATION_ONLY=1
    - usare un ruolo proprietario/migrator; il processo termina dopo la migrazione.
    """
    conn = pg_pool.getconn()
    try:
        conn.autocommit = True
        with conn.cursor() as cur:
            if PG_AUTO_HARDEN_SCHEMA or POC_MODE:
                if PG_AUTO_HARDEN_SCHEMA and not POC_MODE and not PG_SCHEMA_MIGRATION_ONLY:
                    raise RuntimeError(
                        "PG_AUTO_HARDEN_SCHEMA=1 è consentito solo con "
                        "PG_SCHEMA_MIGRATION_ONLY=1. Il ruolo di migrazione non deve "
                        "essere usato per l'ingestion ordinaria."
                    )

                cur.execute("ALTER TABLE public.ingestion_logs ADD COLUMN IF NOT EXISTS ingestion_run_id UUID")
                cur.execute("ALTER TABLE public.ingestion_logs ADD COLUMN IF NOT EXISTS tenant_key TEXT")
                cur.execute("ALTER TABLE public.ingestion_logs ADD COLUMN IF NOT EXISTS corpus_version TEXT")
                cur.execute("ALTER TABLE public.ingestion_logs ADD COLUMN IF NOT EXISTS classification TEXT")
                cur.execute("ALTER TABLE public.ingestion_logs ADD COLUMN IF NOT EXISTS embedding_model TEXT")
                cur.execute("ALTER TABLE public.ingestion_logs ADD COLUMN IF NOT EXISTS completed_at TIMESTAMPTZ")

                cur.execute("ALTER TABLE public.document_chunks ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'active'")
                cur.execute("ALTER TABLE public.document_chunks ADD COLUMN IF NOT EXISTS ingestion_run_id UUID")
                cur.execute("ALTER TABLE public.document_chunks ADD COLUMN IF NOT EXISTS tenant_key TEXT")
                cur.execute("ALTER TABLE public.document_chunks ADD COLUMN IF NOT EXISTS corpus_version TEXT")
                cur.execute("ALTER TABLE public.document_chunks ADD COLUMN IF NOT EXISTS classification TEXT")
                cur.execute("ALTER TABLE public.document_chunks ADD COLUMN IF NOT EXISTS embedding_model TEXT")

                cur.execute("ALTER TABLE public.ingestion_images ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'active'")
                cur.execute("ALTER TABLE public.ingestion_images ADD COLUMN IF NOT EXISTS ingestion_run_id UUID")
                cur.execute("ALTER TABLE public.ingestion_images ADD COLUMN IF NOT EXISTS tenant_key TEXT")
                cur.execute("ALTER TABLE public.ingestion_images ADD COLUMN IF NOT EXISTS corpus_version TEXT")
                cur.execute("ALTER TABLE public.ingestion_images ADD COLUMN IF NOT EXISTS classification TEXT")

                for table in ("ingestion_logs", "document_chunks", "ingestion_images"):
                    constraint_name = f"ck_{table}_tenant_tier_scope"
                    cur.execute(
                        f"""
                        DO $$
                        BEGIN
                            IF NOT EXISTS (
                                SELECT 1 FROM pg_constraint
                                WHERE conname = '{constraint_name}'
                                  AND conrelid = 'public.{table}'::regclass
                            ) THEN
                                ALTER TABLE public.{table}
                                ADD CONSTRAINT {constraint_name}
                                CHECK (
                                    (tier = 'A' AND scope = 'GLOBAL' AND organization_id IS NULL)
                                    OR
                                    (tier IN ('B','C') AND scope = 'ACCOUNT' AND organization_id IS NOT NULL)
                                ) NOT VALID;
                            END IF;
                        END $$;
                        """
                    )
                    cur.execute(f"ALTER TABLE public.{table} ENABLE ROW LEVEL SECURITY")
                    cur.execute(f"ALTER TABLE public.{table} FORCE ROW LEVEL SECURITY")

                visible_expr = """
                    (
                        (scope = 'GLOBAL' AND tier = 'A' AND organization_id IS NULL)
                        OR
                        (scope = 'ACCOUNT' AND tier IN ('B','C')
                         AND organization_id::text = current_setting('app.current_customer_account_id', true))
                    )
                """
                writable_expr = """
                    (
                        (scope = 'GLOBAL' AND tier = 'A' AND organization_id IS NULL
                         AND current_setting('app.allow_global_ingestion', true) = '1')
                        OR
                        (scope = 'ACCOUNT' AND tier IN ('B','C')
                         AND organization_id::text = current_setting('app.current_customer_account_id', true))
                    )
                """

                for table in ("ingestion_logs", "document_chunks", "ingestion_images"):
                    cur.execute(f"DROP POLICY IF EXISTS {table}_tenant_select ON public.{table}")
                    cur.execute(
                        f"CREATE POLICY {table}_tenant_select ON public.{table} "
                        f"FOR SELECT USING ({visible_expr})"
                    )
                    cur.execute(f"DROP POLICY IF EXISTS {table}_tenant_insert ON public.{table}")
                    cur.execute(
                        f"CREATE POLICY {table}_tenant_insert ON public.{table} "
                        f"FOR INSERT WITH CHECK ({writable_expr})"
                    )
                    cur.execute(f"DROP POLICY IF EXISTS {table}_tenant_update ON public.{table}")
                    cur.execute(
                        f"CREATE POLICY {table}_tenant_update ON public.{table} "
                        f"FOR UPDATE USING ({visible_expr}) WITH CHECK ({writable_expr})"
                    )
                    cur.execute(f"DROP POLICY IF EXISTS {table}_tenant_delete ON public.{table}")
                    cur.execute(
                        f"CREATE POLICY {table}_tenant_delete ON public.{table} "
                        f"FOR DELETE USING ({visible_expr})"
                    )

                cur.execute(
                    """
                    CREATE TABLE IF NOT EXISTS public.rag_query_audit (
                        audit_id BIGSERIAL PRIMARY KEY,
                        request_id UUID NOT NULL,
                        organization_id BIGINT NOT NULL,
                        user_id TEXT NOT NULL,
                        roles JSONB NOT NULL DEFAULT '[]'::jsonb,
                        query_sha256 TEXT NOT NULL,
                        intent TEXT,
                        filters JSONB NOT NULL DEFAULT '{}'::jsonb,
                        retrieved_sources JSONB NOT NULL DEFAULT '[]'::jsonb,
                        llm_model TEXT,
                        corpus_version TEXT,
                        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                    )
                    """
                )
                cur.execute("ALTER TABLE public.rag_query_audit ENABLE ROW LEVEL SECURITY")
                cur.execute("ALTER TABLE public.rag_query_audit FORCE ROW LEVEL SECURITY")
                cur.execute("DROP POLICY IF EXISTS rag_query_audit_tenant_all ON public.rag_query_audit")
                cur.execute(
                    """
                    CREATE POLICY rag_query_audit_tenant_all ON public.rag_query_audit
                    USING (organization_id::text = current_setting('app.current_customer_account_id', true))
                    WITH CHECK (organization_id::text = current_setting('app.current_customer_account_id', true))
                    """
                )

                cur.execute(
                    "CREATE INDEX IF NOT EXISTS idx_document_chunks_tenant_status "
                    "ON public.document_chunks(scope, organization_id, tier, status, chunk_uuid)"
                )
                cur.execute(
                    "CREATE INDEX IF NOT EXISTS idx_ingestion_images_tenant_status "
                    "ON public.ingestion_images(scope, organization_id, tier, status, image_hash)"
                )
                cur.execute(
                    "CREATE UNIQUE INDEX IF NOT EXISTS uq_ingestion_logs_run_id "
                    "ON public.ingestion_logs(ingestion_run_id) WHERE ingestion_run_id IS NOT NULL"
                )
                cur.execute(
                    "CREATE INDEX IF NOT EXISTS idx_rag_query_audit_tenant_time "
                    "ON public.rag_query_audit(organization_id, created_at DESC)"
                )
                return

            # Runtime ordinario.
            _pg_role_security_check(cur)

            # Nel POC manteniamo i filtri tenant applicativi e i metadati
            # organization_id/scope/tier, ma non blocchiamo l'avvio se il DB
            # usa ancora admin oppure se RLS/FORCE RLS non è stata bootstrapata.
            # La validazione rigorosa resta attiva fuori dal POC.
            if POC_MODE:
                print(
                    "ℹ️ POC MODE attivo | tenant derivato dal job Database A | "
                    "controllo RLS/least-privilege non bloccante."
                )
                return

            required_tables = ("ingestion_logs", "document_chunks", "ingestion_images")
            for table in required_tables:
                cur.execute(
                    """
                    SELECT relrowsecurity, relforcerowsecurity
                    FROM pg_class
                    WHERE oid = %s::regclass
                    """,
                    (f"public.{table}",),
                )
                flags = cur.fetchone()
                if not flags or not all(bool(x) for x in flags):
                    raise RuntimeError(f"RLS/FORCE RLS non attive su public.{table}")

                cur.execute(
                    """
                    SELECT count(*)
                    FROM pg_policies
                    WHERE schemaname='public' AND tablename=%s
                      AND policyname IN (%s, %s, %s, %s)
                    """,
                    (
                        table,
                        f"{table}_tenant_select",
                        f"{table}_tenant_insert",
                        f"{table}_tenant_update",
                        f"{table}_tenant_delete",
                    ),
                )
                if int(cur.fetchone()[0]) != 4:
                    raise RuntimeError(f"Policy RLS tenant incomplete su public.{table}")

            cur.execute("SELECT to_regclass('public.rag_query_audit')")
            if cur.fetchone()[0] is None:
                raise RuntimeError("Tabella public.rag_query_audit assente: eseguire bootstrap schema")
    finally:
        try:
            conn.autocommit = False
        except Exception:
            pass
        pg_pool.putconn(conn)



def pg_start_log(source_name: str, source_type: str, doc_meta: dict = None) -> int:
    meta = doc_meta if isinstance(doc_meta, dict) else {}
    org_id = meta.get("organization_id")
    tier = str(meta.get("tier") or "").upper()
    scope = str(meta.get("scope") or "").upper()
    tenant_key = str(meta.get("tenant_key") or build_tenant_key(scope, org_id))
    run_id = str(meta.get("ingestion_run_id") or uuid.uuid4())
    meta["ingestion_run_id"] = run_id
    meta.setdefault("corpus_version", CORPUS_VERSION)
    meta.setdefault("classification", DEFAULT_CLASSIFICATION)
    meta.setdefault("embedding_model", EMBEDDING_MODEL_NAME)

    conn = pg_get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO public.ingestion_logs (
                    source_name, source_type, ingestion_ts, status,
                    organization_id, tier, scope, ingestion_run_id,
                    tenant_key, corpus_version, classification, embedding_model
                )
                VALUES (%s, %s, NOW(), %s, %s, %s, %s, %s::uuid, %s, %s, %s, %s)
                RETURNING log_id
                """,
                (
                    source_name, source_type, "RUNNING", org_id, tier, scope,
                    run_id, tenant_key, meta["corpus_version"],
                    meta["classification"], meta["embedding_model"],
                ),
            )
            log_id = cur.fetchone()[0]
        conn.commit()
        return int(log_id)
    except Exception:
        conn.rollback()
        raise
    finally:
        pg_put_conn(conn)
        
        
def pg_close_log(log_id: int, status: str, total_chunks: int, processing_ms: int, error_msg: str = None):
    status = str(status or "FAILED").upper()
    if status not in INGESTION_RUN_STATUSES:
        raise ValueError(f"Stato ingestion non valido: {status}")
    conn = pg_get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE public.ingestion_logs
                SET status = %s,
                    total_chunks = %s,
                    processing_time_ms = %s,
                    error_message = %s,
                    completed_at = NOW()
                WHERE log_id = %s
                """,
                (status, total_chunks, processing_ms, error_msg, log_id),
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        pg_put_conn(conn)



def pg_fail_log_if_running(
    log_id: int,
    processing_ms: int,
    error_msg: str,
) -> None:
    """Imposta FAILED solo se il log non è già DONE/PARTIAL_FAILED."""
    conn = pg_get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE public.ingestion_logs
                SET status = 'FAILED',
                    processing_time_ms = %s,
                    error_message = %s,
                    completed_at = NOW()
                WHERE log_id = %s
                  AND status = 'RUNNING'
                """,
                (processing_ms, error_msg, log_id),
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        pg_put_conn(conn)

def pg_get_image_by_hash(
    image_hash: str,
    log_id: int,
    cur,
) -> Optional[Tuple[int, str]]:
    """Deduplica immagini soltanto nello stesso namespace tenant."""
    cur.execute(
        """
        SELECT i.image_id, i.description_ai
        FROM ingestion_images i
        JOIN ingestion_logs current_log
          ON current_log.log_id = %s
        WHERE i.image_hash = %s
          AND i.scope IS NOT DISTINCT FROM current_log.scope
          AND i.tier IS NOT DISTINCT FROM current_log.tier
          AND i.organization_id IS NOT DISTINCT FROM current_log.organization_id
        LIMIT 1
        """,
        (log_id, image_hash),
    )
    return cur.fetchone()


def pg_save_image(log_id: int, image_bytes: bytes, mime_type: str, description: str, cur) -> int:
    img_hash = sha256_hex(image_bytes)
    cached = pg_get_image_by_hash(img_hash, log_id, cur)
    if cached:
        return cached[0]

    # I metadati tenant vengono copiati dal log già all'inserimento; in questo
    # modo anche più immagini uguali nello stesso documento sono deduplicate.
    cur.execute(
        """
        INSERT INTO ingestion_images (
            log_id,
            image_data,
            image_hash,
            mime_type,
            description_ai,
            ingestion_ts,
            organization_id,
            tier,
            scope,
            status,
            ingestion_run_id,
            tenant_key,
            corpus_version,
            classification
        )
        SELECT
            l.log_id,
            %s,
            %s,
            %s,
            %s,
            NOW(),
            l.organization_id,
            l.tier,
            l.scope,
            'active',
            l.ingestion_run_id,
            l.tenant_key,
            l.corpus_version,
            l.classification
        FROM ingestion_logs l
        WHERE l.log_id = %s
        RETURNING image_id
        """,
        (
            psycopg2.Binary(image_bytes),
            img_hash,
            mime_type,
            description,
            log_id,
        ),
    )
    row = cur.fetchone()
    if not row:
        raise RuntimeError(f"Log ingestion non trovato: {log_id}")
    return row[0]


def flush_postgres_chunks_batch(batch_data: List[Tuple]):
    if not batch_data:
        return True

    now = time.strftime('%Y-%m-%d %H:%M:%S')
    rows = [row + (now,) for row in batch_data]
    dedupe_keys = []
    seen = set()

    for row in batch_data:
        if len(row) < 16:
            raise ValueError("Riga document_chunks priva dei metadati di sicurezza obbligatori")
        chunk_uuid = str(row[6]).strip()
        organization_id = row[7]
        scope = str(row[9] or "").strip().upper()
        key = (chunk_uuid, organization_id, scope)
        if chunk_uuid and key not in seen:
            seen.add(key)
            dedupe_keys.append(key)

    conn = pg_get_conn()
    try:
        with conn.cursor() as cur:
            if dedupe_keys:
                execute_values(
                    cur,
                    """
                    WITH doomed(chunk_uuid, organization_id, scope) AS (VALUES %s)
                    DELETE FROM public.document_chunks d
                    USING doomed
                    WHERE d.chunk_uuid::text = doomed.chunk_uuid::text
                      AND d.scope IS NOT DISTINCT FROM doomed.scope
                      AND d.organization_id IS NOT DISTINCT FROM doomed.organization_id::bigint
                    """,
                    dedupe_keys,
                )

            execute_values(
                cur,
                """
                INSERT INTO public.document_chunks (
                    log_id, chunk_index, toon_type, content_raw, content_semantic,
                    metadata_json, chunk_uuid, organization_id, tier, scope,
                    status, ingestion_run_id, tenant_key, corpus_version,
                    classification, embedding_model, ingestion_ts
                ) VALUES %s
                """,
                rows,
            )
        conn.commit()
        return True
    except Exception:
        conn.rollback()
        raise
    finally:
        pg_put_conn(conn)


# =========================
# Qdrant helpers
# =========================
def get_embedding_dimension_safe(model) -> int:
    """
    Compatibilità SentenceTransformer:
    - versioni nuove: get_embedding_dimension()
    - versioni vecchie: get_sentence_embedding_dimension()
    """
    if hasattr(model, "get_embedding_dimension"):
        return int(model.get_embedding_dimension())

    return int(model.get_sentence_embedding_dimension())


def ensure_qdrant_collection():
    dim = get_embedding_dimension_safe(embedder)
    try:
        info = qdrant_client.get_collection(QDRANT_COLLECTION)
        if info.config.params.vectors.size != dim:
            raise RuntimeError(
                f"Qdrant vector dimension mismatch: {info.config.params.vectors.size} != {dim}"
            )
    except RuntimeError:
        raise
    except Exception:
        print(f"🆕 Creating Qdrant collection '{QDRANT_COLLECTION}' (dim={dim})")
        qdrant_client.create_collection(
            collection_name=QDRANT_COLLECTION,
            vectors_config=models.VectorParams(size=dim, distance=models.Distance.COSINE),
        )

    indexes = {
        "scope": models.PayloadSchemaType.KEYWORD,
        "tier": models.PayloadSchemaType.KEYWORD,
        "organization_id": models.PayloadSchemaType.INTEGER,
        "status": models.PayloadSchemaType.KEYWORD,
        "doc_id": models.PayloadSchemaType.KEYWORD,
        "document_id": models.PayloadSchemaType.KEYWORD,
        "ontology": models.PayloadSchemaType.KEYWORD,
        "ontology_codes": models.PayloadSchemaType.KEYWORD,
        "document_context_ids": models.PayloadSchemaType.KEYWORD,
        "chunk_id": models.PayloadSchemaType.KEYWORD,
        "ingestion_run_id": models.PayloadSchemaType.KEYWORD,
        "source_type": models.PayloadSchemaType.KEYWORD,
        "classification": models.PayloadSchemaType.KEYWORD,
        "corpus_version": models.PayloadSchemaType.KEYWORD,
        "embedding_model": models.PayloadSchemaType.KEYWORD,
    }
    for field_name, schema_type in indexes.items():
        try:
            qdrant_client.create_payload_index(
                collection_name=QDRANT_COLLECTION,
                field_name=field_name,
                field_schema=schema_type,
                # La creazione dell'indice è idempotente e può proseguire lato
                # Qdrant senza bloccare l'ingestion del primo documento.
                wait=False,
            )
        except Exception as exc:
            message = str(exc).lower()
            if "already exists" not in message and "already indexed" not in message:
                raise

NEO4J_STRUCTURE_QUERY = """
UNWIND $rows AS r

// Modello fisico unico e direzionale:
// Document -> Page -> Chunk
MERGE (d:Document {doc_id: r.doc_id})
SET d.filename = r.filename,
    d.doc_type = r.doc_type,
    d.tier = r.tier,
    d.scope = r.scope,
    d.organization_id = r.organization_id,
    d.tenant_key = r.tenant_key,
    d.ontology = r.ontology,
    d.ontology_codes = r.ontology_codes,
    d.document_context_ids = r.document_context_ids,
    d.contexts_json = r.contexts_json,
    d.log_id = r.log_id,
    d.status = r.status,
    d.ingestion_run_id = r.ingestion_run_id,
    d.corpus_version = r.corpus_version,
    d.classification = r.classification,
    d.embedding_model = r.embedding_model,
    d.ingested_at = datetime()

MERGE (p:Page {pid: r.doc_id + "::" + toString(r.page_no)})
SET p.doc_id = r.doc_id,
    p.page_no = r.page_no,
    p.filename = r.filename,
    p.tier = r.tier,
    p.scope = r.scope,
    p.organization_id = r.organization_id,
    p.tenant_key = r.tenant_key,
    p.ontology = r.ontology,
    p.ontology_codes = r.ontology_codes,
    p.document_context_ids = r.document_context_ids,
    p.contexts_json = r.contexts_json,
    p.status = r.status,
    p.ingestion_run_id = r.ingestion_run_id,
    p.corpus_version = r.corpus_version,
    p.classification = r.classification
MERGE (d)-[:HAS_PAGE]->(p)

MERGE (c:Chunk {id: r.chunk_id})
SET c.chunk_id = r.chunk_id,
    c.doc_id = r.doc_id,
    c.chunk_index = r.chunk_index,
    c.page_chunk_index = r.page_chunk_index,
    c.toon_type = r.toon_type,
    c.page = r.page_no,
    c.filename = r.filename,
    c.tier = r.tier,
    c.scope = r.scope,
    c.organization_id = r.organization_id,
    c.tenant_key = r.tenant_key,
    c.ontology = r.ontology,
    c.ontology_codes = r.ontology_codes,
    c.document_context_ids = r.document_context_ids,
    c.contexts_json = r.contexts_json,
    c.status = r.status,
    c.ingestion_run_id = r.ingestion_run_id,
    c.corpus_version = r.corpus_version,
    c.classification = r.classification,
    c.embedding_model = r.embedding_model,
    c.text = left(r.text_sem, 2500),
    c.section_hint = coalesce(r.section_hint, "")
MERGE (p)-[:HAS_CHUNK]->(c)

RETURN count(*) AS chunks_written
"""

NEO4J_ENTITY_QUERY = """
UNWIND $rows AS r
MATCH (c:Chunk {id: r.chunk_id})
UNWIND coalesce(r.nodes, []) AS n
WITH r, c, n
WHERE n.id IS NOT NULL AND trim(toString(n.id)) <> ""

MERGE (e:Entity {id: r.tenant_key + "::" + n.id})
ON CREATE SET
    e.canonical_id = n.id,
    e.entity_key = r.tenant_key + "::" + n.id,
    e.tenant_key = r.tenant_key,
    e.name = coalesce(n.name, n.id),
    e.category = CASE
        WHEN n.category IS NOT NULL AND n.category <> "UNCLASSIFIED"
        THEN n.category
        ELSE "UNCLASSIFIED"
    END,
    e.tier = r.tier,
    e.scope = r.scope,
    e.organization_id = r.organization_id,
    e.sources = [r.filename_norm],
    e.source_refs = [r.source_ref],
    e.status = r.status,
    e.corpus_version = r.corpus_version,
    e.classification = r.classification,
    e.embedding_model = r.embedding_model,
    e.ingestion_run_ids = [r.ingestion_run_id]
ON MATCH SET
    e.name = CASE
        WHEN n.name IS NOT NULL
             AND trim(toString(n.name)) <> ""
             AND (
                 e.name IS NULL
                 OR trim(toString(e.name)) = ""
                 OR toLower(trim(toString(e.name))) =
                    toLower(trim(toString(e.id)))
             )
        THEN n.name
        ELSE coalesce(e.name, n.name, n.id)
    END,
    e.category = CASE
        WHEN n.category IS NOT NULL AND n.category <> "UNCLASSIFIED"
        THEN n.category
        ELSE e.category
    END,
    e.tier = CASE 
        WHEN r.scope = 'GLOBAL' THEN 'A' 
        ELSE coalesce(e.tier, r.tier) 
    END,
    e.scope = CASE 
        WHEN r.scope = 'GLOBAL' THEN 'GLOBAL' 
        ELSE coalesce(e.scope, r.scope) 
    END,
    e.organization_id = CASE 
        WHEN r.scope = 'GLOBAL' THEN NULL 
        ELSE coalesce(e.organization_id, r.organization_id) 
    END,
    e.sources = CASE
        WHEN r.filename_norm IN coalesce(e.sources, [])
        THEN coalesce(e.sources, [])
        ELSE coalesce(e.sources, []) + r.filename_norm
    END,
    e.source_refs = CASE
        WHEN r.source_ref IN coalesce(e.source_refs, [])
        THEN coalesce(e.source_refs, [])
        ELSE coalesce(e.source_refs, []) + r.source_ref
    END,
    e.ingestion_run_ids = CASE
        WHEN r.ingestion_run_id IN coalesce(e.ingestion_run_ids, [])
        THEN coalesce(e.ingestion_run_ids, [])
        ELSE coalesce(e.ingestion_run_ids, []) + r.ingestion_run_id
    END,
    e.status = 'active' 
SET e += coalesce(n.props, {})
// I props estratti dall'LLM non possono modificare il confine tenant.
SET e.canonical_id = n.id,
    e.entity_key = r.tenant_key + "::" + n.id,
    e.tenant_key = r.tenant_key,
    e.tier = r.tier,
    e.scope = r.scope,
    e.organization_id = r.organization_id,
    e.status = r.status,
    e.corpus_version = r.corpus_version,
    e.classification = r.classification,
    e.embedding_model = r.embedding_model

// Provenance esclusivamente a livello Chunk.
// Non esiste più alcun collegamento diretto Page -> Entity o Entity -> Page.
MERGE (c)-[m:MENTIONS]->(e)
SET m.filename = r.filename,
    m.page_no = r.page_no,
    m.chunk_index = r.chunk_index,
    m.page_chunk_index = r.page_chunk_index,
    m.chunk_id = r.chunk_id,
    m.source_ref = r.source_ref,
    m.tier = r.tier,
    m.scope = r.scope,
    m.organization_id = r.organization_id,
    m.tenant_key = r.tenant_key,
    m.status = r.status,
    m.ingestion_run_id = r.ingestion_run_id,
    m.corpus_version = r.corpus_version,
    m.classification = r.classification,
    m.evidence_type = "chunk_entity_mention"

RETURN count(*) AS entity_mentions_written
"""

# Alias mantenuto per eventuali riferimenti esterni al modulo.
NEO4J_BATCH_QUERY = NEO4J_STRUCTURE_QUERY

# Formula nodes deterministici: Chunk -> Formula.
NEO4J_FORMULA_QUERY = """
UNWIND $rows AS r
MATCH (c:Chunk {id: r.chunk_id})
MERGE (f:Formula {fid: r.fid})
SET f.latex = r.latex,
    f.latex_raw = r.latex_raw,
    f.plain = r.plain,
    f.meaning_it = r.meaning_it,
    f.keywords = r.keywords,
    f.page = r.page_no,
    f.source = r.filename,
    f.tier = r.tier,
    f.scope = r.scope,
    f.organization_id = r.organization_id,
    f.tenant_key = r.tenant_key,
    f.status = r.status,
    f.ingestion_run_id = r.ingestion_run_id,
    f.corpus_version = r.corpus_version,
    f.classification = r.classification
MERGE (c)-[hf:HAS_FORMULA]->(f)
SET hf.filename = r.filename,
    hf.page_no = r.page_no,
    hf.chunk_id = r.chunk_id,
    hf.tier = r.tier,
    hf.scope = r.scope,
    hf.organization_id = r.organization_id,
    hf.status = r.status,
    hf.ingestion_run_id = r.ingestion_run_id
"""

def _flat_props(props) -> Dict[str, Any]:
    if not isinstance(props, dict):
        return {}
    out = {}
    for k, v in props.items():
        if isinstance(v, (str, int, float, bool)):
            out[k[:60]] = v
        elif isinstance(v, list) and len(v) <= 12 and all(isinstance(x, (str, int, float, bool)) for x in v):
            out[k[:60]] = v
    return out

def _clean_type(t: str) -> str:
    t = (t or "").strip()
    t = re.sub(r"[^a-zA-Z0-9]", "", t[:60].capitalize())
    return t[:50] or "Entity"

def _clean_rel(r: str) -> str:
    r = (r or "").strip().upper()
    r = re.sub(r"[^A-Z0-9_]+", "_", r)
    r = re.sub(r"_+", "_", r).strip("_")
    return r[:50] or "RELATED_TO"

def canonicalize_edges(edges: list[dict]) -> list[dict]:
    """
    Canonicalizza relation types senza whitelist linguistica:
    - se esiste sia BASE che BASE_SUFFIX nello stesso batch di edges,
      collassa BASE_SUFFIX -> BASE e salva suffix in props["qualifier"].
    """
    if not edges:
        return edges

    # set dei relation type presenti (già puliti da _clean_rel)
    rel_types = set((e.get("relation") or "").strip().upper() for e in edges if e.get("relation"))

    out = []
    for e in edges:
        rel = (e.get("relation") or "").strip().upper()
        if not rel or "_" not in rel:
            out.append(e)
            continue

        base, suffix = rel.rsplit("_", 1)

        # guardrail: base non troppo corto e suffix ragionevole
        if base in rel_types and len(base) >= 8 and 1 <= len(suffix) <= 12:
            ee = dict(e)
            ee["relation"] = base
            props = dict(ee.get("props") or {})
            props.setdefault("raw_relation", rel)
            props.setdefault("qualifier", suffix)
            ee["props"] = props
            out.append(ee)
        else:
            out.append(e)

    return out

def _as_str(x) -> str:
    if x is None:
        return ""
    if isinstance(x, str):
        return x.strip()
    return str(x).strip()


def _as_str_list(x) -> list[str]:
    if not x:
        return []
    if isinstance(x, list):
        return [str(v).strip() for v in x if str(v).strip()]
    if isinstance(x, str):
        return [x.strip()] if x.strip() else []
    return []


def _normalize_graph_schema(js: Any) -> Optional[Dict[str, Any]]:
    """
    Normalizza output KG flat:
    - nodi con description/formula/synonyms in props
    - archi con evidence in props
    - compatibile con Neo4j Entity generico
    """
    if not isinstance(js, dict):
        if isinstance(js, list):
            js = {"nodes": js, "edges": []}
        else:
            return None

    g = dict(js)

    nnodes = []
    for n in (g.get("nodes") or g.get("entities") or []):
        if not isinstance(n, dict):
            continue

        nid = n.get("id") or n.get("name") or n.get("label")
        if not nid:
            continue

        category = _as_str(n.get("category") or n.get("type") or "UNCLASSIFIED").upper()

        props = {}
        props["description"] = _as_str(n.get("description"))
        props["formula"] = _as_str(n.get("formula"))
        props["synonyms"] = _as_str_list(n.get("synonyms"))

        # preserva eventuali props già presenti
        raw_props = n.get("props") or n.get("properties") or {}
        if isinstance(raw_props, dict):
            for k, v in raw_props.items():
                if k in props:
                    continue
                if isinstance(v, (str, int, float, bool)):
                    props[k[:60]] = v
                elif isinstance(v, list) and all(isinstance(x, (str, int, float, bool)) for x in v):
                    props[k[:60]] = v

        node_out = {
            "id": _as_str(nid),
            "category": category,
            "props": props
        }

        nnodes.append(node_out)

    g["nodes"] = nnodes

    eedges = []
    for e in (g.get("edges") or g.get("relationships") or []):
        if not isinstance(e, dict):
            continue

        src = e.get("source") or e.get("from")
        tgt = e.get("target") or e.get("to")
        rel = e.get("relation") or e.get("type") or "RELATED_TO"

        if not src or not tgt:
            continue

        props = {}

        evidence = e.get("evidence")
        if evidence:
            props["evidence"] = _as_str(evidence)

        raw_props = e.get("props") or e.get("properties") or {}
        if isinstance(raw_props, dict):
            for k, v in raw_props.items():
                if isinstance(v, (str, int, float, bool)):
                    props[k[:60]] = v
                elif isinstance(v, list) and all(isinstance(x, (str, int, float, bool)) for x in v):
                    props[k[:60]] = v

        edge_out = {
            "source": _as_str(src),
            "target": _as_str(tgt),
            "relation": _as_str(rel).upper(),
            "props": props
        }

        eedges.append(edge_out)

    g["edges"] = eedges
    return g


def _sanitize_graph(graph_data: Any) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Passa i dati a Neo4j con controlli antiproiettile contro le allucinazioni dell'LLM."""
    if not isinstance(graph_data, dict): return [], []
    
    nodes = []
    seen = set()
    for n in graph_data.get("nodes", []):
        # 🔥 FIX ANTI-CRASH: Se l'LLM allucina una stringa invece di un oggetto, saltala
        if not isinstance(n, dict): continue  
        
        nid = n.get("id")
        if not nid or str(nid) in seen: continue
        seen.add(str(nid))
        nodes.append({
            "id": str(nid)[:200],
            "category": str(n.get("category", "UNCLASSIFIED"))[:50],
            "props": n.get("props", {})
        })
        
    edges = []
    for e in graph_data.get("edges", []):
        # 🔥 FIX ANTI-CRASH: Protezione per gli archi
        if not isinstance(e, dict): continue  
        
        src = e.get("source")
        tgt = e.get("target")
        if not src or not tgt: continue
        edges.append({
            "source": str(src)[:200],
            "target": str(tgt)[:200],
            "relation": str(e.get("relation", "RELATED_TO"))[:50],
            "props": e.get("props", {})
        })
        
    return nodes[:80], edges[:100]

def enrich_formula_nodes_and_edges(nodes: list[dict], edges: list[dict]) -> tuple[list[dict], list[dict]]:
    """
    Se un nodo concettuale contiene props.formula, crea anche:
    - un nodo FORMULA dedicato
    - un edge concetto -> formula con HAS_FORMULA

    Esempio:
    CVSS Base Score
      props.formula = "CVSS = f(Impact, Exploitability)"
    diventa anche:
      (:Entity {id:"Formula::CVSS Base Score"})
      (:Entity)-[:HAS_FORMULA]->(:Entity)
    """
    if not nodes:
        return nodes, edges

    existing_ids = {n.get("id") for n in nodes if isinstance(n, dict)}
    existing_edges = {
        (e.get("source"), e.get("target"), e.get("relation"))
        for e in edges
        if isinstance(e, dict)
    }

    new_nodes = []
    new_edges = []

    for n in nodes:
        if not isinstance(n, dict):
            continue

        nid = n.get("id")
        cat = str(n.get("category", "") or "").upper()
        props = n.get("props") or {}
        formula = str(props.get("formula", "") or "").strip()

        if not nid or not formula:
            continue

        # Se il nodo è già FORMULA, non duplicare.
        if cat == "FORMULA":
            continue

        fid = f"Formula::{nid}"

        if fid not in existing_ids:
            new_nodes.append({
                "id": fid,
                "category": "FORMULA",
                "props": {
                    "description": f"Formula associata a {nid}",
                    "formula": formula,
                    "synonyms": []
                }
            })
            existing_ids.add(fid)

        edge_key = (nid, fid, "HAS_FORMULA")
        if edge_key not in existing_edges:
            new_edges.append({
                "source": nid,
                "target": fid,
                "relation": "HAS_FORMULA",
                "props": {
                    "evidence": "Formula estratta dal testo e associata al concetto."
                }
            })
            existing_edges.add(edge_key)

    return nodes + new_nodes, edges + new_edges


def _cleanup_legacy_neo4j_links(
    session,
    page_ids: List[str],
    chunk_ids: List[str],
) -> None:
    """Rimuove soltanto le vecchie provenance del modello precedente."""
    if page_ids:
        session.run(
            """
            MATCH (p:Page)
            WHERE p.pid IN $page_ids
            MATCH (:Entity)-[r:PRESENT_ON]->(p)
            DELETE r
            """,
            page_ids=page_ids,
        ).consume()

    if chunk_ids:
        session.run(
            """
            MATCH (c:Chunk)
            WHERE c.id IN $chunk_ids
            MATCH (:Entity)-[r:PRESENT_IN|MENTIONED_IN]->(c)
            DELETE r
            """,
            chunk_ids=chunk_ids,
        ).consume()

        session.run(
            """
            MATCH (c:Chunk)
            WHERE c.id IN $chunk_ids
            MATCH (:Formula)-[r:MENTIONED_IN]->(c)
            DELETE r
            """,
            chunk_ids=chunk_ids,
        ).consume()



NEO4J_GLOBAL_TARGET_RELATIONS = {
    "EVIDENCES", "IMPLEMENTS", "SATISFIES", "REFERENCES_REQUIREMENT",
    "COMPLIES_WITH", "MAPS_TO", "ALIGNS_WITH", "SUPPORTS",
}


def ensure_neo4j_security_schema() -> None:
    if not NEO4J_ENABLED or not neo4j_driver:
        return
    statements = [
        "CREATE CONSTRAINT document_doc_id_unique IF NOT EXISTS FOR (n:Document) REQUIRE n.doc_id IS UNIQUE",
        "CREATE CONSTRAINT page_pid_unique IF NOT EXISTS FOR (n:Page) REQUIRE n.pid IS UNIQUE",
        "CREATE CONSTRAINT chunk_id_unique IF NOT EXISTS FOR (n:Chunk) REQUIRE n.id IS UNIQUE",
        "CREATE CONSTRAINT entity_id_unique IF NOT EXISTS FOR (n:Entity) REQUIRE n.id IS UNIQUE",
        "CREATE CONSTRAINT formula_fid_unique IF NOT EXISTS FOR (n:Formula) REQUIRE n.fid IS UNIQUE",
        "CREATE INDEX chunk_tenant_status IF NOT EXISTS FOR (n:Chunk) ON (n.scope, n.organization_id, n.status)",
        "CREATE INDEX entity_tenant_status IF NOT EXISTS FOR (n:Entity) ON (n.scope, n.organization_id, n.status)",
        "CREATE INDEX document_tenant_status IF NOT EXISTS FOR (n:Document) ON (n.scope, n.organization_id, n.status)",
    ]
    with neo4j_driver.session() as session:
        for statement in statements:
            session.run(statement).consume()


def flush_neo4j_rows_batch(rows: List[Dict[str, Any]]) -> bool:
    """
    Scrive il modello:
        Document -[:HAS_PAGE]-> Page
        Page     -[:HAS_CHUNK]-> Chunk
        Chunk    -[:MENTIONS]-> Entity

    Le relazioni semantiche Entity -> Entity restano separate e conservano
    provenance di documento, pagina e chunk.
    """
    if not NEO4J_ENABLED or not rows:
        return True

    try:
        with neo4j_driver.session() as session:
            page_ids = sorted({
                f"{row.get('doc_id')}::{int(row.get('page_no') or 0)}"
                for row in rows
                if row.get("doc_id") and int(row.get("page_no") or 0) > 0
            })
            chunk_ids = sorted({
                str(row.get("chunk_id"))
                for row in rows
                if row.get("chunk_id")
            })

            # Consente anche re-ingestion incrementale senza lasciare il modello
            # legacy Entity->Page / Entity->Chunk sul documento corrente.
            _cleanup_legacy_neo4j_links(session, page_ids, chunk_ids)

            session.run(NEO4J_STRUCTURE_QUERY, rows=rows).consume()
            session.run(NEO4J_ENTITY_QUERY, rows=rows).consume()

            edges_by_type: Dict[str, Dict[Tuple[str, str, str], Dict[str, Any]]] = {}

            for row in rows:
                for edge in row.get("edges", []):
                    if not isinstance(edge, dict):
                        continue

                    source = normalize_entity_id(str(edge.get("source") or ""))
                    target = normalize_entity_id(str(edge.get("target") or ""))
                    rel_type = str(
                        edge.get("relation") or "RELATES_TO"
                    ).upper().replace(" ", "_")
                    rel_type = "".join(
                        char for char in rel_type
                        if char.isalnum() or char == "_"
                    ) or "RELATES_TO"

                    if not source or not target:
                        continue

                    props = dict(edge.get("props") or {})
                    source_file = str(
                        props.get("source_file")
                        or row.get("filename")
                        or ""
                    )
                    page_no = int(
                        props.get("page_no")
                        or row.get("page_no")
                        or 0
                    )
                    chunk_id = str(
                        props.get("chunk_id")
                        or row.get("chunk_id")
                        or ""
                    )
                    chunk_index = int(
                        props.get("chunk_index")
                        if props.get("chunk_index") is not None
                        else (row.get("chunk_index") or 0)
                    )
                    page_chunk_index = int(
                        props.get("page_chunk_index")
                        if props.get("page_chunk_index") is not None
                        else (row.get("page_chunk_index") or 0)
                    )
                    source_ref = str(
                        props.get("source_ref")
                        or row.get("source_ref")
                        or ""
                    )

                    tenant_key = str(row.get("tenant_key") or "")
                    if not tenant_key:
                        continue

                    bucket = edges_by_type.setdefault(rel_type, {})
                    key = (tenant_key, source, target)
                    entry = bucket.setdefault(
                        key,
                        {
                            "source": source,
                            "target": target,
                            "source_key": f"{tenant_key}::{source}",
                            "target_key": f"{tenant_key}::{target}",
                            "tenant_key": tenant_key,
                            "scope": row.get("scope"),
                            "organization_id": row.get("organization_id"),
                            "status": row.get("status", "active"),
                            "ingestion_run_id": row.get("ingestion_run_id"),
                            "corpus_version": row.get("corpus_version"),
                            "classification": row.get("classification"),
                            "allow_global_target": (
                                str(row.get("scope") or "").upper() == "ACCOUNT"
                                and rel_type in NEO4J_GLOBAL_TARGET_RELATIONS
                            ),
                            "props": {},
                            "source_files": set(),
                            "page_nos": set(),
                            "chunk_ids": set(),
                            "chunk_indices": set(),
                            "page_chunk_indices": set(),
                            "source_refs": set(),
                        },
                    )

                    entry["props"].update(props)
                    if source_file:
                        entry["source_files"].add(source_file)
                    if page_no > 0:
                        entry["page_nos"].add(page_no)
                    if chunk_id:
                        entry["chunk_ids"].add(chunk_id)
                    entry["chunk_indices"].add(chunk_index)
                    entry["page_chunk_indices"].add(page_chunk_index)
                    if source_ref:
                        entry["source_refs"].add(source_ref)

            for rel_type, edge_map in edges_by_type.items():
                batch_edges = []
                for entry in edge_map.values():
                    batch_edges.append({
                        "source": entry["source"],
                        "target": entry["target"],
                        "source_key": entry["source_key"],
                        "target_key": entry["target_key"],
                        "tenant_key": entry["tenant_key"],
                        "scope": entry["scope"],
                        "organization_id": entry["organization_id"],
                        "status": entry["status"],
                        "ingestion_run_id": entry["ingestion_run_id"],
                        "corpus_version": entry["corpus_version"],
                        "classification": entry["classification"],
                        "allow_global_target": entry["allow_global_target"],
                        "global_target_key": f"GLOBAL::{entry['target']}",
                        "props": entry["props"],
                        "source_files": sorted(entry["source_files"]),
                        "page_nos": sorted(entry["page_nos"]),
                        "chunk_ids": sorted(entry["chunk_ids"]),
                        "chunk_indices": sorted(entry["chunk_indices"]),
                        "page_chunk_indices": sorted(
                            entry["page_chunk_indices"]
                        ),
                        "source_refs": sorted(entry["source_refs"]),
                    })

                edge_query = f"""
                UNWIND $batch AS e
                MATCH (s:Entity {{id: e.source_key}})
                MATCH (tenant_target:Entity {{id: e.target_key}})
                OPTIONAL MATCH (global_target:Entity {{id: e.global_target_key, scope: 'GLOBAL', tier: 'A', status: 'active'}})
                WITH e, s, CASE
                    WHEN e.allow_global_target AND global_target IS NOT NULL THEN global_target
                    ELSE tenant_target
                END AS t
                MERGE (s)-[r:{rel_type}]->(t)
                ON CREATE SET
                    r.first_seen = datetime(),
                    r.source_files = [],
                    r.page_nos = [],
                    r.chunk_ids = [],
                    r.chunk_indices = [],
                    r.page_chunk_indices = [],
                    r.source_refs = []
                SET r += coalesce(e.props, {{}}),
                    r.tenant_key = e.tenant_key,
                    r.scope = e.scope,
                    r.organization_id = e.organization_id,
                    r.status = e.status,
                    r.ingestion_run_id = e.ingestion_run_id,
                    r.corpus_version = e.corpus_version,
                    r.classification = e.classification,
                    r.last_seen = datetime()
                SET r.source_files = reduce(
                    acc = coalesce(r.source_files, []),
                    value IN coalesce(e.source_files, []) |
                    CASE WHEN value IN acc THEN acc ELSE acc + value END
                )
                SET r.page_nos = reduce(
                    acc = coalesce(r.page_nos, []),
                    value IN coalesce(e.page_nos, []) |
                    CASE WHEN value IN acc THEN acc ELSE acc + value END
                )
                SET r.chunk_ids = reduce(
                    acc = coalesce(r.chunk_ids, []),
                    value IN coalesce(e.chunk_ids, []) |
                    CASE WHEN value IN acc THEN acc ELSE acc + value END
                )
                SET r.chunk_indices = reduce(
                    acc = coalesce(r.chunk_indices, []),
                    value IN coalesce(e.chunk_indices, []) |
                    CASE WHEN value IN acc THEN acc ELSE acc + value END
                )
                SET r.page_chunk_indices = reduce(
                    acc = coalesce(r.page_chunk_indices, []),
                    value IN coalesce(e.page_chunk_indices, []) |
                    CASE WHEN value IN acc THEN acc ELSE acc + value END
                )
                SET r.source_refs = reduce(
                    acc = coalesce(r.source_refs, []),
                    value IN coalesce(e.source_refs, []) |
                    CASE WHEN value IN acc THEN acc ELSE acc + value END
                )
                SET r.count = size(coalesce(r.source_refs, []))
                """

                session.run(edge_query, batch=batch_edges).consume()

        return True

    except Exception as e:
        print(f"   ⚠️ Neo4j Batch Error: {e}")
        return False


def validate_neo4j_graph_model(doc_id: str) -> None:
    """Verifica il modello Document -> Page -> Chunk -> Entity."""
    if not NEO4J_ENABLED or not neo4j_driver or not doc_id:
        return

    try:
        with neo4j_driver.session() as session:
            summary = session.run(
                """
                MATCH (d:Document {doc_id: $doc_id})
                OPTIONAL MATCH (d)-[:HAS_PAGE]->(p:Page)
                OPTIONAL MATCH (p)-[:HAS_CHUNK]->(c:Chunk)
                OPTIONAL MATCH (c)-[:MENTIONS]->(e:Entity)
                RETURN
                    count(DISTINCT p) AS pages,
                    count(DISTINCT c) AS chunks,
                    count(DISTINCT e) AS entities,
                    count(DISTINCT [c.id, e.id]) AS mentions
                """,
                doc_id=doc_id,
            ).single()

            legacy_page = session.run(
                """
                MATCH (d:Document {doc_id: $doc_id})-[:HAS_PAGE]->(p:Page)
                MATCH (:Entity)-[r:PRESENT_ON]->(p)
                RETURN count(r) AS total
                """,
                doc_id=doc_id,
            ).single()["total"]

            legacy_chunk = session.run(
                """
                MATCH (d:Document {doc_id: $doc_id})-[:HAS_PAGE]->(:Page)
                      -[:HAS_CHUNK]->(c:Chunk)
                MATCH (:Entity)-[r:PRESENT_IN|MENTIONED_IN]->(c)
                RETURN count(r) AS total
                """,
                doc_id=doc_id,
            ).single()["total"]

            print(
                "   🧭 Graph Model Check | "
                f"pages={summary['pages']} | chunks={summary['chunks']} | "
                f"entities={summary['entities']} | mentions={summary['mentions']} | "
                f"legacy_page_links={legacy_page} | "
                f"legacy_reverse_chunk_links={legacy_chunk}"
            )

    except Exception as e:
        print(f"   ⚠️ Graph Model Check Error: {e}")

def flush_neo4j_formulas_batch(rows: List[Dict[str, Any]]):
    if not NEO4J_ENABLED or not rows:
        return True
    try:
        with neo4j_driver.session() as session:
            session.run(NEO4J_FORMULA_QUERY, rows=rows).consume()
        return True
    except Exception:
        raise


# =========================
# LLM / Vision
# =========================
def llm_chat(prompt: str, text: str, model: str, max_tokens: int = LLM_MAX_TOKENS) -> str:
    """
    Chiamata testuale a Ollama usata soprattutto per KG extraction.
    Usa HTTP /api/chat con timeout reale, così lo script non resta appeso
    se Ollama non risponde.
    """
    return ollama_chat_http(
        model=model,
        messages=[
            {"role": "system", "content": prompt},
            {"role": "user", "content": text},
        ],
        options={
            "temperature": LLM_TEMPERATURE,
            "num_predict": int(max_tokens) if max_tokens is not None else LLM_MAX_TOKENS,
        },
        response_format_json=False,
        timeout_s=OLLAMA_KG_TIMEOUT_S,
    )


# ==============================================================================
# API CALLER (OLLAMA NATIVE - MINISTRAL OPTIMIZED)
# ==============================================================================
# Assicurati di avere in cima al file: from ollama import chat, ChatResponse

# ==============================================================================
# API CALLER (OLLAMA NATIVE LIBRARY)
# ==============================================================================
# Assicurati di avere l'import in alto: from ollama import chat, ChatResponse

# ---- Limiti di concorrenza Ollama per workload ----
#
# Le chiamate testuali/KG e le chiamate Vision
# usano semafori separati.
#
# Prima fase:
# - massimo 2 chiamate testuali concorrenti;
# - massimo 1 chiamata Vision concorrente.
OLLAMA_TEXT_PARALLELISM = max(
    1,
    int(
        os.getenv(
            "OLLAMA_TEXT_PARALLELISM",
            "2",
        )
    ),
)

OLLAMA_VISION_PARALLELISM = max(
    1,
    int(
        os.getenv(
            "OLLAMA_VISION_PARALLELISM",
            "1",
        )
    ),
)

OLLAMA_TEXT_SEMAPHORE = (
    threading.BoundedSemaphore(
        OLLAMA_TEXT_PARALLELISM
    )
)

OLLAMA_VISION_SEMAPHORE = (
    threading.BoundedSemaphore(
        OLLAMA_VISION_PARALLELISM
    )
)



# Endpoint unico e configurabile.
# - Esecuzione Windows/.venv: default http://127.0.0.1:11434
# - Docker Compose: impostare OLLAMA_BASE_URL=http://ollama_assessment:11434
OLLAMA_API_CHAT = os.getenv(
    "OLLAMA_API_CHAT",
    f"{OLLAMA_BASE_URL}/api/chat",
)
OLLAMA_API_GENERATE = os.getenv(
    "OLLAMA_API_GENERATE",
    f"{OLLAMA_BASE_URL}/api/generate",
)


# Timeout separati: evitano che una singola chiamata Ollama sembri bloccare tutta l'ingestion.
OLLAMA_TIMEOUT_S = int(
    os.getenv("OLLAMA_TIMEOUT_S", "240")
)

OLLAMA_VISION_TIMEOUT_S = int(
    os.getenv(
        "OLLAMA_VISION_TIMEOUT_S",
        str(OLLAMA_TIMEOUT_S),
    )
)

OLLAMA_KG_TIMEOUT_S = int(
    os.getenv("OLLAMA_KG_TIMEOUT_S", "180")
)

OLLAMA_RETRIES = int(
    os.getenv("OLLAMA_RETRIES", "1")
)

OLLAMA_REQUEST_KEEP_ALIVE = os.getenv(
    "OLLAMA_REQUEST_KEEP_ALIVE",
    "30m",
)

OLLAMA_LOG_TIMINGS = (
    os.getenv("OLLAMA_LOG_TIMINGS", "1") == "1"
)


def _log_ollama_timings(
    label: str,
    model: str,
    data: Dict[str, Any],
) -> None:
    if not OLLAMA_LOG_TIMINGS:
        return

    if not isinstance(data, dict):
        return

    load_ms = (
        int(data.get("load_duration") or 0)
        / 1_000_000
    )

    prompt_ms = (
        int(data.get("prompt_eval_duration") or 0)
        / 1_000_000
    )

    eval_ms = (
        int(data.get("eval_duration") or 0)
        / 1_000_000
    )

    eval_count = int(
        data.get("eval_count") or 0
    )

    tok_s = (
        eval_count / (eval_ms / 1000.0)
        if eval_ms > 0
        else 0.0
    )

    print(
        f"   📈 Ollama {label} | "
        f"model={model} | "
        f"load={load_ms:.0f}ms | "
        f"prompt={prompt_ms:.0f}ms | "
        f"generation={eval_ms:.0f}ms | "
        f"output_tokens={eval_count} | "
        f"tok/s={tok_s:.1f}"
    )


def ollama_chat_http(
    *,
    model: str,
    messages: List[Dict[str, str]],
    options: Optional[Dict[str, Any]] = None,
    response_format_json: bool = False,
    timeout_s: Optional[int] = None,
) -> str:
    """
    Chiamata testuale Ollama con timeout reale via HTTP /api/chat.

    Perché serve:
    - ollama.chat() può rimanere appeso senza timeout visibile lato script;
    - fut.result(timeout=...) non uccide il thread se la chiamata Ollama resta bloccata;
    - con producer/consumer e P5000 è meglio serializzare tutte le chiamate LLM/Vision.
    """
    payload: Dict[str, Any] = {
        "model": model,
        "messages": messages,
        "stream": False,
        "keep_alive": OLLAMA_REQUEST_KEEP_ALIVE,
        "options": options or {},
    }
    
    if response_format_json:
        payload["format"] = "json"

    effective_timeout = int(timeout_s or OLLAMA_KG_TIMEOUT_S)
    last_err = None

    with OLLAMA_TEXT_SEMAPHORE:
        for attempt in range(
            OLLAMA_RETRIES + 1
        ):
            
            
            try:
                r = requests.post(
                    OLLAMA_API_CHAT,
                    json=payload,
                    timeout=effective_timeout,
                )
                r.raise_for_status()

                data = r.json() or {}

                _log_ollama_timings(
                    "chat",
                    model,
                    data,
                )
                msg = data.get("message") or {}

                return (
                    msg.get("content") or ""
                ).strip()

            except Exception as e:
                last_err = e
                sleep_s = min(3.0, 0.75 * (attempt + 1))
                print(
                    f"   ⚠️ Ollama chat retry {attempt + 1}/{OLLAMA_RETRIES + 1} "
                    f"| model={model} | err={e}"
                )
                time.sleep(sleep_s)

    print(f"   ❌ Ollama chat failed | model={model} | err={last_err}")
    return ""


def llm_chat_multimodal(
    prompt: str,
    image_bytes: bytes,
    model: str,
    max_tokens: int = 4000,
    num_ctx: int = VISION_PAGE_NUM_CTX,
    response_format_json: bool = False,
    force_json: Optional[bool] = None,
    log_label: str = "vision",
) -> str:
    """
    Vision via Ollama /api/generate (robusto).
    - max_tokens -> options.num_predict
    - timeout + retry
    - lock per evitare deadlock con Vision in parallelo
    - response_format_json: usa format='json' per forzare JSON valido
    - force_json: alias compatibile con chiamate già presenti nel codice
    """
    if not image_bytes:
        return ""

    # ✅ alias: se qualcuno chiama force_json=True, lo mappiamo su response_format_json
    if force_json is not None:
        response_format_json = bool(force_json)

    try:
        img_b64 = base64.b64encode(image_bytes).decode("utf-8")
    except Exception as e:
        print(f"   ❌ Base64 encode error: {e}")
        return ""

    payload = {
        "model": model,
        "prompt": prompt,
        "images": [img_b64],
        "keep_alive": OLLAMA_REQUEST_KEEP_ALIVE,
        "options": {
            "temperature": 0.0,
            "num_ctx": int(num_ctx),
            "num_predict": (
                int(max_tokens)
                if max_tokens is not None
                else 4000
            ),
        },
        "stream": False,
    }

    # ✅ forza JSON lato Ollama (riduce drasticamente parse-fail)
    if response_format_json:
        payload["format"] = "json"

    with OLLAMA_VISION_SEMAPHORE:
        last_err = None

        for attempt in range(OLLAMA_RETRIES + 1):
            try:
                r = requests.post(
                    OLLAMA_API_GENERATE,
                    json=payload,
                    timeout=OLLAMA_VISION_TIMEOUT_S,
                )
                r.raise_for_status()

                data = r.json() or {}
                _log_ollama_timings(
                    log_label,
                    model,
                    data,
                )
                return data.get("response", "") or ""

            except Exception as e:
                last_err = e
                sleep_s = min(3.0, 0.75 * (attempt + 1))
                time.sleep(sleep_s)

        print(f"   ⚠️ Vision generate failed (model={model}): {last_err}")
        return ""


def _downscale_and_compress_for_vision(
    img_bytes: bytes,
    max_side: int = 1800,
    jpeg_quality: int = 92,
    output_format: str = "PNG",   # ✅ CHART: PNG = testo più nitido
) -> bytes:
    """
    Prepara immagini per Vision mantenendo il testo leggibile.
    - PNG consigliato per grafici (etichette piccole).
    - JPEG ok per foto, ma può "impastare" le scritte.
    """
    try:
        from PIL import Image
        import io

        img = Image.open(io.BytesIO(img_bytes)).convert("RGB")
        w, h = img.size

        scale = min(1.0, max_side / max(w, h))
        if scale < 1.0:
            img = img.resize((max(1, int(w * scale)), max(1, int(h * scale))), Image.LANCZOS)

        buf = io.BytesIO()
        fmt = (output_format or "PNG").upper().strip()

        if fmt == "JPEG" or fmt == "JPG":
            img.save(buf, format="JPEG", quality=int(jpeg_quality), optimize=True)
        else:
            # ✅ PNG: preserva edge e testo
            img.save(buf, format="PNG", optimize=True)

        return buf.getvalue()
    except Exception:
        return img_bytes



def ocr_extract_text(img_bytes: bytes) -> str:
    """
    Deterministic OCR used ONLY to assist Vision on titles/sources.
    No hallucinations possible here.
    """
    try:
        import pytesseract
        from PIL import Image
        import io

        img = Image.open(io.BytesIO(img_bytes))
        text = pytesseract.image_to_string(img, lang="ita+eng")
        return normalize_ws(text)
    except Exception:
        return ""

def render_full_page_png(page_obj, dpi: int = 200) -> bytes:
    """
    Render pagina PDF in PNG (migliore per formule e testo fine).
    """
    zoom = dpi / 72.0
    mat = fitz.Matrix(zoom, zoom)
    pix = page_obj.get_pixmap(matrix=mat, alpha=False)
    return pix.tobytes("png")


def render_full_page_jpeg(page: fitz.Page, dpi: int = VISION_DPI) -> bytes:
    pix = page.get_pixmap(dpi=dpi, alpha=False)
    return pix.tobytes("jpg")

# --- Vision cache (in-memory) ---
# chiave: sha256(image_bytes) / valore: json vision
_vision_cache: Dict[str, Dict[str, Any]] = {}
_vision_cache_order: List[str] = []

def _tenant_cache_key(key: str) -> str:
    tenant_key = _current_output_tenant_key()
    corpus_version = str(
        getattr(_OUTPUT_DB_CONTEXT, "corpus_version", CORPUS_VERSION)
    )
    return f"{tenant_key}|{corpus_version}|{VISION_MODEL_NAME}|{key}"


def _vision_cache_get(key: str) -> Optional[Dict[str, Any]]:
    return _vision_cache.get(_tenant_cache_key(key))

def _vision_cache_put(key: str, val: Dict[str, Any]):
    key = _tenant_cache_key(key)
    if key in _vision_cache:
        return
    _vision_cache[key] = val
    _vision_cache_order.append(key)
    if len(_vision_cache_order) > VISION_CACHE_MAX:
        old = _vision_cache_order.pop(0)
        _vision_cache.pop(old, None)


def extract_formulas_vision(img_bytes: bytes) -> Optional[Dict[str, Any]]:
    """
    Estrazione Formule V3: Supersampling + PNG per pedici nitidi.
    """
    if not img_bytes:
        return None

    # 1. UPSCALING AGGRESSIVO (Fondamentale per i vettoriali renderizzati)
    # 2400px garantisce che un pedice 'i' sia leggibile.
    # PNG è obbligatorio: il JPEG 'sbaverebbe' le linee sottili delle frazioni.
    vbytes = _downscale_and_compress_for_vision(
        img_bytes,
        max_side=FORMULA_VISION_MAX_SIDE,
        output_format="PNG",
        jpeg_quality=100,
    )
    
    key = sha256_hex(vbytes) + "::formula_latex_v3_highres"
    cached = _vision_cache_get(key)
    if cached:
        return cached

    try:
        # Usa il nuovo prompt LaTeX-centrico
        raw = llm_chat_multimodal(
            FORMULA_VISION_PROMPT,
            vbytes,
            VISION_MODEL_NAME,
            max_tokens=FORMULA_VISION_MAX_TOKENS,
            num_ctx=FORMULA_VISION_NUM_CTX,
            response_format_json=True,
            log_label="formula",
        )
        
        js = safe_json_extract(raw)
        if not js or ("formulas" not in js and "summary_it" not in js):
            return None
            
        _vision_cache_put(key, js)
        return js
    except Exception as e:
        print(f"   ⚠️ Formula Vision Error: {e}")
        return None


def normalize_chart_json_for_semantics(js: Dict[str, Any], page_no: int, context_hint: str = "") -> Dict[str, Any]:
    """
    Normalizza output Vision eterogeneo (V8 - Robustezza Totale).
    Gestisce varianti di schema (value/values, category/labels) tipiche di Ministral/Qwen.
    """
    if not isinstance(js, dict):
        return {}

    out = dict(js)  # shallow copy

    # ----------------------------
    # Page Alignment
    # ----------------------------
    out["page_no"] = page_no

    # ----------------------------
    # Kind / Toon Type Inference
    # ----------------------------
    if not out.get("kind"):
        # Se ci sono dati strutturati e assi, è probabilmente un grafico a barre
        if out.get("data_points") and (out.get("x-axis_labels") or out.get("x_axis_labels")):
            out["kind"] = "bar_chart"
        else:
            out["kind"] = out.get("toon_type") or "immagine"

    # Uniformiamo toon_type per il downstream (Neo4j/Postgres)
    out["toon_type"] = "immagine"

    # ----------------------------
    # Timeframe Auto-Detection
    # ----------------------------
    tf = out.get("timeframe")
    if not tf or str(tf).strip() in ("", "NOT READABLE", "None"):
        # Se timeframe è vuoto, cerca anni nelle etichette dell'asse X
        xlab = out.get("x-axis_labels") or out.get("x_axis_labels") or out.get("xAxis") or []
        if isinstance(xlab, (list, tuple)):
            years = []
            for v in xlab:
                years += re.findall(r"\b(19\d{2}|20\d{2})\b", str(v))
            years = list(dict.fromkeys(years))  # unique preserving order
            if len(years) >= 2:
                out["timeframe"] = f"{years[0]} vs {years[-1]}"
            elif len(years) == 1:
                out["timeframe"] = years[0]

    # ----------------------------
    # Confidence Score Calculation
    # ----------------------------
    conf = out.get("confidence", None)
    try:
        conf = float(conf) if conf is not None else None
    except Exception:
        conf = None

    if conf is None:
        # Euristica: calcola un punteggio basato sulla completezza dei dati
        score = 0.25
        if out.get("title"): score += 0.15
        if out.get("source"): score += 0.10
        if out.get("unit_of_measure"): score += 0.05

        dps = out.get("data_points") or out.get("numbers") or []
        if isinstance(dps, list):
            if len(dps) >= 2: score += 0.25
            if len(dps) >= 4: score += 0.10

        tf2 = out.get("timeframe") or ""
        if re.findall(r"\b(19\d{2}|20\d{2})\b", str(tf2)):
            score += 0.10

        # Clamp tra 0.0 e 0.95
        conf = max(0.0, min(0.95, score))

    out["confidence"] = conf

    # ----------------------------
    # Text Fields Defaults
    # ----------------------------
    if not out.get("what_is_visible_it"):
        title = str(out.get("title") or "").strip()
        uom = str(out.get("unit_of_measure") or "").strip()
        out["what_is_visible_it"] = (
            f"Grafico/immagine informativa. Titolo: {title}."
            + (f" Unità di misura: {uom}." if uom else "")
        ).strip()

    if not out.get("observations_it"):
        # Se c'è una descrizione in inglese, la usiamo come osservazione
        vtd = out.get("visual_trend_description")
        if vtd:
            out["observations_it"] = [str(vtd)]
        else:
            out["observations_it"] = []

    if not out.get("analysis_it"):
        out["analysis_it"] = ""

    # ----------------------------
    # Numbers Normalization (Legacy Sync + Robustness)
    # ----------------------------
    # Questa sezione popola 'numbers' (usato da parti legacy) usando 'data_points'
    if not out.get("numbers"):
        numbers = []
        dps = out.get("data_points") or []
        if isinstance(dps, list):
            for dp in dps[:12]: # Limitiamo a 12 per evitare payload enormi
                if isinstance(dp, dict):
                    
                    # --- FIX ROBUSTEZZA (Value/Values + Label/Category) ---
                    # 1. Cattura valori singolari o plurali
                    v_raw = dp.get("value") or dp.get("values")
                    
                    # 2. Cattura etichette in qualsiasi formato allucinato dal modello
                    l_raw = (dp.get("category") or 
                             dp.get("categories") or 
                             dp.get("label") or 
                             dp.get("labels") or 
                             "")
                    # ------------------------------------------------------

                    numbers.append({
                        "label": l_raw,
                        "value": v_raw,
                        "unit": out.get("unit_of_measure") or "",
                        "period": out.get("timeframe") or ""
                    })
        out["numbers"] = numbers

    return out


def extract_chart_via_vision(img_bytes: bytes, context_hint: str = "") -> Optional[Dict[str, Any]]:
    """
    FIX 3 (definitivo):
    - prepara immagine in PNG (testo più nitido)
    - OCR su immagine migliore
    - 2-pass retry se data_points sono pochi / NOT_READABLE
    - sceglie automaticamente l'output "migliore" (più categorie, meno NOT_READABLE)
    """
    if not img_bytes:
        return None

    def _score_chart(js: Dict[str, Any]) -> int:
        dps = js.get("data_points", [])
        if not isinstance(dps, list):
            return -9999
        n = 0
        bad = 0
        for dp in dps:
            if not isinstance(dp, dict):
                continue
            cat = str(dp.get("category", "") or "")
            val = str(dp.get("value", "") or "")
            if cat.strip():
                n += 1
            if "NOT_READABLE" in cat.upper() or "NOT_READABLE" in val.upper():
                bad += 1
        # più categorie = meglio; meno NOT_READABLE = meglio
        return (n * 10) - (bad * 25)

    # PAGE: prova a leggerla da context_hint tipo "... Page 2 ..."
    page_no = 0
    if context_hint:
        m = re.search(r"\bpage\s+(\d+)\b", context_hint, re.I)
        if m:
            try:
                page_no = int(m.group(1))
            except Exception:
                page_no = 0

    # PASS 1 (PNG nitido)
    vbytes1 = _downscale_and_compress_for_vision(img_bytes, max_side=1900, output_format="PNG")
    key1 = sha256_hex(vbytes1) + "::chart_grounded_fix3_p1"
    cached = _vision_cache_get(key1)
    if cached:
        return cached

    ocr1 = ocr_extract_text(
        vbytes1
    )

    tesseract_available = bool(
        TESSERACT_CMD
        or shutil.which("tesseract")
    )

    ocr_compact = re.sub(
        r"\W+",
        "",
        ocr1,
    )

    if (
        CHART_REQUIRE_OCR_TEXT
        and tesseract_available
        and len(ocr_compact) < CHART_MIN_OCR_CHARS
    ):
        return None

    prompt1 = CHART_DATA_PROMPT
    
    
    if context_hint:
        prompt1 += f"\n\nCONTEXT HINT: {context_hint[:600]}\n"
    if ocr1:
        prompt1 += f"\nVERIFIED OCR TEXT (Use as evidence): \"\"\"{ocr1[:1600]}\"\"\""


    raw1 = llm_chat_multimodal(
        prompt1,
        vbytes1,
        VISION_MODEL_NAME,
        max_tokens=2000,
        num_ctx=CHART_VISION_NUM_CTX,
        response_format_json=True,
        log_label="chart-pass1",
    )
    
    
    js1 = safe_json_extract(raw1)
    if not isinstance(js1, dict):
        js1 = {}

    # Condizione retry: poche categorie o NOT_READABLE presenti
    
    # Il secondo passaggio viene eseguito solo
    # quando il primo ha realmente trovato dati.
    #
    # Un logo, una foto o un diagramma privo
    # di data_points non deve generare
    # automaticamente una seconda inferenza.
    need_retry = False

    if (
        CHART_VISION_RETRY_ENABLED
        and isinstance(
            js1.get(
                "data_points",
                None,
            ),
            list,
        )
    ):
        dps1 = js1.get(
            "data_points",
            [],
        )

        n1 = sum(
            1
            for item in dps1
            if isinstance(item, dict)
            and str(
                item.get(
                    "category",
                    "",
                )
            ).strip()
        )

        has_bad = any(
            (
                "NOT_READABLE"
                in str(
                    item.get(
                        "category",
                        "",
                    )
                ).upper()
            )
            or (
                "NOT_READABLE"
                in str(
                    item.get(
                        "value",
                        "",
                    )
                ).upper()
            )
            for item in dps1
            if isinstance(item, dict)
        )

        has_first_pass_data = (
            n1 > 0
        )

        need_retry = (
            (
                has_first_pass_data
                or CHART_VISION_RETRY_ON_EMPTY
            )
            and (
                n1 < 4
                or has_bad
            )
        )

    # PASS 2 (più grande, istruzioni più “hard”)
    js2 = {}
    if need_retry:
        vbytes2 = _downscale_and_compress_for_vision(img_bytes, max_side=2600, output_format="PNG")
        ocr2 = ocr_extract_text(vbytes2)

        prompt2 = CHART_DATA_PROMPT + """
            SECOND PASS (IMPORTANT):
            - You MUST list ALL categories visible (legend + bars/lines labels), even if some values are only estimates.
            - If a category label is partially readable, return the best possible label instead of NOT_READABLE.
            - Prefer OCR evidence for labels (countries/regions) and units.
            """
        if context_hint:
            prompt2 += f"\n\nCONTEXT HINT: {context_hint[:600]}\n"
        if ocr2:
            prompt2 += f"\nVERIFIED OCR TEXT (Use as evidence): \"\"\"{ocr2[:2200]}\"\"\""


        raw2 = llm_chat_multimodal(
            prompt2,
            vbytes2,
            VISION_MODEL_NAME,
            max_tokens=2400,
            num_ctx=CHART_VISION_NUM_CTX,
            response_format_json=True,
            log_label="chart-pass2",
        )
        
        
        js2 = safe_json_extract(raw2)
        if not isinstance(js2, dict):
            js2 = {}

    # scegli output migliore
    best = js1 if _score_chart(js1) >= _score_chart(js2) else js2

    if not isinstance(best, dict) or not best:
        return None

    best_score = _score_chart(best)
    best_title = str(best.get("title") or "").strip()
    best_points = best.get("data_points") or []

    if best_score <= 0:
        return None

    if not best_title and not best_points:
        return None

    # --- CLEANING (anni / geo) ---
    tf = str(best.get("timeframe", "") or "")
    years = re.findall(r"\b(19\d{2}|20\d{2})\b", tf)
    if years:
        best["timeframe"] = " vs ".join(sorted(set(years)))

    bad_geo = [" sud", "south", " nord", "north"]
    for dp in best.get("data_points", []) if isinstance(best.get("data_points", []), list) else []:
        if not isinstance(dp, dict):
            continue
        cat = str(dp.get("category", "") or "")
        for token in bad_geo:
            if token in cat.lower():
                dp["category"] = cat.lower().replace(token, "").capitalize().strip()

    js_norm = normalize_chart_json_for_semantics(best, page_no=page_no, context_hint=context_hint)
    js_norm["semantic_description"] = build_chart_semantic_chunk(page_no, js_norm)
    js_norm["toon_type"] = "immagine"

    _vision_cache_put(key1, js_norm)
    return js_norm




def to_text(x) -> str:
    """Converte in stringa sicura (None, list annidate, dict)."""
    if x is None:
        return ""
    if isinstance(x, str):
        return x
    if isinstance(x, (list, tuple, set)):
        parts = [to_text(i) for i in x]
        parts = [p.strip() for p in parts if p and str(p).strip()]
        return "; ".join(parts)
    if isinstance(x, dict):
        # qui NON forziamo json.dumps per evitare output enorme, ma è ok usare str
        return str(x)
    return str(x)


def build_chart_semantic_chunk(page_no: int, chart_json: Dict[str, Any], prefix: str = "VISUAL") -> str:
    """
    Versione V8: Ministral-Ready.
    Accetta 'value' (singolare) e 'values' (plurale).
    """
    page_human = page_no

    if not isinstance(chart_json, dict):
        return normalize_ws(f"--- ANALISI VISUALE - Pagina {page_human} ---\n[Dati non validi]")
    
    title = to_text(chart_json.get("title", ""))
    ctype = to_text(chart_json.get("chart_type", "Grafico"))
    discriminators = to_text(chart_json.get("series_discriminators") or chart_json.get("series_legend", ""))
    
    lines = [f"--- ANALISI VISUALE ({ctype}) - Pagina {page_human} ---"]
    if title: lines.append(f"Titolo: {title}")
    if discriminators: lines.append(f"Legenda Serie: {discriminators}")

    datap = chart_json.get("data_points") or []
    if datap:
        lines.append("\nDati Estratti:")
        if not isinstance(datap, list): datap = [datap]
        
        for d in datap[:40]:
            if isinstance(d, dict):
                cat = to_text(d.get("category", ""))
                
                # --- FIX CRITICO PER MINISTRAL (Value vs Values) ---
                # Cerca prima 'value', se vuoto cerca 'values', se vuoto stringa vuota
                raw_val = d.get("value") or d.get("values") or ""
                
                if isinstance(raw_val, list):
                    # Unisce lista [0.8, 5.5] -> "0.8, 5.5"
                    val = ", ".join([str(v) for v in raw_val if v is not None])
                else:
                    # Pulisce stringa
                    val = to_text(raw_val).replace("[", "").replace("]", "").replace("'", "")
                # ---------------------------------------------------

                vis_check = to_text(d.get("visual_check", ""))
                check_str = f" ({vis_check})" if (vis_check and len(vis_check) < 80) else ""

                if cat or val:
                    lines.append(f" - {cat}: {val}{check_str}")

    return normalize_ws("\n".join(lines))


# =========================
# Chunk builders
# =========================
def build_formula_semantic_chunk(page_no: int, formulas_json: Dict[str, Any]) -> str:
    """
    Crea un chunk ottimizzato per il RAG contenente spiegazioni e LaTeX puro.
    FIX ROBUSTEZZA: Gestisce casi in cui 'latex' è una lista o dict invece di str.
    """
    formulas = (formulas_json or {}).get("formulas") or []
    summary = (formulas_json or {}).get("summary_it") or ""
    
    if not formulas and not summary:
        return ""

    lines = [f"--- FORMULE E MODELLI MATEMATICI - Pagina {page_no} ---"]
    if summary:
        lines.append(f"Contenuto: {summary}\n")

    for f in formulas:
        desc = f.get("meaning_it") or f.get("description_it") or "Formula"
        
        # --- FIX QUI: Normalizzazione forzata a stringa ---
        raw_latex = f.get("latex", "")
        if isinstance(raw_latex, list):
            # Se è una lista, uniamo gli elementi
            latex_str = " ".join([str(x) for x in raw_latex])
        elif isinstance(raw_latex, dict):
            latex_str = str(raw_latex)
        else:
            latex_str = str(raw_latex)
            
        # Ora possiamo fare replace sicuro
        latex = latex_str.replace("\\\\", "\\") 
        # --------------------------------------------------
        
        vars_list = []
        # Fix anche per variables se il modello impazzisce
        raw_vars = f.get("variables", [])
        if isinstance(raw_vars, list):
            for v in raw_vars:
                if isinstance(v, dict):
                    vars_list.append(f"{v.get('name')}: {v.get('meaning')}")
                elif isinstance(v, str):
                    vars_list.append(v)
        
        vars_str = "; ".join(vars_list)
        
        # Blocco semantico: Concetto + LaTeX + Variabili
        block = f"## {desc}\nModello (LaTeX): $${latex}$$\nVariabili: {vars_str}"
        lines.append(block)

    return "\n".join(lines).strip()


# =========================
# KG extraction (LLM) - ROBUST DEBUG & RETRY
# =========================
def llm_extract_kg(filename: str, page_no, text: str, model_name: str):
    """
    Estrazione KG Unificata e Pulita.
    Schema FLAT ottimizzato per LLM 8B/9B.
    """
    base = os.path.basename(str(filename))
    if not text or len(text) < 50:
        return [], []

    # UNICO PROMPT: FLAT SCHEMA
    FLAT_KG_PROMPT = """You are an expert Compliance Auditor, Cybersecurity Analyst, and Data Engineer.

CRITICAL DISAMBIGUATION RULES FOR NEO4J:
- For generic parameters, assets, controls, processes, or rules, append the core topic when needed, e.g., "Backup (Business Continuity)" or "Notification (Incident Management)".
- Do not create isolated generic nodes.
- Ensure each extracted entity is strictly relevant to IT security, risk management, audit, compliance, privacy, governance, or regulatory obligations.
- Keep node IDs stable, human-readable, and close to the wording used in the text.

CRITICAL JSON SCHEMA REQUIREMENT:
Every node object MUST contain EXACTLY these 5 keys:
1. "id": Entity name, concept, control, process, function, authority, obligation, requirement, finding, or technical object.
2. "category": Chosen from the Taxonomy.
3. "description": Brief definition EXTRACTED FROM THE TEXT. Keep the original language of the text.
4. "formula": If there is a strict technical rule or mathematical formula, extract it here. Otherwise, use "".
5. "synonyms": Array of alternative names, acronyms, or translations explicitly present in the input text.

TAXONOMY:
- ORGANIZATION
- PERSON
- ROLE
- AUTHORITY
- REGULATION
- FRAMEWORK
- STANDARD
- POLICY_OR_PROCEDURE
- PROCESS
- PHASE
- FUNCTION
- CONTROL
- MEASURE
- REQUIREMENT
- OBLIGATION
- NOTIFICATION
- EVIDENCE
- FINDING
- GAP
- REMEDIATION
- COMPLIANCE_STATUS
- ASSET
- DATA
- INCIDENT
- EVENT
- RISK
- THREAT
- VULNERABILITY
- IMPACT
- METRIC
- FORMULA
- CONCEPT

RELATION VOCABULARY. Use ONLY these EXACT UPPERCASE relation types:

STRUCTURE:
- IS_A
- PART_OF
- HAS_COMPONENT
- CONTAINS
- BELONGS_TO
- APPLIES_TO
- MAPS_TO
- DEFINES
- CLASSIFIES

GOVERNANCE / COMPLIANCE:
- COMPLIES_WITH
- NON_COMPLIANT_WITH
- HAS_COMPLIANCE_STATUS
- HAS_GAP
- REQUIRES_REMEDIATION
- REMEDIATES
- MANDATES
- REQUIRES
- GOVERNS
- APPROVES
- REVIEWS
- ASSIGNS_RESPONSIBILITY_TO

INCIDENT / PROCESS:
- TRIGGERS
- ACTIVATES
- STARTS
- FOLLOWS
- PRECEDES
- LEADS_TO
- ESCALATES_TO
- MANAGES
- HANDLES
- CONTAINS_INCIDENT
- ERADICATES
- RECOVERS
- CLOSES
- IMPROVES

NOTIFICATION / AUTHORITY:
- NOTIFIES
- REPORTS_TO
- RECEIVES_NOTIFICATION
- REQUIRES_NOTIFICATION_TO
- HAS_DEADLINE
- HAS_RECIPIENT
- COMMUNICATES_TO

NIST / FRAMEWORK:
- SUPPORTS
- ENABLES
- IMPLEMENTS
- DEPENDS_ON
- ALIGNS_WITH
- CONTRIBUTES_TO
- MEASURES
- MONITORS

RISK / SECURITY:
- MITIGATES
- REDUCES
- THREATENS
- EXPLOITS
- PROTECTS
- VULNERABLE_TO
- COMPROMISES
- IMPACTS
- AFFECTS
- EXPOSES

AUDIT / EVIDENCE:
- GENERATES
- VERIFIES
- TESTS
- DEMONSTRATES
- DOCUMENTS
- SUPPORTS_EVIDENCE_FOR

GRAPH EXTRACTION RULES:
1. Every edge MUST be supported by explicit evidence in the input text.
2. Do not infer relations that are only generally plausible.
3. If the text describes conformity, compliance, non-compliance, audit gaps, findings, deviations, missing controls, partial implementation, or remediation actions, use:
   - COMPLIES_WITH
   - NON_COMPLIANT_WITH
   - HAS_COMPLIANCE_STATUS
   - HAS_GAP
   - REQUIRES_REMEDIATION
   - REMEDIATES
4. If the text describes a sequence, obligation, responsibility, notification flow, incident lifecycle, authority interaction, deadline, or framework function, use PROCESS, OBLIGATION, NOTIFICATION, AUTHORITY, FUNCTION, INCIDENT, REQUIREMENT nodes when supported by the text.
5. Do not force every relation into CONTROL/RISK vocabulary.
6. Prefer process and obligation relations when the text describes procedures, deadlines, responsibilities, authorities, reporting, or lifecycle phases.
7. Use HAS_DEADLINE only when a deadline, timing, or timeframe is explicitly stated.
8. Use REPORTS_TO / NOTIFIES / RECEIVES_NOTIFICATION only when the recipient authority or role is explicit.
9. Use NON_COMPLIANT_WITH only when the text explicitly states absence, failure, non-conformity, gap, deviation, or unmet requirement.
10. Use HAS_COMPLIANCE_STATUS when the text explicitly states implemented, partially implemented, not implemented, compliant, non-compliant, partial, open, closed, or similar status.
11. Use evidence text for every edge. Keep the original language of the text.

Return ONLY valid JSON. Example of EXACT expected format:
{
  "nodes": [
    {
      "id": "Registro dei trattamenti",
      "category": "EVIDENCE",
      "description": "Documento richiesto per censire i trattamenti di dati personali.",
      "formula": "",
      "synonyms": []
    },
    {
      "id": "GDPR",
      "category": "REGULATION",
      "description": "Regolamento europeo sulla protezione dei dati personali.",
      "formula": "",
      "synonyms": ["General Data Protection Regulation"]
    }
  ],
  "edges": [
    {
      "source": "Registro dei trattamenti",
      "target": "GDPR",
      "relation": "COMPLIES_WITH",
      "evidence": "Il registro dei trattamenti è previsto dagli obblighi GDPR."
    }
  ]
}
"""
    # Prompt compatto con limiti deterministici.
    # Riduce il rischio che la risposta venga troncata
    # raggiungendo il limite num_predict.
    compact_prompt = (
        FLAT_KG_PROMPT
        + "\n\nOUTPUT LIMITS:"
        + f"\n- Return at most {KG_MAX_NODES_PER_WINDOW} nodes."
        + f"\n- Return at most {KG_MAX_EDGES_PER_WINDOW} edges."
        + "\n- Keep node and edge descriptions concise."
        + "\n- Return only the JSON object."
    )

    try:
        # Unico tentativo applicativo per questa finestra KG.
        #
        # Gli eventuali retry tecnici per timeout o errori HTTP
        # restano gestiti internamente da ollama_chat_http()
        # attraverso OLLAMA_RETRIES.
        raw_content = ollama_chat_http(
            model=model_name,
            messages=[
                {
                    "role": "system",
                    "content": compact_prompt,
                },
                {
                    "role": "user",
                    "content": (
                        "Extract entities and relations "
                        "in JSON format from this text:\n\n"
                        + text[:KG_INPUT_MAX_CHARS]
                    ),
                },
            ],
            options={
                "temperature": 0.0,
                "num_predict": KG_MAX_OUTPUT_TOKENS,
                "num_ctx": KG_NUM_CTX,
            },
            response_format_json=True,
            timeout_s=OLLAMA_KG_TIMEOUT_S,
        )

        js = safe_json_extract(raw_content)

    except Exception as exc:
        print(
            f"   ⚠️ [KG-SKIP] Pag {page_no}: "
            "estrazione KG fallita; "
            "nessun secondo tentativo LLM "
            f"({exc})"
        )
        return [], []

    # Deve essere presente un oggetto JSON.
    #
    # Non è obbligatorio che contenga nodi:
    # {"nodes": [], "edges": []}
    # è un risultato valido e non deve provocare un retry.
    if not isinstance(js, dict):
        print(
            f"   ⚠️ [KG-SKIP] Pag {page_no}: "
            "risposta JSON non valida; "
            "nessun secondo tentativo LLM."
        )
        return [], []

    # Filtriamo a monte qualsiasi allucinazione (stringhe al posto di dizionari)
    raw_nodes = js.get("nodes", js.get("entities", []))
    raw_edges = js.get("edges", js.get("relationships", []))
    
    nodes = [n for n in raw_nodes if isinstance(n, dict)]
    edges = [e for e in raw_edges if isinstance(e, dict)]

    # DEBUG RADAR
    if nodes:
        props_count = sum(1 for n in nodes if n.get("description") or n.get("formula"))
        class_count = sum(1 for n in nodes if n.get("category") and n.get("category") != "UNCLASSIFIED")
        print(f"   [DEBUG-KG] Pag {page_no}: {len(nodes)} nodi estratti -> {class_count} categorizzati, {props_count} con proprietà.")

    return nodes, edges


def extract_pdf_text_by_page_pdfminer(file_path: str) -> list[str]:
    """
    VERSIONE UPGRADE 3: Estrazione ottimizzata per velocità.
    Utilizza LAParams minimi per evitare l'analisi complessa del layout.
    """
    if extract_pages is None or LTTextContainer is None:
        return []

    # LAParams ottimizzati: disabilitiamo il rilevamento verticale e 
    # allarghiamo i margini per processare i blocchi di testo più velocemente.
    fast_params = LAParams(
        detect_vertical=False, 
        all_texts=True, 
        char_margin=2.0, 
        line_margin=0.5,
        word_margin=0.1
    )
    
    pages: list[str] = []
    try:
        # L'argomento 'caching=True' è fondamentale per non ri-analizzare 
        # le risorse comuni (font, immagini) ad ogni cambio pagina.
        for layout in extract_pages(file_path, laparams=fast_params, caching=True):
            # Usiamo una list comprehension per una raccolta dei chunk più rapida
            chunks = [element.get_text() for element in layout if isinstance(element, LTTextContainer)]
            pages.append("".join(chunks))
    except Exception as e:
        print(f"   ⚠️ PDFMiner Extraction Error: {e}")
        return []

    return pages


# ==============================================================================
# HELPER: CHUNKING RICORSIVO (Text Splitter)
# ==============================================================================
def recurse_text_chunking(text: str, base_meta: Dict[str, Any], max_chars: int = 1200) -> List[Dict[str, Any]]:
    """
    Versione Ottimizzata: Aumentata la soglia max_chars a 1200 (da 1000)
    per ridurre il numero totale di nodi e chunk.
    """
    text = text.strip()
    if not text:
        return []

    # CASO BASE: Aumentiamo la tolleranza per non spezzare troppo
    if len(text) <= max_chars + 200: 
        source = base_meta.get("source", "unknown")
        p_no = base_meta.get("page", 0)
        
        # Ridotto l'header: rimosso il nome file che è già nei metadati 
        # per risparmiare token e ridurre la ripetitività nel testo semantico.
        sem_header = f"PAG. {p_no}" 
        
        meta_final = base_meta.copy()
        if "metadata_override" in base_meta:
            del meta_final["metadata_override"]
            meta_final.update(base_meta["metadata_override"])

        return [{
            "text_raw": text,
            "text_sem": f"{sem_header}: {text}",
            "page_no": p_no,
            "toon_type": base_meta.get("type", "text"),
            "section_hint": "content",
            "image_id": base_meta.get("original_image_id"),
            "metadata_override": meta_final
        }]
    
    # ... resto della logica ricorsiva ...
    # LOGICA RICORSIVA: Il testo è troppo lungo
    chunks = []
    
    # 1. Gerarchia separatori (dal più forte al più debole)
    separators = ["\n\n", "\n", ". ", " "]
    split_char = ""
    
    for sep in separators:
        if sep in text:
            # Verifica euristica: se splittiamo qui, otteniamo pezzi validi?
            temp_parts = text.split(sep)
            if len(temp_parts) > 1:
                split_char = sep
                break
    
    # 2. Se nessun separatore funziona (taglio brutale)
    if not split_char:
        mid = len(text) // 2
        return (
            recurse_text_chunking(text[:mid], base_meta, max_chars) + 
            recurse_text_chunking(text[mid:], base_meta, max_chars)
        )

    # 3. Accumulatore (Greedy Bin Packing)
    raw_parts = text.split(split_char)
    current_chunk_str = ""
    
    for part in raw_parts:
        candidate = part if not current_chunk_str else (current_chunk_str + split_char + part)
        
        if len(candidate) <= max_chars:
            current_chunk_str = candidate
        else:
            if current_chunk_str:
                chunks.extend(recurse_text_chunking(current_chunk_str, base_meta, max_chars))
            current_chunk_str = part

    # 4. Aggiungi l'ultimo pezzo rimasto
    if current_chunk_str:
        chunks.extend(recurse_text_chunking(current_chunk_str, base_meta, max_chars))

    return chunks


def prep_text_for_embedding(s: str, max_chars: int = 1800) -> str:
    """
    PDF-optimized: riduce rumore e costo tokenizer.
    - rimuove header "Doc: ...\n" se presente
    - normalizza whitespace
    - tronca a max_chars (importantissimo per i PDF)
    """
    if not s:
        return ""
    s = s.strip()
    s = re.sub(r"^Doc:\s.*?\n", "", s, flags=re.DOTALL)
    s = re.sub(r"\s+", " ", s).strip()
    if len(s) > max_chars:
        s = s[:max_chars]
    return s


# ==============================================================================
# MOTORE VISIONE QWEN (Thread-Safe + Vision Supremacy)
# ==============================================================================
# ==============================================================================
def extract_pdf_chunks(file_path: str, log_id: int) -> List[Dict[str, Any]]:
    """
    Strategia 'Vision-First' con Classificazione Granulare (Per-Chunk).
    """
    out_chunks = []
    filename = os.path.basename(file_path)

    # Reset stats
    if "VISION_STATS" in globals() and "_VISION_STATS_LOCK" in globals():
        with _VISION_STATS_LOCK: VISION_STATS["pages_total"] = 0

    try:
        doc0 = fitz.open(file_path)
        total_pages = len(doc0)
        doc0.close()
    except Exception as e:
        print(f"   ❌ Errore critico file {filename}: {e}")
        return []

    print(f"   🚀 Ingestion: {total_pages} pagine | Vision: {VISION_MODEL_NAME} | Brain: {LLM_MODEL_NAME}")

    # --- WORKER INTERNO ---
    def process_page_worker(p_idx: int):
        p_no = p_idx + 1
        local_res = []
        doc_worker = None
        try:
            doc_worker = fitz.open(file_path)
            page = doc_worker.load_page(p_idx)
            
            # 1. Rendering
            zoom = VISION_DPI / 72
            mat = fitz.Matrix(zoom, zoom)
            pix = page.get_pixmap(matrix=mat, alpha=False)
            img_bytes = pix.tobytes("png")
            # ✅ riduce tempo + VRAM + rischio blocchi Vision
            img_bytes = _downscale_and_compress_for_vision(img_bytes, max_side=1400, jpeg_quality=90)
            # 2. Salva img nel DB
            img_id = None
            t_conn = pg_get_conn()
            if t_conn:
                try:
                    with t_conn.cursor() as t_cur:
                        # Salva lo screenshot della pagina intera
                        img_id = pg_save_image(log_id, img_bytes, "image/png", f"Page_{p_no}", cur=t_cur)
                    t_conn.commit()
                except Exception as e:
                    print(f"   ⚠️ Errore salvataggio immagine PG (Pagina {p_no}): {e}")
                    t_conn.rollback()
                finally:
                    pg_put_conn(t_conn)

            # 3. VISIONE TOTALE
            chunk_text = llm_chat_multimodal(
                prompt=VISION_FIRST_PROMPT, 
                image_bytes=img_bytes, 
                model=VISION_MODEL_NAME 
            )

            # 4. Creazione Chunk
            if chunk_text and "NO_CONTENT" not in chunk_text and len(chunk_text) > 10:
                
                # Partiamo assumendo che sia tutto TESTO.
                # La classificazione avverrà pezzo per pezzo DOPO lo split.
                meta = {
                    "source": filename, 
                    "page": p_no, 
                    "type": "text", # Default
                    "original_image_id": img_id
                }
                
                # Generiamo i chunk grezzi
                # 1. Generazione chunk con soglia più alta per evitare frammentazione eccessiva
                # Usiamo CHUNK_MAX_CHARS (consigliato 1200-1500)
                raw_chunks = recurse_text_chunking(chunk_text, meta, max_chars=CHUNK_MAX_CHARS)
                
                # 2. Set per la deduplicazione semantica locale (per pagina)
                seen_hashes = set()
                
                # 3. POST-PROCESSING: Classificazione e Pulizia
                for ch in raw_chunks:
                    txt_content = ch.get("text_raw", "").strip()
                    
                    # --- FILTRO RIDONDANZA ---
                    # Evitiamo chunk troppo corti o duplicati esatti generati dalla ricorsione
                    content_hash = hashlib.md5(txt_content.encode()).hexdigest()[:12]
                    if len(txt_content) < 100 or content_hash in seen_hashes:
                        continue
                    seen_hashes.add(content_hash)

                    # --- CLASSIFICAZIONE GRANULARE AVANZATA ---
                    is_visual = False
                    
                    # A. Marcatori espliciti del Prompt Vision
                    visual_markers = [
                        "### 🖼️ VISUAL ANALYSIS", 
                        "*Visual Elements:*", 
                        "*Data Insights:*",
                        "ANALISI VISIVA"
                    ]
                    
                    # B. Analisi euristica del contenuto (Keywords visive)
                    # Cerca termini come "asse", "legenda", "andamento" nel chunk
                    visual_keywords = r"\b(asse|assi|axis|axes|legenda|legend|grafico|chart|plot|pendenza|slope|barre|bars)\b"
                    has_visual_terms = len(re.findall(visual_keywords, txt_content, re.IGNORECASE)) >= 2
                    
                    if any(m in txt_content for m in visual_markers) or has_visual_terms:
                        is_visual = True

                    # C. Protezione Formule: Se è presente LaTeX ($$), non classificarlo come immagine
                    # a meno che non ci siano riferimenti espliciti a grafici.
                    if "$$" in txt_content and not has_visual_terms:
                        is_visual = False

                    # 4. Assegnazione finale e salvataggio
                    ch["toon_type"] = "imagine" if is_visual else "testo"
                    local_res.append(ch)

        except Exception as e:
            print(f"   ⚠️ Error p.{p_no}: {e}")
        finally:
            if doc_worker: doc_worker.close()
            
        return local_res

    # --- ESECUZIONE PARALLELA ---
    workers = int(os.environ.get("VISION_PARALLEL_WORKERS", "1")) #3
    per_page_timeout = int(os.getenv("PDF_PAGE_TIMEOUT_S", "240"))  # timeout per pagina

    with ThreadPoolExecutor(max_workers=workers) as executor:
        future_map = {executor.submit(process_page_worker, i): i for i in range(total_pages)}

        done_count = 0
        for f in as_completed(future_map, timeout=max(per_page_timeout * total_pages, per_page_timeout)):
            p_idx = future_map[f]
            try:
                res = f.result(timeout=per_page_timeout)
                if res:
                    out_chunks.extend(res)
            except Exception as e:
                # Non bloccare ingestion: logga e vai avanti
                print(f"\n   ⚠️ Pagina {p_idx+1}/{total_pages} fallita o in timeout: {e}")

            done_count += 1
            print(f"   🔄 Processed {done_count}/{total_pages}...", end="\r")

    print("")
    out_chunks.sort(key=lambda x: x["page_no"])
    return add_context_windows(out_chunks)

def detect_page_vision_reasons(
    text: str,
) -> set:
    """
    Restituisce i motivi reali per cui una pagina
    richiede Vision.
    """
    reasons = set()

    if not text:
        return reasons

    # -----------------------------------------------------
    # 1. Corruzione del text layer PDF
    # -----------------------------------------------------
    if "(cid:" in text or "2C0D" in text:
        reasons.add("corruption")


    private_use_count = sum(
        1
        for char in text
        if "\uE000" <= char <= "\uF8FF"
    )

    control_count = sum(
        1
        for char in text
        if (
            ord(char) < 32
            and char not in "\n\r\t"
        )
    )

    bad_char_count = (
        text.count("\ufffd")
        + text.count("˜")
        + private_use_count
        + control_count
    )

    if len(text) >= 50:
        bad_char_ratio = (
            bad_char_count
            / len(text)
        )

        if (
            bad_char_count
            >= PDF_CORRUPTION_MIN_BAD_CHARS
            and bad_char_ratio
            >= PDF_CORRUPTION_BAD_CHAR_RATIO
        ):
            reasons.add("corruption")

    # -----------------------------------------------------
    # 2. Tabelle numeriche
    # -----------------------------------------------------
    chars = len(text)

    if chars > 100:
        digits = sum(
            char.isdigit()
            for char in text
        )

        density = digits / chars

        if density > PDF_TABLE_DIGIT_DENSITY:
            reasons.add("table")

            print(
                "   📊 Table Hunter Triggered: "
                f"densità numeri {density:.2f}"
            )

    # -----------------------------------------------------
    # 3. Matematica
    # -----------------------------------------------------
    # -----------------------------------------------------
    # 3. Matematica: segnali espliciti, non semplici
    # parole appartenenti al dominio del documento.
    # -----------------------------------------------------
    text_lower = text.lower()

    math_context = re.search(
        r"\b("
        r"formula|equation|equazione|"
        r"theorem|teorema|lemma|"
        r"integral|integrale|"
        r"derivative|derivata|"
        r"logarithm|logaritmo|"
        r"summation|sommatoria"
        r"variance|varianza"
        r"average|media"
        r"regression|regressione"
        r"difference|differenza"
        r"multiplication|moltiplicazione"
        r"ratio|rapporto"
        r"probability|probabilità"     
        r"calculation|calcolo"                         
        r")\b",
        text_lower,
    )

    math_symbols = re.search(
        r"[∑∏∫√∂∇∆∀∃∈∉⊆⊂∪∩"
        r"≠≈≤≥±∓∞∝∠⊥∥]",
        text,
    )

    variable_assignment = re.search(
        r"\b[A-Za-z]"
        r"[A-Za-z0-9_]{0,3}"
        r"\s*=\s*"
        r"(?:[-+]?\d|[A-Za-z]|\()",
        text,
    )

    numeric_expression = re.search(
        r"(?:\d+(?:[.,]\d+)?)"
        r"\s*(?:[+\-*/×÷^])\s*"
        r"(?:\d+(?:[.,]\d+)?)",
        text,
    )

    fraction_or_power = re.search(
        r"\b\d+\s*/\s*\d+\b"
        r"|"
        r"[A-Za-z0-9]\s*\^\s*[-+]?\d+",
        text,
    )

    context_with_expression = bool(
        math_context
        and re.search(
            r"[=<>±×÷^]",
            text,
        )
    )

    if (
        math_symbols
        or variable_assignment
        or numeric_expression
        or fraction_or_power
        or context_with_expression
    ):
        reasons.add("math")

    return reasons


def is_page_math_heavy_or_broken(
    text: str,
) -> bool:
    """
    Wrapper retrocompatibile per gli eventuali
    chiamanti esistenti.
    """
    return bool(
        detect_page_vision_reasons(text)
    )

# ==============================================================================
# PATTERN GENERALISTA PER LA MATEMATICA
# ==============================================================================
# Rileva simboli matematici universali, operatori logici, lettere greche e keyword standard.
MATH_BROAD_PAT = re.compile(
    r"(?i)("
    r"formula|equation|equazione|modello|model|theorem|teorema|lemma|"  # Keyword generiche
    r"[∑∏∫√∂∇∆∀∃∄∈∉⊆⊂∪∩≠≈≡≤≥±∓×÷∝∞]|"                             # Simboli matematici avanzati
    r"\^\{|\_\{|"                                                 # Sintassi stile LaTeX residua
    r"[a-z]_[a-z0-9]|"                                            # Pedici (es. x_i, t_0)
    r"\b[A-Za-z]=\d+"                                             # Assegnazioni (es. x=5)
    r")"
)

def extract_file_chunks(
    file_path: str,
    log_id: int,
    doc_meta: Optional[dict] = None,
) -> List[Dict[str, Any]]:
    """
    Estrazione Universale (PDF) v3.0:
    1. SINGOLO PASSAGGIO CON FITZ. Nessun doppio caricamento.
    2. Testo Nativo con OVERLAP (Rolling Buffer).
    3. Immagini Embedded (grafici raster).
    4. Matematica/Schemi (Visione su render Hi-Res).
    """
    
    # --- CONFIGURAZIONE OVERLAP ---
    OVERLAP_SIZE = 250  # Caratteri (~40 parole)
    prev_page_tail = "" # Buffer per la coda della pagina precedente
    # ------------------------------

    filename = os.path.basename(file_path)
    final_chunks: List[Dict[str, Any]] = []
    doc = None 

    # Helper per contare elementi vettoriali
    def _count_vectors(p: fitz.Page) -> int:
        try:
            ops = 0
            drawings = p.get_drawings() or []
            for d in drawings:
                ops += len(d.get("items") or [])
            return ops
        except Exception:
            return 0

    try:
        doc = fitz.open(file_path)
        # Il document_id canonico proviene esclusivamente dal Database A.
        doc_id = str((doc_meta or {}).get("document_id") or "").strip()
        
        
        if not doc_id:
            raise ValueError(
                "document_id assente nel payload del job Database A"
            )

        # Hash degli asset già processati nel documento.
        # Evita di reinviare a Vision loghi e immagini
        # identiche presenti in molte pagine.
        seen_embedded_image_hashes = set()


        # ==============================================================
        # CICLO UNICO: SCORRIAMO LE PAGINE UNA SOLA VOLTA
        # ==============================================================
        for i, page in enumerate(doc):
            page_no = i + 1
            
            
            # 1. ESTRAZIONE TESTO NATIVO CON FITZ
            page_text = page.get_text(
                "text",
                sort=True,
            )

            clean_text = page_text.strip()

            native_text_len = len(
                clean_text
            )
            
           
            # =========================================================
            # FIX VISION-NATIVE: Rilevamento Testo Corrotto / Matematica
            # =========================================================
            vision_reasons = detect_page_vision_reasons(
                page_text
            )

            use_vision_replacement = (
                PDF_VISION_ENABLED
                and bool(
                    vision_reasons.intersection(
                        {"corruption", "table"}
                    )
                )
            )

            if use_vision_replacement:
                reasons_label = ",".join(
                    sorted(vision_reasons)
                )

                print(
                    f"   👁️‍🗨️ Pagina {page_no}: "
                    "Vision-to-Markdown attivato "
                    f"| reason={reasons_label}"
                )
                
            # Se serve la Visione, sostituiamo 'clean_text' con l'output dell'LLM
            if use_vision_replacement:
                try:
                    # Carichiamo la pagina come immagine ad alta risoluzione (DPI 180)
                    hq_bytes = render_full_page_png(
                        page,
                        dpi=VISION_PAGE_DPI,
                    )
                    
                    vision_md = llm_chat_multimodal(
                        prompt=MARKER_VISION_PROMPT,
                        image_bytes=hq_bytes,
                        model=VISION_MODEL_NAME,
                        max_tokens=VISION_PAGE_MAX_TOKENS,
                        num_ctx=VISION_PAGE_NUM_CTX,
                        log_label="page-markdown",
                    )
                    
                    if len(vision_md) > 50:
                        clean_text = f"\n{vision_md}" 
                    
                except Exception as e:
                    print(f"   ⚠️ Vision fallback failed: {e}")
            # =========================================================

            # ---------------------------------------------------------
            # A) CHUNK TESTO BASE (CON OVERLAP)
            # ---------------------------------------------------------
            if len(clean_text) > MIN_CHUNK_LEN:
                
                # --- LOGICA OVERLAP ---
                header_semantico = f"Doc: {filename} | Pagina: {page_no}\n"
                
                if prev_page_tail:
                    text_semantic_content = f"{header_semantico}... {prev_page_tail}\n{clean_text}"
                else:
                    text_semantic_content = f"{header_semantico}{clean_text}"
                
                # Aggiorniamo il buffer per il prossimo giro
                if len(clean_text) > OVERLAP_SIZE:
                    prev_page_tail = clean_text[-OVERLAP_SIZE:]
                else:
                    prev_page_tail = clean_text 
                # ----------------------

                final_chunks.append({
                    "text_raw": clean_text,
                    "text_sem": text_semantic_content, 
                    "toon_type": "testo",
                    "page_no": page_no,
                    "metadata": {"source": filename, "doc_id": doc_id}
                })
            else:
                prev_page_tail = ""

            # ---------------------------------------------------------
            # B) IMMAGINI EMBEDDED (Grafici Raster, Foto)
            # ---------------------------------------------------------
            if PDF_VISION_ENABLED:
                page_objs = (
                    page.get_images(full=True)
                    or []
                )

                accepted_images = 0

                t_conn = pg_get_conn()

                try:
                    with t_conn.cursor() as t_cur:
                        for img_idx, img in enumerate(
                            page_objs
                        ):
                            if (
                                accepted_images
                                >= PDF_MAX_IMAGES_PER_PAGE
                            ):
                                break

                            xref = img[0]

                            width = int(
                                img[2] or 0
                            )

                            height = int(
                                img[3] or 0
                            )

                            try:
                                base_image = (
                                    doc.extract_image(
                                        xref
                                    )
                                )

                                img_bytes = (
                                    base_image.get(
                                        "image",
                                        b"",
                                    )
                                )

                                if not embedded_image_is_vision_candidate(
                                    img_bytes,
                                    width,
                                    height,
                                ):
                                    continue

                                image_hash = sha256_hex(
                                    img_bytes
                                )

                                if (
                                    PDF_EMBEDDED_SKIP_DUPLICATES
                                    and image_hash
                                    in seen_embedded_image_hashes
                                ):
                                    continue

                                seen_embedded_image_hashes.add(
                                    image_hash
                                )

                                accepted_images += 1

                                img_name = (
                                    f"PDF_{doc_id}"
                                    f"_P{page_no}"
                                    f"_IMG{img_idx}"
                                )

                                image_id = pg_save_image(log_id, img_bytes, "image/jpeg", img_name, cur=t_cur)

                                analysis = None
                                if PDF_VISION_ON_EMBEDDED_IMAGES and VISION_MODEL_NAME:
                                    try:
                                        analysis = extract_chart_via_vision(
                                            img_bytes,
                                            context_hint=f"Page {page_no} of {filename}"
                                        )
                                    except Exception: 
                                        analysis = None
                                
                                if analysis:
                                    sem_text = build_chart_semantic_chunk(page_no, analysis)
                                    meta = analysis
                                else:
                                    sem_text = normalize_ws(f"--- ASSET VISIVO - P{page_no} ---\nNome: {img_name}")
                                    meta = {"asset_name": img_name}

                                final_chunks.append({
                                    "text_raw": json.dumps(meta) if analysis else sem_text,
                                    "text_sem": sem_text,
                                    "toon_type": "imagine",
                                    "page_no": page_no,
                                    "image_id": image_id,
                                    "metadata": {**meta, "source": filename}
                                })

                            except Exception:
                                continue
                    t_conn.commit()
                finally:
                    pg_put_conn(t_conn)

            # ---------------------------------------------------------
            # C) MATEMATICA & VETTORIALI (Render & Transcribe)
            # ---------------------------------------------------------
            has_math_text = (
                "math" in vision_reasons
            )

            vector_count = _count_vectors(page)

            has_vectors = (
                vector_count
                > PDF_VECTOR_VISION_THRESHOLD
            )

            vector_only_formula_candidate = (
                has_vectors
                and native_text_len
                <= PDF_VECTOR_ONLY_MAX_TEXT_LEN
            )

            formula_vision_needed = (
                PDF_VISION_ENABLED
                and (
                    has_math_text
                    or vector_only_formula_candidate
                )
            )

            if (
                PDF_SKIP_FORMULA_AFTER_PAGE_VISION
                and use_vision_replacement
            ):
                formula_vision_needed = False

            if formula_vision_needed:
                try:
                    pix = page.get_pixmap(
                        dpi=FORMULA_RENDER_DPI,
                        alpha=False,
                    )

                    hq_bytes = pix.tobytes("png")

                    math_json = extract_formulas_vision(
                        hq_bytes
                    )


                    if math_json and math_json.get("formulas"):
                        sem_math = build_formula_semantic_chunk(page_no, math_json)
                    
                        # ---> AGGIUNGI QUESTA RIGA <---
                        sem_math = f"Doc: {filename} | Pagina: {page_no}\n{sem_math}"
                        
                        final_chunks.append({
                            "text_raw": json.dumps(math_json, ensure_ascii=False),
                            "text_sem": sem_math,
                            "toon_type": "formula",
                            "page_no": page_no,
                            "metadata": {
                                "source": filename,
                                "type": "mathematical_content",
                                "doc_id": doc_id,
                                "formulas_found": len(math_json.get("formulas", []))
                            }
                        })
                        print(f"   Σ  Matematica rilevata a pag {page_no}: {len(math_json['formulas'])} formule.")

                except Exception as e_math:
                    print(f"   ⚠️ Errore estrazione matematica pag {page_no}: {e_math}")

    except Exception as e:
        print(f"   ❌ Errore critico file {filename}: {e}")
        
    finally:
        if doc:
            doc.close()

        # In producer/consumer mode evitiamo unload concorrenti mentre il consumer usa Ollama.
        if (
            PDF_VISION_ENABLED
            and VISION_MODEL_NAME
            and os.getenv("PRODUCER_CONSUMER_MODE", "0") != "1"
        ):
            force_unload_ollama(VISION_MODEL_NAME)

    return final_chunks



def extract_pdf_as_markdown_assets(
    file_path: str,
    log_id: int,
    doc_meta: Optional[dict] = None,
) -> List[Dict[str, Any]]:
    """
    Estrae testo e asset da PDF.
    FIX:
    - Crea SEMPRE un chunk 'immagine' per ogni asset embedded (anche se Vision fallisce o ritorna kind=other)
    - Evita che tutto finisca come 'testo' quando il PDF contiene grafici.
    """
    chunks_payload: List[Dict[str, Any]] = []

    try:
        doc = fitz.open(file_path)
    except Exception as e:
        print(f"   ❌ Errore apertura PDF {file_path}: {e}")
        return []

    filename = os.path.basename(file_path)
    total_pages = len(doc)
    doc_id = str((doc_meta or {}).get("document_id") or "").strip()
    if not doc_id:
        raise ValueError("document_id assente nel payload del job Database A")

    print(f"   🚀 Ingestion: {total_pages} pagine | Vision: {VISION_MODEL_NAME} | Brain: {LLM_MODEL_NAME}")

    # Pulizia VRAM preventiva
    if PDF_VISION_ENABLED and VISION_MODEL_NAME:
        force_unload_ollama(VISION_MODEL_NAME)

    for i, page in enumerate(doc):
        page_no = i + 1
        try:
            # ------------------------------------------------------------
            # 1) Chunk TESTO pagina
            # ------------------------------------------------------------
            page_text = page.get_text()
            text_sem = safe_normalize_text(page_text) or ""

            # se vuoi, puoi mantenere lo skip condizionale; qui lo lasciamo conservativo
            if len(text_sem) < 50 and not PDF_VISION_ENABLED:
                continue

            page_chunk = {
                "text_raw": text_sem,
                "text_sem": f"Page {page_no} content: {text_sem[:250]}...\n{text_sem}",
                "page_no": page_no,
                "toon_type": "testo",
                "metadata": {
                    "source": filename,
                    "page": page_no,
                    "doc_id": doc_id,
                }
            }
            chunks_payload.append(page_chunk)

            # ------------------------------------------------------------
            # 2) Chunk IMMAGINI embedded (grafici inclusi)
            # ------------------------------------------------------------
            if PDF_VISION_ENABLED:
                images = page.get_images(full=True) or []
                if images:
                    for img_index, img in enumerate(images[:PDF_MAX_IMAGES_PER_PAGE]):
                        xref = img[0]
                        try:
                            base_image = doc.extract_image(xref)
                            image_bytes = base_image.get("image", b"")

                            # filtro dimensione (usa la tua soglia configurabile)
                            if not image_bytes or len(image_bytes) < MIN_ASSET_SIZE:
                                continue

                            # salva asset in Postgres
                            img_name = f"PDF_{doc_id}_P{page_no}_IMG{img_index}"
                            conn = pg_get_conn()
                            try:
                                with conn.cursor() as cur:
                                    image_id = pg_save_image(log_id, image_bytes, "image/jpeg", img_name, cur)
                                conn.commit()
                            finally:
                                pg_put_conn(conn)

                            # prova Vision
                            c_js = None
                            if PDF_VISION_ON_EMBEDDED_IMAGES and VISION_MODEL_NAME:
                                try:
                                    c_js = extract_chart_via_vision(
                                        image_bytes,
                                        context_hint=f"{filename} | page {page_no}"
                                    )
                                except Exception as _:
                                    c_js = None

                            # costruisci semantica (anche fallback)
                            conf = float((c_js or {}).get("confidence") or 0.0)
                            kind = (c_js or {}).get("kind")

                            if c_js and isinstance(c_js, dict):
                                # FIX: uniforma tipo (evita 'imagine' typo)
                                c_js["toon_type"] = "immagine"

                            CHART_MIN_CONF = float(os.getenv("CHART_MIN_CONF", "0.55"))

                            if c_js and kind != "other" and conf >= CHART_MIN_CONF:
                                sem = build_chart_semantic_chunk(page_no, c_js)
                                meta = c_js
                            else:
                                sem = normalize_ws(
                                    f"--- CONTENUTO VISIVO (immagine) - Pagina {page_no} ---\n"
                                    f"Asset: {img_name}\n"
                                    f"Nota: immagine estratta dal PDF (grafico/tabella possibile).\n"
                                    f"Stato: non interpretata automaticamente oppure conf bassa.\n"
                                    f"Hint: prova ad aumentare VISION_DPI o abbassare CHART_MIN_CONF.\n"
                                )
                                meta = {
                                    "asset_name": img_name,
                                    "confidence": conf,
                                    "kind": kind or "unknown",
                                    "toon_type": "immagine"
                                }

                            # crea chunk IMMAGE dedicato (questo è il FIX chiave)
                            img_chunk = {
                                "text_raw": sem,               # utile anche per embedding
                                "text_sem": sem,               # retrieval “forte”
                                "page_no": page_no,
                                "toon_type": "immagine",
                                "image_id": image_id,
                                "metadata": {
                                    "source": filename,
                                    "page": page_no,
                                    "doc_id": doc_id,
                                    **(meta if isinstance(meta, dict) else {})
                                }
                            }
                            chunks_payload.append(img_chunk)

                        except Exception as e_img:
                            print(f"   ⚠️ Err. Img {img_index} pg {page_no}: {e_img}")
                            continue


            # ✅ VRAM safety: no unload per pagina (troppo costoso).
            # Se serve, lasciamo solo una GC leggera.
            if PDF_VISION_ENABLED:
                gc.collect()


        except Exception as e_page:
            print(f"   ⚠️ Err. Pagina {page_no}: {e_page}")
            continue

    try:
        doc.close()
    except Exception:
        pass

    return chunks_payload



def normalize_toon_type(ch: dict) -> str:
    """
    Normalizza il tipo del chunk in una tassonomia unica usata anche dal RAG:
    text, image, table, chart, formula.
    """
    current_type = str(ch.get("toon_type", "")).lower().strip()

    if current_type in {"formula", "math", "equation"}:
        return "formula"

    if ch.get("image_id") is not None:
        return "image"

    content_raw = ch.get("text_raw", "") or ""
    content_sem = ch.get("text_sem", "") or ""

    visual_markers = [
        "### 🖼️ VISUAL ANALYSIS",
        "VISUAL ANALYSIS:",
        "*Visual Elements:*",
        "--- CONTENUTO VISUALE",
        "--- ANALISI VISUALE",
        "--- CONTENUTO VISIVO",
        "--- ASSET VISIVO",
        "![",
    ]

    table_markers = [
        "|---",
        "| ---",
        "data_table_md",
    ]

    if any(m in content_raw for m in visual_markers) or any(m in content_sem for m in visual_markers):
        return "image"

    if any(m in content_raw for m in table_markers) or any(m in content_sem for m in table_markers):
        return "table"

    if current_type in {"chart", "grafico", "chart_analysis"}:
        return "chart"

    if current_type in {"image", "immagine", "imagine", "visual", "screenshot"}:
        return "image"

    if current_type in {"table", "tabella"}:
        return "table"

    return "text"


def process_virtual_md_chunks(content: str, asset_park: dict, filename: str, log_id: int) -> List[Dict[str, Any]]:
    """
    Versione 2.9.2 (Optimized):
    - Include Debug Saving e Context Hint.
    - Prompt Merging: Rimossa la seconda chiamata LLM per l'analisi (ora fatta dalla Vision).
    """
    out_chunks = []

    # ✅ Cap Vision per documento
    vision_done = 0
    VISION_MAX_ASSETS_PER_DOC = int(os.getenv("VISION_MAX_ASSETS_PER_DOC", "25"))

    content = clean_markdown_structure(content)
    raw_paras = re.split(r'\n(?=# PAGE)|\n\n', content)

    for para in raw_paras:
        para_strip = para.strip()
        if not para_strip:
            continue

        # Identificazione Pagina
        current_page = 1
        page_match = re.search(r'# PAGE (\d+)', para_strip)
        if page_match: current_page = int(page_match.group(1))

        # Scomposizione granulare
        sub_segments = [para_strip] if len(para_strip) <= 1200 else split_text_with_overlap(para_strip, 1000, 200)

        for sub_p in sub_segments:
            clean_sub_p = safe_normalize_text(sub_p)
            
            chunk_data = {
                "text_raw": clean_sub_p,
                "text_sem": f"Doc: {filename} | Content: {clean_sub_p[:80]}...\n{clean_sub_p}",
                "page_no": current_page, 
                "toon_type": "text",
                "section_hint": find_section_hint(clean_sub_p)
            }

            # --- LOGICA ASSET VISUALI ---
            img_match = re.search(r'!\[.*?\]\(((?:img_|fig_).*?\.jpg)\)', clean_sub_p)
            if img_match and PDF_VISION_ENABLED:
                asset_id = img_match.group(1)
                img_bytes = asset_park.get(asset_id)

                if img_bytes and len(img_bytes) >= MIN_ASSET_SIZE and ai_vision_gatekeeper(img_bytes):
                    if vision_done >= VISION_MAX_ASSETS_PER_DOC:
                        out_chunks.append(chunk_data)
                        continue

                    chunk_data["toon_type"] = "immagine"
                    hint = f"{filename} | page {current_page}"

                    # Estrazione (ora include già 'analysis_it' grazie al Prompt Merging)
                    c_js = extract_chart_via_vision(img_bytes, context_hint=hint) or {}
                    vision_done += 1
                    
                    if c_js:
                        # 🔒 GEO SANITIZATION (STRICT)
                        bad_geo_tokens = [" sud", "south"]
                        cats = c_js.get("categories_it", [])
                        if isinstance(cats, list):
                            c_js["categories_it"] = [
                                c for c in cats
                                if not any(tok in c.lower() for tok in bad_geo_tokens)
                            ]

                        # 🔒 BLOCK AMBIGUOUS TIMEFRAME
                        tf = c_js.get("timeframe")
                        years = re.findall(r"\b(19\d{2}|20\d{2})\b", str(tf)) if tf else []
                        if len(years) < 2:
                            c_js.pop("timeframe", None)

                        # --- OPTIMIZATION START: Prompt Merging ---
                        # Abbiamo rimosso la chiamata a generate_chart_analysis_it()
                        # perché il dato è già presente in c_js['analysis_it'] dal modello Vision.
                        # --- OPTIMIZATION END ---

                        c_js = normalize_chart_json_for_semantics(c_js, page_no=current_page, context_hint=hint)
                        semantic = build_chart_semantic_chunk(current_page, c_js)
                        
                        # Replace semantico
                        # is_image_only: chunk che contiene solo immagine markdown (es. ![...](...)) oppure chunk di tipo image
                        md_only = (chunk_data.get("text_raw") or "").strip()

                        toon_type = (chunk_data.get("toon_type") or "").strip().lower()
                        # accetta anche il vecchio typo "imagine"
                        if toon_type == "imagine":
                            toon_type = "image"
                        chunk_data["toon_type"] = toon_type  # normalizza per downstream

                        is_image_only = (toon_type == "image") or (
                            md_only.startswith("![") and "](" in md_only and len(md_only) < 120
                        )

                        chunk_data["text_sem"] = semantic
                        if is_image_only:
                            chunk_data["text_raw"] = semantic 
                    else:
                        # Fallback se la vision fallisce o restituisce None
                        chunk_data["text_sem"] = normalize_ws(
                            f"--- CONTENUTO VISIVO - Pagina {current_page} ---\n"
                            f"Asset: {asset_id}\n"
                            f"Descrizione: immagine estratta dal PDF.\n"
                            f"Stato: non interpretata automaticamente."
                        )
                        chunk_data["text_raw"] = chunk_data["text_sem"]

                    # save image to PG
                    conn = pg_get_conn()
                    try:
                        with conn.cursor() as cur:
                                chunk_data["image_id"] = pg_save_image(
                                    log_id, img_bytes, "image/jpeg", f"RAM_{asset_id}", cur
                                )

                                # 🔥 FIX: rendi l'immagine "risolvibile" dal solo record document_chunks
                                chunk_data.setdefault("metadata", {})
                                chunk_data["metadata"]["image_id"] = chunk_data["image_id"]
                                chunk_data["metadata"]["asset_name"] = asset_id
                                chunk_data["metadata"]["mime_type"] = "image/jpeg"

                        conn.commit()
                    finally:
                        pg_put_conn(conn)

            out_chunks.append(chunk_data)
    return out_chunks



def formula_kg_from_chunk(ch: dict) -> tuple[list[dict], list[dict]]:
    """
    Converte deterministicamente il JSON Vision delle formule in nodi KG.
    Non dipende dal LLM KG.
    """
    if normalize_toon_type(ch) != "formula":
        return [], []

    raw = ch.get("text_raw") or ""
    page_no = ch.get("page_no", 1)

    try:
        js = json.loads(raw) if isinstance(raw, str) else raw
    except Exception:
        js = safe_json_extract(raw)

    if not isinstance(js, dict):
        return [], []

    formulas = js.get("formulas") or []
    if not isinstance(formulas, list):
        return [], []

    nodes = []
    edges = []
    seen_ids = set()

    for idx, f in enumerate(formulas):
        if not isinstance(f, dict):
            continue

        desc = (
            f.get("description_it")
            or f.get("meaning_it")
            or f.get("description")
            or f"Formula {idx + 1}"
        )

        raw_latex = f.get("latex", "")
        if isinstance(raw_latex, list):
            latex = " ".join(str(x) for x in raw_latex)
        elif isinstance(raw_latex, dict):
            latex = json.dumps(raw_latex, ensure_ascii=False)
        else:
            latex = str(raw_latex or "")

        latex = latex.strip()
        if not latex:
            continue

        formula_hash = sha256_hex(latex.encode("utf-8"))[:10]
        formula_id = f"Formula::P{page_no}::{formula_hash}"

        if formula_id not in seen_ids:
            nodes.append({
                "id": formula_id,
                "category": "FORMULA",
                "props": {
                    "description": str(desc),
                    "formula": latex,
                    "synonyms": [],
                    "source": "vision_formula",
                    "page_no": page_no
                }
            })
            seen_ids.add(formula_id)

        variables = f.get("variables") or []
        if isinstance(variables, list):
            for v in variables:
                if isinstance(v, dict):
                    v_name = str(v.get("name", "") or "").strip()
                    v_meaning = str(v.get("meaning", "") or "").strip()
                else:
                    v_name = str(v or "").strip()
                    v_meaning = ""

                if not v_name:
                    continue

                var_id = v_name

                if var_id not in seen_ids:
                    nodes.append({
                        "id": var_id,
                        "category": "VARIABLE",
                        "props": {
                            "description": v_meaning,
                            "formula": v_name,
                            "synonyms": [],
                            "source": "vision_formula",
                            "page_no": page_no
                        }
                    })
                    seen_ids.add(var_id)

                edges.append({
                    "source": formula_id,
                    "target": var_id,
                    "relation": "HAS_VARIABLE",
                    "props": {
                        "evidence": "Variabile estratta dal JSON Vision della formula.",
                        "source": "vision_formula"
                    }
                })

    return nodes, edges



def ensure_entity_props_defaults(nodes: list[dict]) -> list[dict]:
    """
    Garantisce che ogni nodo Entity abbia sempre:
    - description
    - formula
    - synonyms

    Non inventa sinonimi.
    """
    out = []

    for n in nodes or []:
        if not isinstance(n, dict):
            continue

        nn = dict(n)
        props = dict(nn.get("props") or {})

        props.setdefault("description", "")
        props.setdefault("formula", "")

        syn = props.get("synonyms", [])
        if syn is None:
            syn = []
        elif isinstance(syn, str):
            syn = [syn] if syn.strip() else []
        elif not isinstance(syn, list):
            syn = []

        props["synonyms"] = [str(x).strip() for x in syn if str(x).strip()]

        nn["props"] = props
        out.append(nn)

    return out

ACRONYM_PAIR_PATTERNS = [
    # Full Name (ABC)
    re.compile(
        r"\b([A-ZÀ-Úa-zà-ú][A-ZÀ-Úa-zà-ú0-9\s\-/]{4,90})\s*\(([A-Z][A-Z0-9]{1,15})\)"
    ),

    # ABC (Full Name)
    re.compile(
        r"\b([A-Z][A-Z0-9]{1,15})\s*\(([A-ZÀ-Úa-zà-ú][A-ZÀ-Úa-zà-ú0-9\s\-/]{4,90})\)"
    ),
]


def extract_local_synonym_pairs(text: str) -> dict[str, list[str]]:
    """
    Estrae sinonimi SOLO se appaiono esplicitamente nel testo.
    Non usa dizionari esterni.
    Esempi:
    - Multi-Factor Authentication (MFA)
    - MFA (Multi-Factor Authentication)
    - Disaster Recovery Plan (DRP)
    - DRP (Disaster Recovery Plan)
    """
    pairs: dict[str, list[str]] = {}

    if not text:
        return pairs

    clean = re.sub(r"\s+", " ", text).strip()

    for pat in ACRONYM_PAIR_PATTERNS:
        for a, b in pat.findall(clean):
            a = re.sub(r"\s+", " ", a).strip(" .,:;")
            b = re.sub(r"\s+", " ", b).strip(" .,:;")

            if not a or not b:
                continue

            a_is_acronym = bool(re.fullmatch(r"[A-Z][A-Z0-9]{1,15}", a))
            b_is_acronym = bool(re.fullmatch(r"[A-Z][A-Z0-9]{1,15}", b))

            if a_is_acronym and not b_is_acronym:
                canonical, synonym = b, a
            elif b_is_acronym and not a_is_acronym:
                canonical, synonym = a, b
            else:
                continue

            # evita canonical troppo rumorosi
            canonical = canonical.strip()
            synonym = synonym.strip()

            if len(canonical) < 4 or len(synonym) < 2:
                continue

            pairs.setdefault(canonical, [])
            if synonym not in pairs[canonical]:
                pairs[canonical].append(synonym)

    return pairs


def enrich_synonyms_from_local_text(nodes: list[dict], text: str) -> list[dict]:
    """
    Aggiunge sinonimi document-grounded ai nodi.
    Non inventa sinonimi: usa solo pattern presenti nel testo.
    """
    if not nodes or not text:
        return nodes

    local_pairs = extract_local_synonym_pairs(text)
    if not local_pairs:
        return nodes

    out = []

    for n in nodes:
        if not isinstance(n, dict):
            continue

        nn = dict(n)
        nid = str(nn.get("id", "") or "").strip()
        props = dict(nn.get("props") or {})

        syn = props.get("synonyms", [])
        if syn is None:
            syn = []
        elif isinstance(syn, str):
            syn = [syn] if syn.strip() else []
        elif not isinstance(syn, list):
            syn = []

        # Match sul nome canonico
        for canonical, synonyms in local_pairs.items():
            if nid.lower() == canonical.lower():
                for s in synonyms:
                    if s not in syn:
                        syn.append(s)

            # Match inverso: se il nodo è l'acronimo, aggiungi il full name come synonym
            for s in synonyms:
                if nid.lower() == s.lower() and canonical not in syn:
                    syn.append(canonical)

        props["synonyms"] = [str(x).strip() for x in syn if str(x).strip()]
        nn["props"] = props
        out.append(nn)

    return out




# =========================
# PIPELINE AI E PERSISTENZA OUTPUT
# =========================

def mark_ingestion_run_partial_failure(
    *,
    log_id: int,
    ingestion_run_id: str,
    doc_id: str,
    point_ids: List[str],
    error: Exception,
) -> None:
    """Compensazione best-effort: rende invisibili tutti gli artefatti parziali."""
    message = str(error)[:2000]
    try:
        conn = pg_get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE public.document_chunks SET status='failed' WHERE ingestion_run_id=%s::uuid",
                    (ingestion_run_id,),
                )
                cur.execute(
                    "UPDATE public.ingestion_images SET status='failed' WHERE ingestion_run_id=%s::uuid",
                    (ingestion_run_id,),
                )
            conn.commit()
        finally:
            pg_put_conn(conn)
    except Exception as exc:
        print(f"   ⚠️ Compensazione PostgreSQL fallita: {exc}")

    try:
        if qdrant_client and point_ids:
            qdrant_client.set_payload(
                collection_name=QDRANT_COLLECTION,
                payload={"status": "failed", "failure_reason": message},
                points=list(dict.fromkeys(point_ids)),
                wait=True,
            )
    except Exception as exc:
        print(f"   ⚠️ Compensazione Qdrant fallita: {exc}")

    try:
        if NEO4J_ENABLED and neo4j_driver:
            with neo4j_driver.session() as session:
                session.run(
                    """
                    MATCH (n)
                    WHERE n.ingestion_run_id = $run_id
                      AND (n:Document OR n:Page OR n:Chunk OR n:Formula)
                    SET n.status = 'failed', n.failure_reason = $reason
                    """,
                    run_id=ingestion_run_id,
                    reason=message,
                ).consume()
                session.run(
                    """
                    MATCH ()-[r]->()
                    WHERE r.ingestion_run_id = $run_id
                    SET r.status = 'failed', r.failure_reason = $reason
                    """,
                    run_id=ingestion_run_id,
                    reason=message,
                ).consume()
    except Exception as exc:
        print(f"   ⚠️ Compensazione Neo4j fallita: {exc}")

    try:
        pg_close_log(log_id, "PARTIAL_FAILED", 0, 0, message)
    except Exception as exc:
        print(f"   ⚠️ Chiusura log PARTIAL_FAILED fallita: {exc}")


def process_ai_and_db(
    file_path: str,
    source_type: str,
    doc_meta: dict,
    chunks: list,
    log_id: int,
):
    """
    Pipeline con Knowledge Graph estratto per singolo chunk.

    Modello Neo4j:
        Document -[:HAS_PAGE]-> Page
        Page     -[:HAS_CHUNK]-> Chunk
        Chunk    -[:MENTIONS]-> Entity

    Non vengono creati collegamenti diretti Page-Entity e non vengono
    parcheggiate entità su chunk diversi da quello che le ha generate.
    """
    t0 = time.time()
    set_output_db_tenant_context(doc_meta)
    filename = str(
        (doc_meta or {}).get("source_name")
        or os.path.basename(file_path)
    )

    tier = str((doc_meta or {}).get("tier") or "").strip().upper()
    scope = str((doc_meta or {}).get("scope") or "").strip().upper()
    org_id = (doc_meta or {}).get("organization_id")
    ontology_codes = list((doc_meta or {}).get("ontology_codes") or [])
    ontology_contexts = list((doc_meta or {}).get("ontology_contexts") or [])
    document_context_ids = list(
        (doc_meta or {}).get("document_context_ids") or []
    )
    if not ontology_codes:
        raise ValueError("Nessuna ontology restituita dal Database A")
    ontology = str(ontology_codes[0])
    ingestion_run_id = str((doc_meta or {}).get("ingestion_run_id") or uuid.uuid4())
    (doc_meta or {})["ingestion_run_id"] = ingestion_run_id
    classification = str((doc_meta or {}).get("classification") or DEFAULT_CLASSIFICATION).lower()
    corpus_version = str((doc_meta or {}).get("corpus_version") or CORPUS_VERSION)
    embedding_model = str((doc_meta or {}).get("embedding_model") or EMBEDDING_MODEL_NAME)
    document_status = DOCUMENT_ACTIVE_STATUS

    if scope == "GLOBAL":
        if tier != "A" or org_id is not None:
            raise ValueError("Invariante non valida: GLOBAL richiede Tier A e organization_id NULL")
    elif scope == "ACCOUNT":
        if tier not in {"B", "C"} or org_id is None:
            raise ValueError("Invariante non valida: ACCOUNT richiede Tier B/C e organization_id")
        org_id = int(org_id)
    else:
        raise ValueError(f"Scope documento non valido: {scope!r}")

    tenant_key = build_tenant_key(scope, org_id)
    if str((doc_meta or {}).get("tenant_key") or tenant_key) != tenant_key:
        raise ValueError("tenant_key del job non coerente con scope/organization_id")

    print(
        f"   ⚙️ Engine Start: {filename} | tier={tier} | scope={scope} | org_id={org_id} | "
        f"Brain={LLM_MODEL_NAME}"
    )

    # Sincronizza i metadati multi-tenant delle immagini estratte finora
    conn = pg_get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE ingestion_images
                SET organization_id = %s, tier = %s, scope = %s, status = %s,
                    ingestion_run_id = %s::uuid, tenant_key = %s, corpus_version = %s,
                    classification = %s
                WHERE log_id = %s
                """,
                (org_id, tier, scope, document_status, ingestion_run_id, tenant_key,
                 corpus_version, classification, log_id)
            )
        conn.commit()
    except Exception as e:
        print(f"   ⚠️ Impossibile aggiornare i metadati delle immagini: {e}")
    finally:
        pg_put_conn(conn)

    doc_id = str((doc_meta or {}).get("document_id") or "").strip()
    if not doc_id:
        raise ValueError("document_id assente nel payload del job Database A")

    global embedder, qdrant_client
    embedder = get_embedder()
    qdrant_client = get_qdrant_client()
    ensure_qdrant_collection()

    if not chunks:
        pg_close_log(log_id, "FAILED", 0, _ms(t0), "No chunks extracted")
        raise RuntimeError("No chunks extracted")

    # Indici stabili e chunk_id deterministico calcolato una sola volta.
    page_chunk_counters: Dict[int, int] = {}

    for idx, ch in enumerate(chunks):
        page_no = int(ch.get("page_no") or ch.get("page") or 1)
        page_chunk_index = page_chunk_counters.get(page_no, 0)
        page_chunk_counters[page_no] = page_chunk_index + 1

        ch["chunk_index"] = idx
        ch["page_chunk_index"] = page_chunk_index
        ch["page_no"] = page_no
        ch["toon_type"] = normalize_toon_type(ch)
        ch["chunk_id"] = deterministic_chunk_id(
            doc_id,
            page_no,
            page_chunk_index,
            ch.get("toon_type"),
            ch.get("text_sem"),
            image_id=ch.get("image_id"),
        )

        meta = dict(ch.get("metadata") or {})
        ch["metadata"] = meta

    qdrant_points: List[Dict[str, Any]] = []
    pg_rows: List[Tuple] = []
    neo4j_rows: List[Dict[str, Any]] = []
    total_chunks = 0
    num_chunks_totali = len(chunks)

    # Risultati KG indicizzati direttamente per chunk globale.
    chunk_kg_results: Dict[
        int,
        Tuple[List[Dict[str, Any]], List[Dict[str, Any]]],
    ] = {}
    processed_kg_chunks = set()
    submitted_kg_chunks = 0

    if file_path.lower().endswith(".pdf"):
        pdf_batch = int(os.environ.get("PDF_EMBED_BATCH_SIZE", "8"))
        if pdf_batch > 0:
            global EMBED_BATCH_SIZE
            EMBED_BATCH_SIZE = pdf_batch

    print(
        f"   🚀 Inizio elaborazione: {num_chunks_totali} chunks "
        f"(Batch: {EMBED_BATCH_SIZE})"
    )

    for i in range(0, num_chunks_totali, EMBED_BATCH_SIZE):
        batch_t0 = time.time()
        batch = chunks[i:i + EMBED_BATCH_SIZE]

        pdf_embed_max_chars = int(
            os.environ.get("PDF_EMBED_MAX_CHARS", "1800")
        )
        texts = [
            prep_text_for_embedding(
                ch.get("text_sem", ""),
                max_chars=pdf_embed_max_chars,
            )
            for ch in batch
        ]

        print(
            f"   [DEBUG] Calcolo embeddings batch "
            f"{i // EMBED_BATCH_SIZE + 1}..."
        )

        try:
            vecs = embedder.encode(
                texts,
                batch_size=EMBED_BATCH_SIZE,
                show_progress_bar=True,
            )
        except Exception as e:
            raise RuntimeError(f"Errore embeddings: {e}") from e

        # ------------------------------------------------------------
        # KG PER CHUNK: nessuna aggregazione a livello Page.
        # ------------------------------------------------------------
        if KG_ENABLED:
            futures_kg: Dict[Tuple[int, int], Any] = {}
            scheduled_chunks: Dict[int, Dict[str, Any]] = {}
            raw_results: Dict[int, Dict[str, List[Dict[str, Any]]]] = {}

            for local_idx, ch in enumerate(batch):
                global_idx = i + local_idx

                if global_idx in processed_kg_chunks:
                    continue

                processed_kg_chunks.add(global_idx)

                text_full = safe_normalize_text(
                    ch.get("text_raw")
                    or ch.get("text_sem")
                    or ""
                )
                page_no = int(ch.get("page_no") or 1)
                page_chunk_index = int(ch.get("page_chunk_index") or 0)

                if len(text_full) < KG_MIN_LEN:
                    print(
                        f"   [KG_GATEKEEPER] file={filename} | page={page_no} | "
                        f"chunk={page_chunk_index} | text_len={len(text_full)} | "
                        "kg=False (testo corto)"
                    )
                    continue

                semantic_ok = ai_gatekeeper_decision_from_vec(
                    vecs[local_idx],
                    threshold=KG_GATEKEEPER_THRESHOLD,
                )
                keyword_ok = is_keyword_candidate_hybrid(text_full)
                ok_kg = semantic_ok or keyword_ok

                if (
                    KG_CHUNK_LIMIT_ENABLED
                    and MAX_KG_CHUNKS_PER_DOC > 0
                    and submitted_kg_chunks >= MAX_KG_CHUNKS_PER_DOC
                ):
                    ok_kg = False

                print(
                    f"   [KG_GATEKEEPER] file={filename} | page={page_no} | "
                    f"chunk={page_chunk_index} | text_len={len(text_full)} | "
                    f"semantic={semantic_ok} | keyword={keyword_ok} | kg={ok_kg}"
                )

                if not ok_kg:
                    continue

                windows = split_text_with_overlap(
                    text_full,
                    KG_TEXT_MAX_CHARS,
                    min(KG_WINDOW_OVERLAP_CHARS, KG_TEXT_MAX_CHARS // 3),
                )

                if KG_MAX_WINDOWS_PER_CHUNK > 0:
                    windows = windows[:KG_MAX_WINDOWS_PER_CHUNK]

                if not windows:
                    continue

                submitted_kg_chunks += 1
                scheduled_chunks[global_idx] = {
                    "chunk": ch,
                    "text": text_full,
                    "windows": len(windows),
                }
                raw_results[global_idx] = {"nodes": [], "edges": []}

                for window_idx, window_text in enumerate(windows):
                    futures_kg[(global_idx, window_idx)] = kg_executor.submit(
                        llm_extract_kg,
                        filename,
                        page_no,
                        window_text,
                        LLM_MODEL_NAME,
                    )

            for (global_idx, window_idx), future in futures_kg.items():
                chunk_info = scheduled_chunks[global_idx]
                ch = chunk_info["chunk"]
                page_no = int(ch.get("page_no") or 1)
                page_chunk_index = int(ch.get("page_chunk_index") or 0)

                try:
                    result = future.result(timeout=KG_TIMEOUT)
                    if (
                        not result
                        or not isinstance(result, (list, tuple))
                        or len(result) < 2
                    ):
                        print(
                            f"   ⚠️ KG Skip: risposta non valida | "
                            f"p={page_no} c={page_chunk_index} "
                            f"window={window_idx + 1}"
                        )
                        continue

                    raw_nodes, raw_edges = result
                    raw_results[global_idx]["nodes"].extend(raw_nodes or [])
                    raw_results[global_idx]["edges"].extend(raw_edges or [])

                except cf.TimeoutError:
                    future.cancel()
                    print(
                        f"   ⌛ KG Timeout | p={page_no} "
                        f"c={page_chunk_index} window={window_idx + 1} | "
                        f"timeout={KG_TIMEOUT}s"
                    )
                except Exception as e:
                    print(
                        f"   ⚠️ KG Processing Error | p={page_no} "
                        f"c={page_chunk_index} window={window_idx + 1}: {e}"
                    )

            # Normalizzazione finale per singolo chunk.
            for global_idx, chunk_info in scheduled_chunks.items():
                ch = chunk_info["chunk"]
                chunk_text = chunk_info["text"]
                page_no = int(ch.get("page_no") or 1)
                page_chunk_index = int(ch.get("page_chunk_index") or 0)
                chunk_id = str(ch.get("chunk_id") or "")
                source_ref = (
                    f"{filename}::p{page_no}::c{page_chunk_index}"
                )

                graph_data = _normalize_graph_schema(
                    raw_results.get(global_idx, {})
                )

                if not graph_data or not (
                    graph_data.get("nodes") or graph_data.get("edges")
                ):
                    print(
                        f"   ⚠️ KG Empty | p={page_no} "
                        f"c={page_chunk_index}: nessun contenuto valido"
                    )
                    continue

                clean_nodes, clean_edges = _sanitize_graph(graph_data)
                clean_nodes, clean_edges = enrich_formula_nodes_and_edges(
                    clean_nodes,
                    clean_edges,
                )
                clean_edges = canonicalize_edges_to_verb_object(clean_edges)
                clean_edges = canonicalize_edges_by_base_presence(clean_edges)

                nodes_by_id: Dict[str, Dict[str, Any]] = {}

                for node in clean_nodes:
                    if not isinstance(node, dict):
                        continue

                    raw_id = str(node.get("id") or "").strip()
                    normalized_id = normalize_entity_id(raw_id)
                    if not normalized_id:
                        continue

                    normalized_node = dict(node)
                    normalized_node["id"] = normalized_id
                    normalized_node["name"] = (
                        str(node.get("name") or raw_id).strip() or raw_id
                    )

                    props = dict(normalized_node.get("props") or {})
                    props.setdefault("description", "")
                    props.setdefault("formula", "")
                    props.setdefault("synonyms", [])
                    normalized_node["props"] = props

                    if normalized_id not in nodes_by_id:
                        nodes_by_id[normalized_id] = normalized_node
                    else:
                        existing = nodes_by_id[normalized_id]
                        existing_props = dict(existing.get("props") or {})
                        existing_props.update(props)
                        existing["props"] = existing_props

                        if existing.get("category") in (
                            None,
                            "",
                            "UNCLASSIFIED",
                        ):
                            existing["category"] = normalized_node.get(
                                "category",
                                "UNCLASSIFIED",
                            )

                validated_nodes = ensure_entity_props_defaults(
                    list(nodes_by_id.values())
                )
                validated_nodes = enrich_synonyms_from_local_text(
                    validated_nodes,
                    chunk_text,
                )

                valid_node_ids = {node["id"] for node in validated_nodes}
                final_edges: List[Dict[str, Any]] = []
                seen_edges = set()

                for edge in clean_edges:
                    if not isinstance(edge, dict):
                        continue

                    source = normalize_entity_id(
                        str(edge.get("source") or "")
                    )
                    target = normalize_entity_id(
                        str(edge.get("target") or "")
                    )
                    relation = str(
                        edge.get("relation") or "RELATES_TO"
                    ).strip()

                    if not source or not target:
                        continue
                    if source not in valid_node_ids or target not in valid_node_ids:
                        continue

                    edge_key = (source, target, relation)
                    if edge_key in seen_edges:
                        continue

                    props = dict(edge.get("props") or {})
                    props.setdefault("source_file", filename)
                    props.setdefault("page_no", page_no)
                    props.setdefault("chunk_id", chunk_id)
                    props.setdefault("chunk_index", global_idx)
                    props.setdefault("page_chunk_index", page_chunk_index)
                    props.setdefault("source_ref", source_ref)
                    props.setdefault("source", "kg_extraction")
                    props.setdefault(
                        "evidence_type",
                        "explicit_kg_edge",
                    )

                    final_edges.append({
                        "source": source,
                        "target": target,
                        "relation": relation,
                        "props": props,
                    })
                    seen_edges.add(edge_key)

                if not validated_nodes:
                    print(
                        f"   ⚠️ KG Empty | p={page_no} "
                        f"c={page_chunk_index}: nessun nodo valido"
                    )
                    continue

                chunk_kg_results[global_idx] = (
                    validated_nodes,
                    final_edges,
                )

                print(
                    f"   ✅ KG Exploded | p={page_no} "
                    f"c={page_chunk_index} | "
                    f"nodes={len(validated_nodes)} | "
                    f"edges={len(final_edges)}"
                )

        # ------------------------------------------------------------
        # Costruzione record DB.
        # ------------------------------------------------------------
        for local_idx, ch in enumerate(batch):
            global_idx = i + local_idx
            ch["toon_type"] = normalize_toon_type(ch)

            vector = vecs[local_idx]
            page_no = int(ch.get("page_no") or ch.get("page") or 1)
            page_chunk_index = int(ch.get("page_chunk_index") or 0)
            chunk_id = str(ch.get("chunk_id") or "")
            source_ref = f"{filename}::p{page_no}::c{page_chunk_index}"

            metadata = dict(ch.get("metadata") or {})
            metadata.update({
                "page": page_no,
                "page_no": page_no,
                "toon_type": ch.get("toon_type", "text"),
                "filename": filename,
                "doc_id": doc_id,
                "document_id": doc_id,
                "tier": tier,
                "scope": scope,
                "organization_id": org_id,
                "tenant_key": tenant_key,
                "ontology": ontology,
                "ontology_codes": ontology_codes,
                "document_context_ids": document_context_ids,
                "ontology_contexts": ontology_contexts,
                "source_name": filename,
                "source_type": source_type,
                "log_id": log_id,
                "chunk_index": global_idx,
                "page_chunk_index": page_chunk_index,
                "chunk_id": chunk_id,
                "source_ref": source_ref,
                "status": document_status,
                "ingestion_run_id": ingestion_run_id,
                "embedding_model": embedding_model,
                "corpus_version": corpus_version,
                "classification": classification,
            })

            if ch.get("image_id") is not None:
                metadata["image_id"] = ch.get("image_id")

            payload = metadata.copy()
            payload.update({
                "text_sem": ch.get("text_sem", ""),
                "page": page_no,
                "page_no": page_no,
                "toon_type": ch.get("toon_type", "text"),
            })

            qdrant_points.append({
                "id": chunk_id,
                "vector": vector.tolist(),
                "payload": payload,
            })

            pg_rows.append((
                log_id,
                global_idx,
                ch.get("toon_type", "text"),
                ch.get("text_raw"),
                ch.get("text_sem"),
                json.dumps(metadata, ensure_ascii=False),
                chunk_id,
                doc_meta.get("organization_id"),
                doc_meta.get("tier"),
                doc_meta.get("scope"),
                document_status,
                ingestion_run_id,
                tenant_key,
                corpus_version,
                classification,
                embedding_model
            ))

            chunk_nodes, chunk_edges = chunk_kg_results.get(
                global_idx,
                ([], []),
            )
            chunk_nodes = list(chunk_nodes)
            chunk_edges = list(chunk_edges)

            # Formula Vision: resta sul chunk che contiene la formula.
            formula_nodes, formula_edges = formula_kg_from_chunk(ch)
            chunk_nodes.extend(formula_nodes)
            chunk_edges.extend(formula_edges)

            # Deduplica finale dei nodi dopo l'aggiunta delle formule.
            final_nodes_by_id: Dict[str, Dict[str, Any]] = {}
            for node in ensure_entity_props_defaults(chunk_nodes):
                if not isinstance(node, dict):
                    continue
                node_id = normalize_entity_id(str(node.get("id") or ""))
                if not node_id:
                    continue

                normalized_node = dict(node)
                normalized_node["id"] = node_id
                normalized_node.setdefault(
                    "name",
                    str(node.get("name") or node.get("id") or ""),
                )

                if node_id not in final_nodes_by_id:
                    final_nodes_by_id[node_id] = normalized_node
                else:
                    existing = final_nodes_by_id[node_id]
                    props = dict(existing.get("props") or {})
                    props.update(dict(normalized_node.get("props") or {}))
                    existing["props"] = props

            final_nodes = enrich_synonyms_from_local_text(
                list(final_nodes_by_id.values()),
                ch.get("text_sem", ""),
            )
            final_node_ids = {node["id"] for node in final_nodes}

            final_edges = []
            seen_final_edges = set()
            for edge in chunk_edges:
                if not isinstance(edge, dict):
                    continue

                source = normalize_entity_id(
                    str(edge.get("source") or "")
                )
                target = normalize_entity_id(
                    str(edge.get("target") or "")
                )
                relation = str(
                    edge.get("relation") or "RELATES_TO"
                ).strip()

                if source not in final_node_ids or target not in final_node_ids:
                    continue

                edge_key = (source, target, relation)
                if edge_key in seen_final_edges:
                    continue

                props = dict(edge.get("props") or {})
                props.setdefault("source_file", filename)
                props.setdefault("page_no", page_no)
                props.setdefault("chunk_id", chunk_id)
                props.setdefault("chunk_index", global_idx)
                props.setdefault("page_chunk_index", page_chunk_index)
                props.setdefault("source_ref", source_ref)
                props.setdefault("tier", tier)
                props.setdefault("scope", scope)
                props.setdefault("organization_id", org_id)
                props.setdefault("tenant_key", tenant_key)
                props.setdefault("status", document_status)
                props.setdefault("ingestion_run_id", ingestion_run_id)
                props.setdefault("corpus_version", corpus_version)
                props.setdefault("classification", classification)

                final_edges.append({
                    "source": source,
                    "target": target,
                    "relation": relation,
                    "props": props,
                })
                seen_final_edges.add(edge_key)

            neo4j_rows.append({
                "doc_id": doc_id,
                "filename": filename,
                "filename_norm": normalize_doc_name(filename),
                "doc_type": source_type,
                "tier": tier,
                "scope": scope,
                "organization_id": org_id,
                "tenant_key": tenant_key,
                "ontology": ontology,
                "ontology_codes": ontology_codes,
                "document_context_ids": document_context_ids,
                "contexts_json": json.dumps(
                    ontology_contexts,
                    ensure_ascii=False,
                    default=str,
                ),
                "log_id": log_id,
                "status": document_status,
                "ingestion_run_id": ingestion_run_id,
                "corpus_version": corpus_version,
                "classification": classification,
                "embedding_model": embedding_model,
                "chunk_id": chunk_id,
                "chunk_index": global_idx,
                "page_chunk_index": page_chunk_index,
                "toon_type": ch.get("toon_type"),
                "page_no": page_no,
                "source_ref": source_ref,
                "nodes": final_nodes,
                "edges": final_edges,
                "text_sem": ch.get("text_sem", ""),
                "section_hint": ch.get("section_hint", ""),
            })

            total_chunks += 1

        must_flush = (
            len(pg_rows) >= DB_FLUSH_SIZE
            or i + len(batch) >= num_chunks_totali
        )

        if must_flush:
            current_point_ids = [str(point["id"]) for point in qdrant_points]
            try:
                flush_postgres_chunks_batch(pg_rows)

                points = [
                    models.PointStruct(
                        id=point["id"],
                        vector=point["vector"],
                        payload=point["payload"],
                    )
                    for point in qdrant_points
                ]
                if points:
                    qdrant_client.upsert(
                        collection_name=QDRANT_COLLECTION,
                        points=points,
                        wait=True,
                    )

                if not flush_neo4j_rows_batch(neo4j_rows):
                    raise RuntimeError("Scrittura Neo4j incompleta")
            except Exception as exc:
                mark_ingestion_run_partial_failure(
                    log_id=log_id,
                    ingestion_run_id=ingestion_run_id,
                    doc_id=doc_id,
                    point_ids=current_point_ids,
                    error=exc,
                )
                raise

            pg_rows.clear()
            qdrant_points.clear()
            neo4j_rows.clear()

        percentage = min(
            100,
            int((i + len(batch)) / num_chunks_totali * 100),
        )
        print(
            f"   📦 Batch {int(i / EMBED_BATCH_SIZE) + 1} | "
            f"{percentage}% completato | Tempo Batch: {_ms(batch_t0)}ms"
        )

    total_ms = _ms(t0)
    pg_close_log(log_id, "DONE", total_chunks, total_ms)

    if NEO4J_ENABLED:
        try:
            with neo4j_driver.session() as session:
                session.run(
                    "MATCH (d:Document {doc_id: $did}) "
                    "SET d.processing_time_ms = $ms",
                    did=doc_id,
                    ms=total_ms,
                ).consume()
        except Exception:
            pass

        validate_neo4j_graph_model(doc_id)

    print(
        f"   ✅ Completed: {filename} | chunks={total_chunks} | "
        f"time={total_ms / 1000:.2f}s"
    )
    return {
        "status": "DONE",
        "chunks": total_chunks,
        "processing_time_ms": total_ms,
        "document_id": doc_id,
        "ontology_codes": ontology_codes,
    }

# =========================
# Database A / rag_ingestion job helpers
# =========================
class IngestionWorkerBusyError(RuntimeError):
    """Un altro processo API possiede già il lock globale di ingestion."""


INGESTION_GLOBAL_LOCK_KEY = int(
    os.getenv("INGESTION_GLOBAL_LOCK_KEY", "731904271")
)
_RUNTIME_INIT_LOCK = Lock()
_RUNTIME_INITIALIZED = False
_RUNTIME_CLOSED = False


def source_pg_get_conn():
    return source_pg_pool.getconn()


def source_pg_put_conn(conn) -> None:
    if conn is None:
        return
    try:
        if not conn.closed:
            conn.rollback()
    except Exception:
        pass
    finally:
        source_pg_pool.putconn(conn)


def verify_source_db_contract() -> None:
    """Verifica che il Database A esponga le API worker previste dalla DDL."""
    expected = {
        "fn_claim_next_ingestion_job": 1,
        "fn_get_claimed_job_payload": 3,
        "fn_heartbeat_ingestion_job": 3,
        "fn_complete_ingestion_job": 6,
        "fn_fail_ingestion_job": 6,
    }

    conn = source_pg_get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT current_database(), current_user")
            database_name, role_name = cur.fetchone()
            cur.execute(
                """
                SELECT p.proname, p.pronargs
                FROM pg_catalog.pg_proc p
                JOIN pg_catalog.pg_namespace n
                  ON n.oid = p.pronamespace
                WHERE n.nspname = 'rag_ingestion'
                  AND p.proname = ANY(%s)
                """,
                (list(expected),),
            )
            found: Dict[str, set[int]] = {}
            for name, argument_count in cur.fetchall():
                found.setdefault(str(name), set()).add(int(argument_count))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        source_pg_put_conn(conn)

    missing = [
        name
        for name, argument_count in expected.items()
        if argument_count not in found.get(name, set())
    ]
    if missing:
        raise RuntimeError(
            "Contratto DDL rag_ingestion non compatibile. "
            f"Funzioni mancanti o con firma diversa: {missing}"
        )

    if str(database_name) != SOURCE_PG_DB:
        raise RuntimeError(
            f"Database sorgente inatteso: connesso a {database_name!r}, "
            f"configurato {SOURCE_PG_DB!r}"
        )

    print(
        f"   ✅ Contratto Database A verificato | "
        f"db={database_name} | role={role_name}"
    )


def claim_next_db_job() -> Optional[Dict[str, Any]]:
    """Acquisisce atomicamente il prossimo job PENDING dal Database A."""
    conn = source_pg_get_conn()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                "SELECT * FROM rag_ingestion.fn_claim_next_ingestion_job(%s)",
                (INGESTION_WORKER_ID,),
            )
            row = cur.fetchone()
        conn.commit()
        return dict(row) if row else None
    except Exception:
        conn.rollback()
        raise
    finally:
        source_pg_put_conn(conn)


def get_claimed_db_job_payload(job: Dict[str, Any]) -> Dict[str, Any]:
    """Legge BYTEA e metadati solo per un job posseduto dal worker."""
    conn = source_pg_get_conn()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                """
                SELECT *
                FROM rag_ingestion.fn_get_claimed_job_payload(%s, %s, %s)
                """,
                (
                    job["job_id"],
                    INGESTION_WORKER_ID,
                    job["lock_token"],
                ),
            )
            row = cur.fetchone()
        conn.commit()
        if not row:
            raise RuntimeError(
                f"Payload non disponibile per job {job.get('job_id')}"
            )
        return dict(row)
    except Exception:
        conn.rollback()
        raise
    finally:
        source_pg_put_conn(conn)


def heartbeat_db_job(job: Dict[str, Any]) -> bool:
    conn = source_pg_get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT rag_ingestion.fn_heartbeat_ingestion_job(%s, %s, %s)",
                (
                    job["job_id"],
                    INGESTION_WORKER_ID,
                    job["lock_token"],
                ),
            )
            row = cur.fetchone()
        conn.commit()
        return bool(row and row[0])
    except Exception:
        conn.rollback()
        raise
    finally:
        source_pg_put_conn(conn)


def complete_db_job(
    job: Dict[str, Any],
    external_log_id: Optional[int],
    metrics: Optional[Dict[str, Any]] = None,
    result: Optional[Dict[str, Any]] = None,
) -> None:
    conn = source_pg_get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT rag_ingestion.fn_complete_ingestion_job(
                    %s, %s, %s, %s, %s, %s
                )
                """,
                (
                    job["job_id"],
                    INGESTION_WORKER_ID,
                    job["lock_token"],
                    external_log_id,
                    Json(metrics or {}),
                    Json(result or {}),
                ),
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        source_pg_put_conn(conn)


def fail_db_job(
    job: Dict[str, Any],
    error: Exception,
    metrics: Optional[Dict[str, Any]] = None,
) -> Optional[str]:
    conn = source_pg_get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT rag_ingestion.fn_fail_ingestion_job(
                    %s, %s, %s, %s, %s::interval, %s
                )
                """,
                (
                    job["job_id"],
                    INGESTION_WORKER_ID,
                    job["lock_token"],
                    str(error)[:4000],
                    JOB_RETRY_DELAY,
                    Json(metrics or {}),
                ),
            )
            row = cur.fetchone()
        conn.commit()
        return str(row[0]) if row else None
    except Exception:
        conn.rollback()
        raise
    finally:
        source_pg_put_conn(conn)


class JobHeartbeat:
    """Mantiene valido il lock del job durante estrazione e pipeline AI."""

    def __init__(self, job: Dict[str, Any]):
        self.job = job
        self.stop_event = threading.Event()
        self.thread = threading.Thread(
            target=self._run,
            name=f"heartbeat-{job.get('job_id')}",
            daemon=True,
        )

    def start(self) -> None:
        self.thread.start()

    def stop(self) -> None:
        self.stop_event.set()
        if self.thread.is_alive():
            self.thread.join(timeout=5)

    def _run(self) -> None:
        while not self.stop_event.wait(JOB_HEARTBEAT_SECONDS):
            try:
                if not heartbeat_db_job(self.job):
                    print(
                        f"   ⚠️ Heartbeat rifiutato per job "
                        f"{self.job.get('job_id')}"
                    )
                    return
            except Exception as exc:
                print(
                    f"   ⚠️ Heartbeat fallito per job "
                    f"{self.job.get('job_id')}: {exc}"
                )


def _json_safe_value(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _json_safe_value(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_json_safe_value(v) for v in value]
    if isinstance(value, tuple):
        return [_json_safe_value(v) for v in value]
    if isinstance(value, (uuid.UUID,)):
        return str(value)
    return value


def _normalize_contexts(raw_contexts: Any) -> List[Dict[str, Any]]:
    if raw_contexts is None:
        return []
    if isinstance(raw_contexts, str):
        raw_contexts = json.loads(raw_contexts or "[]")
    if isinstance(raw_contexts, dict):
        raw_contexts = [raw_contexts]
    if not isinstance(raw_contexts, list):
        raise ValueError("contexts_json non valido nel payload del job")
    return [
        _json_safe_value(dict(context))
        for context in raw_contexts
        if isinstance(context, dict)
    ]


def suffix_from_db_payload(payload: Dict[str, Any]) -> str:
    mime_type = str(payload.get("mime_type") or "").split(";", 1)[0]
    mime_type = mime_type.strip().lower()
    source_format = str(payload.get("source_format") or "").strip().lower()

    if mime_type == "application/pdf" or source_format in {
        "pdf",
        ".pdf",
        "application/pdf",
    }:
        return ".pdf"
    if mime_type in {"text/markdown", "text/x-markdown"} or source_format in {
        "md",
        ".md",
        "markdown",
        "text/markdown",
        "text/x-markdown",
    }:
        return ".md"

    raise ValueError(
        "Formato non supportato dalla pipeline corrente: "
        f"mime_type={mime_type!r}, source_format={source_format!r}. "
        "Sono ammessi PDF e Markdown."
    )


def build_doc_meta_from_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Costruisce metadati esclusivamente dai valori autorevoli del DB."""
    document_id = str(payload.get("document_id") or "").strip()
    if not document_id:
        raise ValueError("document_id assente nel payload")

    job_id = str(payload.get("job_id") or "").strip()
    if not job_id:
        raise ValueError("job_id assente nel payload")

    job_type = str(payload.get("job_type") or "").strip().upper()
    if job_type not in {"CONTENT_INGESTION", "CONTEXT_SYNC"}:
        raise ValueError(f"job_type non valido: {job_type!r}")

    tier = str(payload.get("tier_code") or "").strip().upper()
    scope = str(payload.get("scope_code") or "").strip().upper()
    organization_id = payload.get("organization_id")

    if scope == "GLOBAL":
        if tier != "A" or organization_id is not None:
            raise ValueError(
                "Payload GLOBAL non valido: richiesti Tier A e organization_id NULL"
            )
        organization_id = None
    elif scope == "ACCOUNT":
        if tier not in {"B", "C"} or organization_id is None:
            raise ValueError(
                "Payload ACCOUNT non valido: richiesti Tier B/C e organization_id"
            )
        organization_id = int(organization_id)
        if organization_id <= 0:
            raise ValueError("organization_id deve essere maggiore di zero")
    else:
        raise ValueError(f"scope_code non valido: {scope!r}")

    tenant_key = build_tenant_key(scope, organization_id)
    payload_tenant_key = str(payload.get("tenant_key") or "").strip()
    if payload_tenant_key and payload_tenant_key != tenant_key:
        raise ValueError(
            f"tenant_key non coerente: atteso={tenant_key}, "
            f"ricevuto={payload_tenant_key}"
        )

    contexts = _normalize_contexts(payload.get("contexts_json"))
    ontology_codes = list(
        dict.fromkeys(
            str(context.get("ontology_code") or "").strip().lower()
            for context in contexts
            if str(context.get("ontology_code") or "").strip()
        )
    )
    if not ontology_codes:
        raise ValueError(
            "Nessuna ontology configurata nel Database A per "
            f"document_id={document_id}"
        )

    document_context_ids = [
        str(context.get("document_context_id"))
        for context in contexts
        if context.get("document_context_id")
    ]

    payload_context_id = (
        str(payload.get("document_context_id"))
        if payload.get("document_context_id")
        else None
    )
    if job_type == "CONTENT_INGESTION" and payload_context_id is not None:
        raise ValueError(
            "CONTENT_INGESTION non deve avere document_context_id sul job"
        )
    if job_type == "CONTEXT_SYNC":
        if payload_context_id is None:
            raise ValueError("CONTEXT_SYNC richiede document_context_id")
        if payload_context_id not in document_context_ids:
            raise ValueError(
                "Il contesto del job CONTEXT_SYNC non è presente in contexts_json"
            )

    classification = str(
        payload.get("classification") or DEFAULT_CLASSIFICATION
    ).strip().lower()
    if classification not in {
        "public",
        "internal",
        "confidential",
        "restricted",
    }:
        raise ValueError(f"classification non valida: {classification!r}")

    source_suffix = suffix_from_db_payload(payload)

    # Il nome originale proviene dall'API del Database A. Per gli upload
    # applicativi è letto da public.file_asset; per i caricamenti CORPUS
    # manuali è letto da rag_file_blob.security_scan_details.
    raw_original_filename = next(
        (
            str(context.get("original_filename") or "").strip()
            for context in contexts
            if str(context.get("original_filename") or "").strip()
        ),
        "",
    )

    if raw_original_filename:
        # Accetta solo il basename: nessun percorso proveniente dal DB può
        # influenzare la directory temporanea del worker.
        source_name = re.split(r"[\\/]", raw_original_filename)[-1].strip()
        source_name = source_name.replace("\x00", "")
        if source_name in {"", ".", ".."}:
            source_name = f"{document_id}{source_suffix}"
        else:
            stem, current_suffix = os.path.splitext(source_name)
            if current_suffix.lower() != source_suffix:
                source_name = f"{stem or document_id}{source_suffix}"
            source_name = source_name[:255]
    else:
        source_name = f"{document_id}{source_suffix}"

    return {
        "db_source": True,
        "job_id": job_id,
        "job_type": job_type,
        "document_id": document_id,
        "document_context_id": payload_context_id,
        "organization_id": organization_id,
        "tier": tier,
        "scope": scope,
        "tenant_key": tenant_key,
        "ontology": ontology_codes[0],
        "ontology_codes": ontology_codes,
        "ontology_contexts": contexts,
        "document_context_ids": document_context_ids,
        "pipeline_version": str(payload.get("pipeline_version") or "v1"),
        "corpus_version": str(
            payload.get("corpus_version") or CORPUS_VERSION
        ),
        "classification": classification,
        "embedding_model": EMBEDDING_MODEL_NAME,
        "ingestion_run_id": str(uuid.uuid4()),
        "source_name": source_name,
        "mime_type": str(payload.get("mime_type") or "").lower(),
        "source_format": str(payload.get("source_format") or ""),
        "content_sha256": str(payload.get("content_sha256") or "").lower(),
        "file_size_bytes": int(payload.get("file_size_bytes") or 0),
        "file_blob_id": (
            str(payload.get("file_blob_id"))
            if payload.get("file_blob_id")
            else None
        ),
    }


def materialize_claimed_bytea(
    payload: Dict[str, Any],
    doc_meta: Dict[str, Any],
) -> str:
    """
    Materializza temporaneamente il BYTEA per gli estrattori esistenti.

    La sorgente del documento resta il Database A; non viene consultata alcuna
    directory sorgente. La directory temporanea viene rimossa al termine del job.
    """
    raw_content = payload.get("content_data")
    if raw_content is None:
        raise ValueError("content_data BYTEA assente nel payload")

    content_bytes = (
        raw_content.tobytes()
        if isinstance(raw_content, memoryview)
        else bytes(raw_content)
    )

    expected_size = int(payload.get("file_size_bytes") or 0)
    if expected_size <= 0 or len(content_bytes) != expected_size:
        raise ValueError(
            "Dimensione BYTEA non coerente: "
            f"attesa={expected_size}, letta={len(content_bytes)}"
        )

    expected_sha = str(payload.get("content_sha256") or "").strip().lower()
    actual_sha = hashlib.sha256(content_bytes).hexdigest()
    if not expected_sha or actual_sha != expected_sha:
        raise ValueError(
            "SHA-256 BYTEA non coerente per "
            f"document_id={payload.get('document_id')}"
        )

    temporary_dir = tempfile.mkdtemp(
        prefix=f"rag_job_{str(payload.get('job_id'))[:12]}_"
    )
    temporary_path = os.path.join(temporary_dir, doc_meta["source_name"])

    with open(temporary_path, "wb") as temporary_file:
        temporary_file.write(content_bytes)

    try:
        os.chmod(temporary_path, 0o600)
    except OSError:
        pass

    doc_meta["temporary_dir"] = temporary_dir
    doc_meta["temporary_file_path"] = temporary_path
    return temporary_path


def cleanup_materialized_bytea(doc_meta: Optional[Dict[str, Any]]) -> None:
    temporary_dir = str((doc_meta or {}).get("temporary_dir") or "").strip()
    if not temporary_dir:
        return
    try:
        shutil.rmtree(temporary_dir, ignore_errors=False)
    except FileNotFoundError:
        pass
    except Exception as exc:
        print(
            f"   ⚠️ Impossibile eliminare la directory temporanea "
            f"{temporary_dir}: {exc}"
        )


def extract_db_document_chunks(
    file_path: str,
    log_id: int,
    doc_meta: Dict[str, Any],
) -> List[Dict[str, Any]]:
    if file_path.lower().endswith(".md"):
        return extract_markdown_chunks(file_path, log_id)
    if file_path.lower().endswith(".pdf"):
        return extract_file_chunks(file_path, log_id, doc_meta)
    raise ValueError(f"Formato temporaneo non supportato: {file_path}")


def _merge_context_lists(
    existing: List[Dict[str, Any]],
    incoming: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    for context in existing + incoming:
        if not isinstance(context, dict):
            continue
        key = str(context.get("document_context_id") or "").strip()
        if not key:
            key = json.dumps(context, sort_keys=True, default=str)
        merged[key] = _json_safe_value(dict(context))
    return list(merged.values())


def sync_context_only(doc_meta: Dict[str, Any]) -> Dict[str, Any]:
    """Sincronizza nuove ontology senza ripetere OCR, embedding o KG."""
    set_output_db_tenant_context(doc_meta)
    document_id = str(doc_meta["document_id"])
    incoming_contexts = list(doc_meta.get("ontology_contexts") or [])

    conn = pg_get_conn()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                """
                SELECT chunk_uuid, metadata_json
                FROM public.document_chunks
                WHERE status = 'active'
                  AND scope = %s
                  AND organization_id IS NOT DISTINCT FROM %s
                  AND (
                        metadata_json ->> 'document_id' = %s
                        OR metadata_json ->> 'doc_id' = %s
                  )
                ORDER BY chunk_index
                """,
                (
                    doc_meta["scope"],
                    doc_meta.get("organization_id"),
                    document_id,
                    document_id,
                ),
            )
            rows = cur.fetchall()
            if not rows:
                raise RuntimeError(
                    "CONTEXT_SYNC impossibile: nessun chunk attivo per "
                    f"document_id={document_id}"
                )

            first_metadata = rows[0].get("metadata_json") or {}
            if isinstance(first_metadata, str):
                first_metadata = json.loads(first_metadata)
            existing_contexts = list(
                first_metadata.get("ontology_contexts") or []
            )
            merged_contexts = _merge_context_lists(
                existing_contexts,
                incoming_contexts,
            )
            ontology_codes = list(
                dict.fromkeys(
                    str(context.get("ontology_code") or "").strip().lower()
                    for context in merged_contexts
                    if str(context.get("ontology_code") or "").strip()
                )
            )
            if not ontology_codes:
                raise RuntimeError("CONTEXT_SYNC senza ontology valide")
            context_ids = [
                str(context.get("document_context_id"))
                for context in merged_contexts
                if context.get("document_context_id")
            ]

            update_rows = []
            chunk_ids = []
            for row in rows:
                metadata = row.get("metadata_json") or {}
                if isinstance(metadata, str):
                    metadata = json.loads(metadata)
                metadata["ontology"] = ontology_codes[0]
                metadata["ontology_codes"] = ontology_codes
                metadata["document_context_ids"] = context_ids
                metadata["ontology_contexts"] = merged_contexts
                update_rows.append(
                    (
                        Json(metadata),
                        row["chunk_uuid"],
                        doc_meta["scope"],
                        doc_meta.get("organization_id"),
                    )
                )
                chunk_ids.append(str(row["chunk_uuid"]))

            cur.executemany(
                """
                UPDATE public.document_chunks
                SET metadata_json = %s
                WHERE chunk_uuid = %s
                  AND scope = %s
                  AND organization_id IS NOT DISTINCT FROM %s
                """,
                update_rows,
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        pg_put_conn(conn)

    qdrant = get_qdrant_client()
    qdrant.set_payload(
        collection_name=QDRANT_COLLECTION,
        payload={
            "ontology": ontology_codes[0],
            "ontology_codes": ontology_codes,
            "document_context_ids": context_ids,
            "ontology_contexts": merged_contexts,
        },
        points=chunk_ids,
        wait=True,
    )

    if NEO4J_ENABLED and neo4j_driver:
        contexts_json = json.dumps(
            merged_contexts,
            ensure_ascii=False,
            default=str,
        )
        with neo4j_driver.session() as session:
            session.run(
                """
                MATCH (d:Document {doc_id: $doc_id})
                SET d.ontology = $ontology,
                    d.ontology_codes = $ontology_codes,
                    d.document_context_ids = $context_ids,
                    d.contexts_json = $contexts_json
                WITH d
                OPTIONAL MATCH (d)-[:HAS_PAGE]->(p:Page)
                SET p.ontology = $ontology,
                    p.ontology_codes = $ontology_codes,
                    p.document_context_ids = $context_ids,
                    p.contexts_json = $contexts_json
                WITH d
                OPTIONAL MATCH (d)-[:HAS_PAGE]->(:Page)-[:HAS_CHUNK]->(c:Chunk)
                SET c.ontology = $ontology,
                    c.ontology_codes = $ontology_codes,
                    c.document_context_ids = $context_ids,
                    c.contexts_json = $contexts_json
                """,
                doc_id=document_id,
                ontology=ontology_codes[0],
                ontology_codes=ontology_codes,
                context_ids=context_ids,
                contexts_json=contexts_json,
            ).consume()

    return {
        "status": "DONE",
        "job_type": "CONTEXT_SYNC",
        "document_id": document_id,
        "chunks_updated": len(chunk_ids),
        "ontology_codes": ontology_codes,
    }


def prepare_claimed_job_item(
    job: Dict[str, Any],
    heartbeat: JobHeartbeat,
) -> Dict[str, Any]:
    started = time.time()
    doc_meta: Optional[Dict[str, Any]] = None
    log_id: Optional[int] = None

    try:
        payload = get_claimed_db_job_payload(job)
        doc_meta = build_doc_meta_from_payload(payload)
        set_output_db_tenant_context(doc_meta)

        print(
            f"   📥 Job {job['job_id']} | type={doc_meta['job_type']} | "
            f"document={doc_meta['document_id']} | tier={doc_meta['tier']} | "
            f"org={doc_meta.get('organization_id')} | "
            f"ontology={doc_meta['ontology_codes']}"
        )

        if doc_meta["job_type"] == "CONTEXT_SYNC":
            log_id = pg_start_log(
                doc_meta["source_name"],
                "context_sync",
                doc_meta,
            )
            return {
                "kind": "CONTEXT_SYNC",
                "job": job,
                "heartbeat": heartbeat,
                "doc_meta": doc_meta,
                "log_id": log_id,
                "file_path": None,
                "chunks": None,
                "started": started,
            }

        file_path = materialize_claimed_bytea(payload, doc_meta)
        log_id = pg_start_log(doc_meta["source_name"], "document", doc_meta)
        chunks = extract_db_document_chunks(file_path, log_id, doc_meta)
        if not chunks:
            raise RuntimeError("No chunks extracted")

        return {
            "kind": "CONTENT_INGESTION",
            "job": job,
            "heartbeat": heartbeat,
            "doc_meta": doc_meta,
            "log_id": log_id,
            "file_path": file_path,
            "chunks": chunks,
            "started": started,
        }

    except Exception as exc:
        if log_id is not None and doc_meta is not None:
            try:
                pg_fail_log_if_running(
                    log_id,
                    _ms(started),
                    str(exc)[:500],
                )
            except Exception:
                pass
        cleanup_materialized_bytea(doc_meta)
        clear_output_db_tenant_context()
        raise


def consume_claimed_job_item(item: Dict[str, Any]) -> Dict[str, Any]:
    job = item["job"]
    heartbeat = item["heartbeat"]
    doc_meta = item["doc_meta"]
    log_id = item["log_id"]
    file_path = item.get("file_path")
    started = item["started"]

    set_output_db_tenant_context(doc_meta)
    try:
        if item["kind"] == "CONTEXT_SYNC":
            result = sync_context_only(doc_meta)
            pg_close_log(log_id, "DONE", 0, _ms(started))
        else:
            chunks = item["chunks"]
            print(
                f"   🧠 Processing: {doc_meta['source_name']} | "
                f"chunks={len(chunks)}"
            )
            result = process_ai_and_db(
                file_path=file_path,
                source_type="document",
                doc_meta=doc_meta,
                chunks=chunks,
                log_id=log_id,
            ) or {}

        complete_db_job(
            job,
            external_log_id=log_id,
            metrics={
                "processing_time_ms": _ms(started),
                "chunks": int(
                    result.get("chunks", result.get("chunks_updated", 0)) or 0
                ),
                "ontology_codes": doc_meta.get("ontology_codes", []),
            },
            result=result,
        )
        heartbeat.stop()
        print(f"   ✅ Job completato: {job['job_id']}")
        return result

    except Exception as exc:
        heartbeat.stop()
        print(f"   ❌ Job fallito {job.get('job_id')}: {exc}")
        try:
            pg_fail_log_if_running(
                log_id,
                _ms(started),
                str(exc)[:500],
            )
        except Exception:
            pass
        try:
            next_status = fail_db_job(
                job,
                exc,
                metrics={"processing_time_ms": _ms(started)},
            )
            print(f"   ↩️ Stato job dopo errore: {next_status}")
        except Exception as fail_exc:
            print(
                "   ⚠️ Impossibile registrare il fallimento del job: "
                f"{fail_exc}"
            )
        raise
    finally:
        cleanup_materialized_bytea(doc_meta)
        clear_output_db_tenant_context()



@contextmanager
def ingestion_global_lock():
    """Serializza l'uso della GPU anche tra processi/istanze API diverse."""
    conn = source_pg_get_conn()
    acquired = False
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT pg_try_advisory_lock(%s)",
                (INGESTION_GLOBAL_LOCK_KEY,),
            )
            row = cur.fetchone()
            acquired = bool(row and row[0])
        conn.commit()

        if not acquired:
            raise IngestionWorkerBusyError(
                "Un altro worker possiede già il lock globale di ingestion"
            )
        yield
    finally:
        if acquired:
            try:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT pg_advisory_unlock(%s)",
                        (INGESTION_GLOBAL_LOCK_KEY,),
                    )
                conn.commit()
            except Exception:
                try:
                    conn.rollback()
                except Exception:
                    pass
        source_pg_put_conn(conn)


def runtime_healthcheck(deep: bool = False) -> Dict[str, Any]:
    """Restituisce uno snapshot privo di segreti delle dipendenze runtime."""
    dependencies: Dict[str, Dict[str, Any]] = {}

    def _record(name: str, check) -> None:
        try:
            check()
        except Exception as exc:
            dependencies[name] = {
                "ready": False,
                "detail": f"{type(exc).__name__}: {str(exc)[:300]}",
            }
        else:
            dependencies[name] = {"ready": True, "detail": "ok"}

    def _check_source_pg() -> None:
        conn = source_pg_get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
            conn.commit()
        finally:
            source_pg_put_conn(conn)

    def _check_output_pg() -> None:
        conn = pg_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
            conn.commit()
        finally:
            pg_pool.putconn(conn)

    _record("postgres_source", _check_source_pg)
    _record("postgres_output", _check_output_pg)

    if deep:
        def _check_ollama() -> None:
            response = requests.get(OLLAMA_API_TAGS, timeout=5)
            response.raise_for_status()

        def _check_qdrant() -> None:
            get_qdrant_client().get_collections()

        _record("ollama", _check_ollama)
        _record("qdrant", _check_qdrant)

        if NEO4J_ENABLED:
            _record("neo4j", lambda: neo4j_driver.verify_connectivity())
        else:
            dependencies["neo4j"] = {
                "ready": True,
                "detail": "disabled",
            }

    ready = all(item["ready"] for item in dependencies.values())
    return {
        "ready": ready,
        "initialized": _RUNTIME_INITIALIZED,
        "worker_id": INGESTION_WORKER_ID,
        "source_database": SOURCE_PG_DB,
        "output_database": PG_DB,
        "qdrant_collection": QDRANT_COLLECTION,
        "dependencies": dependencies,
    }


def initialize_ingestion_runtime(*, strict: bool = True) -> Dict[str, Any]:
    """Inizializza una sola volta il runtime usato dalla API."""
    global _RUNTIME_INITIALIZED, _RUNTIME_CLOSED

    with _RUNTIME_INIT_LOCK:
        if _RUNTIME_CLOSED:
            raise RuntimeError("Runtime ingestion già chiuso")
        if _RUNTIME_INITIALIZED:
            snapshot = runtime_healthcheck(deep=strict)
            if strict and not snapshot["ready"]:
                failed = [
                    name
                    for name, item in snapshot["dependencies"].items()
                    if not item.get("ready")
                ]
                raise RuntimeError(
                    "Dipendenze ingestion non pronte: " + ", ".join(failed)
                )
            return snapshot

        ensure_postgres_security_schema()
        ensure_neo4j_security_schema()
        if not PG_SCHEMA_MIGRATION_ONLY:
            verify_source_db_contract()

        if PG_SCHEMA_MIGRATION_ONLY:
            _RUNTIME_INITIALIZED = True
            return runtime_healthcheck(deep=False)

        if not USE_REMOTE_OLLAMA and OLLAMA_AUTOSTART:
            if os.name == "nt":
                started = force_restart_ollama(
                    num_parallel=os.getenv("OLLAMA_NUM_PARALLEL", "1")
                )
                if strict and not started:
                    raise RuntimeError("Impossibile avviare Ollama")
            else:
                ensure_ollama_parallel(
                    os.getenv("OLLAMA_NUM_PARALLEL", "1")
                )

        snapshot = runtime_healthcheck(deep=strict)
        if strict and not snapshot["ready"]:
            failed = [
                name
                for name, item in snapshot["dependencies"].items()
                if not item.get("ready")
            ]
            raise RuntimeError(
                "Dipendenze ingestion non pronte: " + ", ".join(failed)
            )

        _RUNTIME_INITIALIZED = True
        return runtime_healthcheck(deep=False)


def process_next_db_job() -> Dict[str, Any]:
    """Claim ed elaborazione completa di un solo job Database A."""
    job = claim_next_db_job()
    if not job:
        return {"status": "EMPTY", "job_id": None}

    heartbeat = JobHeartbeat(job)
    heartbeat.start()
    item: Optional[Dict[str, Any]] = None
    started = time.time()

    try:
        item = prepare_claimed_job_item(job, heartbeat)
        result = consume_claimed_job_item(item) or {}
        return {
            "status": "DONE",
            "job_id": str(job.get("job_id") or ""),
            "job_type": str((item.get("doc_meta") or {}).get("job_type") or ""),
            "document_id": str(result.get("document_id") or ""),
            "chunks": int(result.get("chunks", result.get("chunks_updated", 0)) or 0),
            "processing_time_ms": int(result.get("processing_time_ms", _ms(started)) or 0),
            "ontology_codes": list(result.get("ontology_codes") or []),
        }
    except Exception as exc:
        if item is None:
            heartbeat.stop()
            try:
                next_status = fail_db_job(
                    job,
                    exc,
                    metrics={"processing_time_ms": _ms(started)},
                )
            except Exception:
                next_status = None
            clear_output_db_tenant_context()
        else:
            next_status = None

        return {
            "status": "FAILED",
            "job_id": str(job.get("job_id") or ""),
            "next_status": next_status,
            "processing_time_ms": _ms(started),
            "error": f"{type(exc).__name__}: {str(exc)[:1000]}",
        }


def run_pending_jobs(max_jobs: int = 1) -> Dict[str, Any]:
    """
    Elabora fino a ``max_jobs`` job.

    Con USE_PRODUCER_CONSUMER=1:
    - il thread chiamante agisce da producer;
    - prepara BYTEA, file temporaneo e chunk;
    - un consumer dedicato esegue embedding, PostgreSQL, Qdrant e Neo4j;
    - la coda consente di preparare il documento successivo mentre il
      documento precedente viene consumato.

    Con USE_PRODUCER_CONSUMER=0:
    - mantiene disponibile il percorso sequenziale precedente.
    """
    if isinstance(max_jobs, bool) or int(max_jobs) <= 0:
        raise ValueError("max_jobs deve essere maggiore di zero")

    max_jobs = int(max_jobs)

    if PG_SCHEMA_MIGRATION_ONLY:
        raise RuntimeError(
            "PG_SCHEMA_MIGRATION_ONLY=1: "
            "la API non può eseguire job di ingestion"
        )

    use_producer_consumer = (
        os.getenv("USE_PRODUCER_CONSUMER", "1") == "1"
    )
    os.environ["PRODUCER_CONSUMER_MODE"] = (
        "1" if use_producer_consumer else "0"
    )

    started = time.time()
    initialize_ingestion_runtime(strict=True)

    results: List[Dict[str, Any]] = []
    queue_empty = False

    def done_result(
        item: Dict[str, Any],
        result: Optional[Dict[str, Any]],
        claim_index: int,
    ) -> Dict[str, Any]:
        result = result or {}
        doc_meta = item.get("doc_meta") or {}
        job = item.get("job") or {}

        return {
            "_claim_index": claim_index,
            "status": "DONE",
            "job_id": str(job.get("job_id") or ""),
            "job_type": str(doc_meta.get("job_type") or ""),
            "document_id": str(
                result.get("document_id")
                or doc_meta.get("document_id")
                or ""
            ),
            "chunks": int(
                result.get(
                    "chunks",
                    result.get("chunks_updated", 0),
                )
                or 0
            ),
            "processing_time_ms": int(
                result.get(
                    "processing_time_ms",
                    _ms(item["started"]),
                )
                or 0
            ),
            "ontology_codes": list(
                result.get("ontology_codes")
                or doc_meta.get("ontology_codes")
                or []
            ),
        }

    def failed_result(
        *,
        job: Dict[str, Any],
        claim_index: int,
        job_started: float,
        exc: Exception,
        item: Optional[Dict[str, Any]] = None,
        next_status: Optional[str] = None,
    ) -> Dict[str, Any]:
        doc_meta = (item or {}).get("doc_meta") or {}

        return {
            "_claim_index": claim_index,
            "status": "FAILED",
            "job_id": str(job.get("job_id") or ""),
            "job_type": str(
                doc_meta.get("job_type")
                or job.get("job_type")
                or ""
            ),
            "document_id": str(
                doc_meta.get("document_id")
                or job.get("document_id")
                or ""
            ),
            "chunks": 0,
            "processing_time_ms": _ms(job_started),
            "ontology_codes": list(
                doc_meta.get("ontology_codes") or []
            ),
            "next_status": next_status,
            "error": (
                f"{type(exc).__name__}: "
                f"{str(exc)[:1000]}"
            ),
        }

    with ingestion_global_lock():
        # ---------------------------------------------------------
        # FALLBACK SEQUENZIALE
        # ---------------------------------------------------------
        if not use_producer_consumer:
            print(
                "   🧱 API in modalità sequenziale: "
                "producer/consumer disabilitato."
            )

            for _ in range(max_jobs):
                result = process_next_db_job()

                if result.get("status") == "EMPTY":
                    queue_empty = True
                    break

                results.append(result)

        # ---------------------------------------------------------
        # PRODUCER / CONSUMER
        # ---------------------------------------------------------
        else:
            try:
                queue_maxsize = int(
                    os.getenv("DOC_QUEUE_MAXSIZE", "1")
                )
            except ValueError as exc:
                raise ValueError(
                    "DOC_QUEUE_MAXSIZE deve essere un intero"
                ) from exc

            queue_maxsize = max(1, queue_maxsize)

            print(
                "   🚚 API Producer/Consumer attivo | "
                f"max_jobs={max_jobs} | "
                f"queue_size={queue_maxsize} | "
                "consumers=1"
            )

            doc_queue = queue.Queue(maxsize=queue_maxsize)
            results_lock = threading.Lock()

            def append_result(result: Dict[str, Any]) -> None:
                with results_lock:
                    results.append(result)

            def consumer_worker() -> None:
                print("   🧠 Consumer AI/Database avviato.")

                while True:
                    envelope = doc_queue.get()

                    try:
                        if envelope is None:
                            print(
                                "   🛑 Consumer AI/Database terminato."
                            )
                            return

                        claim_index = int(
                            envelope["claim_index"]
                        )
                        item = envelope["item"]
                        job = item["job"]

                        try:
                            consumed = (
                                consume_claimed_job_item(item) or {}
                            )
                        except Exception as exc:
                            # consume_claimed_job_item ha già:
                            # - fermato heartbeat;
                            # - aggiornato log PostgreSQL;
                            # - chiamato fail_db_job;
                            # - eliminato il file temporaneo;
                            # - pulito il tenant context.
                            append_result(
                                failed_result(
                                    job=job,
                                    claim_index=claim_index,
                                    job_started=item["started"],
                                    exc=exc,
                                    item=item,
                                )
                            )
                        else:
                            append_result(
                                done_result(
                                    item,
                                    consumed,
                                    claim_index,
                                )
                            )
                    finally:
                        doc_queue.task_done()

            consumer_thread = threading.Thread(
                target=consumer_worker,
                name="ingestion-document-consumer",
                daemon=False,
            )
            consumer_thread.start()

            try:
                for claim_index in range(max_jobs):
                    job = claim_next_db_job()

                    if not job:
                        queue_empty = True
                        print(
                            "   ✅ Nessun altro job PENDING "
                            "disponibile nel Database A."
                        )
                        break

                    print(
                        f"   📤 Producer: job reclamato "
                        f"{job.get('job_id')} "
                        f"({claim_index + 1}/{max_jobs})"
                    )

                    heartbeat = JobHeartbeat(job)
                    heartbeat.start()
                    item: Optional[Dict[str, Any]] = None
                    job_started = time.time()

                    try:
                        item = prepare_claimed_job_item(
                            job,
                            heartbeat,
                        )

                        envelope = {
                            "claim_index": claim_index,
                            "item": item,
                        }

                        while True:
                            try:
                                doc_queue.put(
                                    envelope,
                                    timeout=30,
                                )
                                print(
                                    "   📬 Producer: documento "
                                    "inserito nella coda AI/Database | "
                                    f"job={job.get('job_id')}"
                                )
                                break
                            except queue.Full:
                                print(
                                    "   ⏳ Coda piena: attendo "
                                    "il consumer AI/Database..."
                                )

                    except Exception as exc:
                        heartbeat.stop()

                        print(
                            "   ❌ Errore preparazione job "
                            f"{job.get('job_id')}: {exc}"
                        )

                        next_status = None
                        try:
                            next_status = fail_db_job(
                                job,
                                exc,
                                metrics={
                                    "processing_time_ms": _ms(
                                        job_started
                                    )
                                },
                            )
                            print(
                                "   ↩️ Stato job dopo errore "
                                f"iniziale: {next_status}"
                            )
                        except Exception as fail_exc:
                            print(
                                "   ⚠️ Impossibile registrare "
                                "il fallimento del job: "
                                f"{fail_exc}"
                            )

                        # prepare_claimed_job_item esegue già il cleanup
                        # in caso di errore. Questi richiami restano
                        # intenzionalmente idempotenti.
                        cleanup_materialized_bytea(
                            (item or {}).get("doc_meta")
                        )
                        clear_output_db_tenant_context()

                        append_result(
                            failed_result(
                                job=job,
                                claim_index=claim_index,
                                job_started=job_started,
                                exc=exc,
                                item=item,
                                next_status=next_status,
                            )
                        )

                    else:
                        # Il contesto thread-local del producer non deve
                        # passare al documento successivo.
                        # Il consumer imposterà il proprio contesto.
                        clear_output_db_tenant_context()

                print(
                    "   ⏳ Producer completato. "
                    "Attesa completamento consumer AI/Database..."
                )

            finally:
                # Sentinel FIFO: viene consumito solo dopo tutti
                # i documenti già presenti nella coda.
                doc_queue.put(None)
                doc_queue.join()
                consumer_thread.join()

            # Il consumer è unico: l'ordine è già normalmente stabile.
            # Il sort protegge anche il caso di errori di preparazione
            # registrati mentre il consumer elabora un job precedente.
            results.sort(
                key=lambda item: int(
                    item.get("_claim_index", 0)
                )
            )

            for result in results:
                result.pop("_claim_index", None)

    try:
        if PDF_VISION_ENABLED and VISION_MODEL_NAME:
            force_unload_ollama(VISION_MODEL_NAME)

        if LLM_MODEL_NAME:
            force_unload_ollama(LLM_MODEL_NAME)
    except Exception:
        pass

    failed = sum(
        1
        for item in results
        if item.get("status") == "FAILED"
    )
    done = sum(
        1
        for item in results
        if item.get("status") == "DONE"
    )

    status = (
        "DONE"
        if failed == 0
        else ("PARTIAL_FAILED" if done else "FAILED")
    )

    total_ms = _ms(started)

    print("\n" + "=" * 60)
    print(
        "   ✨ Ingestion API completata | "
        f"mode={'producer-consumer' if use_producer_consumer else 'sequential'} "
        f"| claimed={len(results)} "
        f"| completed={done} "
        f"| failed={failed} "
        f"| total_time={total_ms / 1000:.2f}s"
    )
    print("=" * 60)

    return {
        "status": status,
        "jobs_claimed": len(results),
        "jobs_completed": done,
        "jobs_failed": failed,
        "queue_empty": queue_empty,
        "processing_time_ms": total_ms,
        "jobs": results,
    }


def shutdown_ingestion_runtime() -> None:
    """Chiude in modo idempotente pool e client posseduti dal modulo."""
    global _RUNTIME_CLOSED, _RUNTIME_INITIALIZED, qdrant_client

    with _RUNTIME_INIT_LOCK:
        if _RUNTIME_CLOSED:
            return
        _RUNTIME_CLOSED = True

        try:
            if qdrant_client is not None and hasattr(qdrant_client, "close"):
                qdrant_client.close()
        except Exception:
            pass
        try:
            if neo4j_driver is not None:
                neo4j_driver.close()
        except Exception:
            pass
        try:
            pg_pool.closeall()
        except Exception:
            pass
        try:
            source_pg_pool.closeall()
        except Exception:
            pass

        _RUNTIME_INITIALIZED = False


def main():
    """
    Producer/Consumer alimentato esclusivamente dal Database A:
    - claim atomico dei job rag_ingestion;
    - lettura del BYTEA e delle ontology configurate nel DB;
    - pipeline AI/Qdrant/PostgreSQL/Neo4j invariata;
    - completamento o fallimento del job nel Database A.
    """
    total_t0 = time.time()

    ensure_postgres_security_schema()
    ensure_neo4j_security_schema()

    if not PG_SCHEMA_MIGRATION_ONLY:
        verify_source_db_contract()

    if PG_SCHEMA_MIGRATION_ONLY:
        print(
            "✅ Bootstrap sicurezza PostgreSQL/Neo4j completato. "
            "Nessuna ingestion eseguita."
        )
        return

    use_producer_consumer = (
        os.getenv("USE_PRODUCER_CONSUMER", "1") == "1"
    )
    os.environ["PRODUCER_CONSUMER_MODE"] = (
        "1" if use_producer_consumer else "0"
    )

    if not USE_REMOTE_OLLAMA and OLLAMA_AUTOSTART:
        if not force_restart_ollama(
            num_parallel=os.getenv("OLLAMA_NUM_PARALLEL", "1")
        ):
            print(
                "   ❌ Errore: impossibile avviare Ollama "
                "in modalità ottimizzata."
            )
            print(
                "   ⚠️ L'ingestion potrebbe fallire o risultare "
                "estremamente lenta."
            )
    else:
        print("   ☁️ Ollama remoto/containerizzato: skip restart locale.")

    print(
        f"   🔌 Ollama endpoint | base={OLLAMA_BASE_URL} "
        f"| chat={OLLAMA_API_CHAT} | generate={OLLAMA_API_GENERATE}"
    )

    print("\n" + "=" * 60)
    print("=== Ingestion Engine v2.5 (Database BYTEA) ===")
    print(
        f"=== Source DB: {SOURCE_PG_DB} | "
        f"Worker: {INGESTION_WORKER_ID} ==="
    )
    print("=" * 60 + "\n")

    claimed_jobs = 0
    processed_jobs = 0
    counter_lock = threading.Lock()

    def register_claim() -> None:
        nonlocal claimed_jobs
        with counter_lock:
            claimed_jobs += 1

    def register_processed() -> None:
        nonlocal processed_jobs
        with counter_lock:
            processed_jobs += 1

    def can_claim_more() -> bool:
        with counter_lock:
            return (
                DB_MAX_JOBS_PER_RUN == 0
                or claimed_jobs < DB_MAX_JOBS_PER_RUN
            )

    def claim_one() -> Optional[Dict[str, Any]]:
        if not can_claim_more():
            return None
        job = claim_next_db_job()
        if job:
            register_claim()
        return job

    if not use_producer_consumer:
        print(
            "   🧱 Modalità sequenziale attiva: "
            "producer/consumer disabilitato."
        )
        while can_claim_more():
            job = claim_one()
            if not job:
                break

            heartbeat = JobHeartbeat(job)
            heartbeat.start()
            item = None
            try:
                item = prepare_claimed_job_item(job, heartbeat)
                consume_claimed_job_item(item)
            except Exception as exc:
                if item is None:
                    heartbeat.stop()
                    try:
                        next_status = fail_db_job(
                            job,
                            exc,
                            metrics={"processing_time_ms": 0},
                        )
                        print(
                            f"   ↩️ Stato job dopo errore iniziale: "
                            f"{next_status}"
                        )
                    except Exception as fail_exc:
                        print(
                            "   ⚠️ Impossibile registrare il fallimento "
                            f"del job: {fail_exc}"
                        )
                # consume_claimed_job_item ha già gestito log/job/cleanup.
            finally:
                if item is None:
                    clear_output_db_tenant_context()
                register_processed()

        if processed_jobs == 0:
            print(
                "   ✅ Nessun job PENDING disponibile nel Database A."
            )
        print("\n" + "=" * 60)
        print(
            "   ✨ Ingestion DB sequenziale completata | "
            f"jobs={processed_jobs} | "
            f"total_time={time.time() - total_t0:.2f}s"
        )
        print("=" * 60)
        return

    doc_queue = queue.Queue(
        maxsize=int(os.getenv("DOC_QUEUE_MAXSIZE", "1"))
    )
    num_consumers = 1

    def consumer_worker() -> None:
        while True:
            item = doc_queue.get()
            try:
                if item is None:
                    return
                try:
                    consume_claimed_job_item(item)
                except Exception:
                    # Errore già registrato dalla funzione di consumo.
                    pass
                finally:
                    register_processed()
            finally:
                doc_queue.task_done()

    consumers = []
    for _ in range(num_consumers):
        thread = threading.Thread(
            target=consumer_worker,
            daemon=False,
        )
        thread.start()
        consumers.append(thread)

    while can_claim_more():
        job = claim_one()
        if not job:
            break

        heartbeat = JobHeartbeat(job)
        heartbeat.start()
        item = None
        try:
            item = prepare_claimed_job_item(job, heartbeat)
            while True:
                try:
                    doc_queue.put(item, timeout=30)
                    break
                except queue.Full:
                    print(
                        "   ⏳ Coda piena: attendo il consumer AI/DB..."
                    )
        except Exception as exc:
            heartbeat.stop()
            print(
                f"   ❌ Errore preparazione job {job.get('job_id')}: {exc}"
            )
            if item is not None:
                doc_meta = item.get("doc_meta")
                log_id = item.get("log_id")
            else:
                doc_meta = None
                log_id = None

            if doc_meta:
                try:
                    set_output_db_tenant_context(doc_meta)
                except Exception:
                    pass
            if log_id is not None:
                try:
                    pg_fail_log_if_running(
                        log_id,
                        0,
                        str(exc)[:500],
                    )
                except Exception:
                    pass
            try:
                next_status = fail_db_job(
                    job,
                    exc,
                    metrics={"processing_time_ms": 0},
                )
                print(
                    f"   ↩️ Stato job dopo errore iniziale: {next_status}"
                )
            except Exception as fail_exc:
                print(
                    "   ⚠️ Impossibile registrare il fallimento del job: "
                    f"{fail_exc}"
                )
            cleanup_materialized_bytea(doc_meta)
            clear_output_db_tenant_context()
            register_processed()
        else:
            # Il consumer imposterà il proprio contesto thread-local.
            clear_output_db_tenant_context()

    print(
        "   ⏳ Claim e lettura BYTEA completati. "
        "Attesa completamento AI/Database..."
    )
    for _ in range(num_consumers):
        doc_queue.put(None)
    doc_queue.join()
    for thread in consumers:
        thread.join()

    if claimed_jobs == 0:
        print("   ✅ Nessun job PENDING disponibile nel Database A.")

    try:
        if PDF_VISION_ENABLED and VISION_MODEL_NAME:
            force_unload_ollama(VISION_MODEL_NAME)
        if LLM_MODEL_NAME:
            force_unload_ollama(LLM_MODEL_NAME)
    except Exception:
        pass

    total_ms = _ms(total_t0)
    print("\n" + "=" * 60)
    print(
        "   ✨ Ingestion DB Producer/Consumer completata | "
        f"jobs={processed_jobs} | total_time={total_ms / 1000:.2f}s"
    )
    print("=" * 60)


if __name__ == "__main__":
    main()